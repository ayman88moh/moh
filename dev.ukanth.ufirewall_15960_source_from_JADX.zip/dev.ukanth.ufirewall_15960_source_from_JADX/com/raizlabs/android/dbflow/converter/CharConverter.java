package com.raizlabs.android.dbflow.converter;

public class CharConverter extends TypeConverter<String, Character> {
    public String getDBValue(Character model) {
        if (model == null) {
            return null;
        }
        return new String(new char[]{model.charValue()});
    }

    public Character getModelValue(String data) {
        return data != null ? Character.valueOf(data.charAt(0)) : null;
    }
}
