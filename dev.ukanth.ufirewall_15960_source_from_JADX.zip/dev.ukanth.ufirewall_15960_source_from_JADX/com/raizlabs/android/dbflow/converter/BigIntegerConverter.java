package com.raizlabs.android.dbflow.converter;

import java.math.BigInteger;

public class BigIntegerConverter extends TypeConverter<String, BigInteger> {
    public String getDBValue(BigInteger model) {
        return model == null ? null : model.toString();
    }

    public BigInteger getModelValue(String data) {
        return data == null ? null : new BigInteger(data);
    }
}
