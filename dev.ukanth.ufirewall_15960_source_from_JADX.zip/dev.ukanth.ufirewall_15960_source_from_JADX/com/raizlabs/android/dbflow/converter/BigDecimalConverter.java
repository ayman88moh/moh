package com.raizlabs.android.dbflow.converter;

import java.math.BigDecimal;

public class BigDecimalConverter extends TypeConverter<String, BigDecimal> {
    public String getDBValue(BigDecimal model) {
        return model == null ? null : model.toString();
    }

    public BigDecimal getModelValue(String data) {
        return data == null ? null : new BigDecimal(data);
    }
}
