package com.raizlabs.android.dbflow.converter;

import java.util.UUID;

public class UUIDConverter extends TypeConverter<String, UUID> {
    public String getDBValue(UUID model) {
        return model != null ? model.toString() : null;
    }

    public UUID getModelValue(String data) {
        if (data == null) {
            return null;
        }
        return UUID.fromString(data);
    }
}
