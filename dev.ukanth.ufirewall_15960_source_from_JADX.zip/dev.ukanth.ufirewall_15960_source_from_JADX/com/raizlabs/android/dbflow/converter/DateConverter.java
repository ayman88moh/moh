package com.raizlabs.android.dbflow.converter;

import java.util.Date;

public class DateConverter extends TypeConverter<Long, Date> {
    public Long getDBValue(Date model) {
        return model == null ? null : Long.valueOf(model.getTime());
    }

    public Date getModelValue(Long data) {
        return data == null ? null : new Date(data.longValue());
    }
}
