package com.raizlabs.android.dbflow.converter;

import com.raizlabs.android.dbflow.annotation.TypeConverter;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;

@TypeConverter(allowedSubtypes = {Time.class, Timestamp.class})
public class SqlDateConverter extends TypeConverter<Long, Date> {
    public Long getDBValue(Date model) {
        return model == null ? null : Long.valueOf(model.getTime());
    }

    public Date getModelValue(Long data) {
        return data == null ? null : new Date(data.longValue());
    }
}
