package com.raizlabs.android.dbflow.converter;

import com.raizlabs.android.dbflow.annotation.TypeConverter;
import java.util.Calendar;
import java.util.GregorianCalendar;

@TypeConverter(allowedSubtypes = {GregorianCalendar.class})
public class CalendarConverter extends TypeConverter<Long, Calendar> {
    public Long getDBValue(Calendar model) {
        return model == null ? null : Long.valueOf(model.getTimeInMillis());
    }

    public Calendar getModelValue(Long data) {
        if (data == null) {
            return null;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(data.longValue());
        return calendar;
    }
}
