package com.raizlabs.android.dbflow.annotation;

public enum Collate {
    NONE,
    BINARY,
    NOCASE,
    RTRIM,
    LOCALIZED,
    UNICODE
}
