package com.raizlabs.android.dbflow;

public final class BuildConfig {
    public static final String APPLICATION_ID = "com.raizlabs.android.dbflow";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 49;
    public static final String VERSION_NAME = "";
}
