package com.raizlabs.android.dbflow.list;

import android.annotation.TargetApi;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.list.FlowCursorList.OnCursorRefreshListener;
import com.raizlabs.android.dbflow.runtime.FlowContentObserver;
import com.raizlabs.android.dbflow.sql.language.SQLite;
import com.raizlabs.android.dbflow.sql.queriable.ModelQueriable;
import com.raizlabs.android.dbflow.structure.InstanceAdapter;
import com.raizlabs.android.dbflow.structure.ModelAdapter;
import com.raizlabs.android.dbflow.structure.cache.ModelCache;
import com.raizlabs.android.dbflow.structure.database.DatabaseWrapper;
import com.raizlabs.android.dbflow.structure.database.transaction.ProcessModelTransaction.ProcessModel;
import com.raizlabs.android.dbflow.structure.database.transaction.Transaction;
import com.raizlabs.android.dbflow.structure.database.transaction.Transaction.Error;
import com.raizlabs.android.dbflow.structure.database.transaction.Transaction.Success;
import java.util.Collection;
import java.util.List;
import java.util.ListIterator;

public class FlowQueryList<TModel> extends FlowContentObserver implements List<TModel>, IFlowCursorIterator<TModel> {
    private static final Handler REFRESH_HANDLER = new Handler(Looper.myLooper());
    private boolean changeInTransaction;
    private final ProcessModel<TModel> deleteModel;
    private final Error errorCallback;
    private final FlowCursorList<TModel> internalCursorList;
    private final Error internalErrorCallback;
    private final Success internalSuccessCallback;
    private boolean pendingRefresh;
    private final Runnable refreshRunnable;
    private final ProcessModel<TModel> saveModel;
    private final Success successCallback;
    private boolean transact;
    private final ProcessModel<TModel> updateModel;

    class C02556 implements Runnable {
        C02556() {
        }

        public void run() {
            synchronized (this) {
                FlowQueryList.this.pendingRefresh = false;
            }
            FlowQueryList.this.refresh();
        }
    }

    public static class Builder<TModel> {
        private boolean cacheModels;
        private boolean changeInTransaction;
        private Cursor cursor;
        private Error error;
        private ModelCache<TModel, ?> modelCache;
        private ModelQueriable<TModel> modelQueriable;
        private Success success;
        private final Class<TModel> table;
        private boolean transact;

        private Builder(FlowCursorList<TModel> cursorList) {
            this.cacheModels = true;
            this.table = cursorList.table();
            this.cursor = cursorList.cursor();
            this.cacheModels = cursorList.cachingEnabled();
            this.modelQueriable = cursorList.modelQueriable();
            this.modelCache = cursorList.modelCache();
        }

        public Builder(Class<TModel> table) {
            this.cacheModels = true;
            this.table = table;
        }

        public Builder(@NonNull ModelQueriable<TModel> modelQueriable) {
            this(modelQueriable.getTable());
            modelQueriable(modelQueriable);
        }

        public Builder<TModel> cursor(Cursor cursor) {
            this.cursor = cursor;
            return this;
        }

        public Builder<TModel> modelQueriable(ModelQueriable<TModel> modelQueriable) {
            this.modelQueriable = modelQueriable;
            return this;
        }

        public Builder<TModel> transact(boolean transact) {
            this.transact = transact;
            return this;
        }

        public Builder<TModel> modelCache(ModelCache<TModel, ?> modelCache) {
            this.modelCache = modelCache;
            return this;
        }

        public Builder<TModel> changeInTransaction(boolean changeInTransaction) {
            this.changeInTransaction = changeInTransaction;
            return this;
        }

        public Builder<TModel> cacheModels(boolean cacheModels) {
            this.cacheModels = cacheModels;
            return this;
        }

        public Builder<TModel> success(Success success) {
            this.success = success;
            return this;
        }

        public Builder<TModel> error(Error error) {
            this.error = error;
            return this;
        }

        public FlowQueryList<TModel> build() {
            return new FlowQueryList();
        }
    }

    class C04941 implements ProcessModel<TModel> {
        C04941() {
        }

        public void processModel(TModel model, DatabaseWrapper wrapper) {
            FlowQueryList.this.getModelAdapter().save(model);
        }
    }

    class C04952 implements ProcessModel<TModel> {
        C04952() {
        }

        public void processModel(TModel model, DatabaseWrapper wrapper) {
            FlowQueryList.this.getModelAdapter().update(model);
        }
    }

    class C04963 implements ProcessModel<TModel> {
        C04963() {
        }

        public void processModel(TModel model, DatabaseWrapper wrapper) {
            FlowQueryList.this.getModelAdapter().delete(model);
        }
    }

    class C04974 implements Error {
        C04974() {
        }

        public void onError(@NonNull Transaction transaction, @NonNull Throwable error) {
            if (FlowQueryList.this.errorCallback != null) {
                FlowQueryList.this.errorCallback.onError(transaction, error);
            }
        }
    }

    class C04985 implements Success {
        C04985() {
        }

        public void onSuccess(@NonNull Transaction transaction) {
            if (FlowQueryList.this.isInTransaction) {
                FlowQueryList.this.changeInTransaction = true;
            } else {
                FlowQueryList.this.refreshAsync();
            }
            if (FlowQueryList.this.successCallback != null) {
                FlowQueryList.this.successCallback.onSuccess(transaction);
            }
        }
    }

    private FlowQueryList(Builder<TModel> builder) {
        this.transact = false;
        this.changeInTransaction = false;
        this.pendingRefresh = false;
        this.saveModel = new C04941();
        this.updateModel = new C04952();
        this.deleteModel = new C04963();
        this.internalErrorCallback = new C04974();
        this.internalSuccessCallback = new C04985();
        this.refreshRunnable = new C02556();
        this.transact = builder.transact;
        this.changeInTransaction = builder.changeInTransaction;
        this.successCallback = builder.success;
        this.errorCallback = builder.error;
        this.internalCursorList = new com.raizlabs.android.dbflow.list.FlowCursorList.Builder(builder.table).cursor(builder.cursor).cacheModels(builder.cacheModels).modelQueriable(builder.modelQueriable).modelCache(builder.modelCache).build();
    }

    public void registerForContentChanges(@NonNull Context context) {
        super.registerForContentChanges(context, this.internalCursorList.table());
    }

    public void addOnCursorRefreshListener(@NonNull OnCursorRefreshListener<TModel> onCursorRefreshListener) {
        this.internalCursorList.addOnCursorRefreshListener(onCursorRefreshListener);
    }

    public void removeOnCursorRefreshListener(@NonNull OnCursorRefreshListener<TModel> onCursorRefreshListener) {
        this.internalCursorList.removeOnCursorRefreshListener(onCursorRefreshListener);
    }

    public void registerForContentChanges(Context context, Class<?> cls) {
        throw new RuntimeException("This method is not to be used in the FlowQueryList. We should only ever receive notifications for one class here. Call registerForContentChanges(Context) instead");
    }

    public void onChange(boolean selfChange) {
        super.onChange(selfChange);
        if (this.isInTransaction) {
            this.changeInTransaction = true;
        } else {
            refreshAsync();
        }
    }

    @TargetApi(16)
    public void onChange(boolean selfChange, Uri uri) {
        super.onChange(selfChange, uri);
        if (this.isInTransaction) {
            this.changeInTransaction = true;
        } else {
            refreshAsync();
        }
    }

    @NonNull
    public List<TModel> getCopy() {
        return this.internalCursorList.getAll();
    }

    @NonNull
    public FlowCursorList<TModel> cursorList() {
        return this.internalCursorList;
    }

    @Nullable
    public Error error() {
        return this.errorCallback;
    }

    @Nullable
    public Success success() {
        return this.successCallback;
    }

    public boolean changeInTransaction() {
        return this.changeInTransaction;
    }

    public boolean transact() {
        return this.transact;
    }

    @NonNull
    ModelAdapter<TModel> getModelAdapter() {
        return this.internalCursorList.getModelAdapter();
    }

    @NonNull
    InstanceAdapter<TModel> getInstanceAdapter() {
        return this.internalCursorList.getInstanceAdapter();
    }

    @NonNull
    public Builder<TModel> newBuilder() {
        return new Builder(this.internalCursorList).success(this.successCallback).error(this.errorCallback).changeInTransaction(this.changeInTransaction).transact(this.transact);
    }

    public void refresh() {
        this.internalCursorList.refresh();
    }

    public void refreshAsync() {
        synchronized (this) {
            if (this.pendingRefresh) {
                return;
            }
            this.pendingRefresh = true;
            REFRESH_HANDLER.post(this.refreshRunnable);
        }
    }

    public void endTransactionAndNotify() {
        if (this.changeInTransaction) {
            this.changeInTransaction = false;
            refresh();
        }
        super.endTransactionAndNotify();
    }

    public void add(int location, @Nullable TModel model) {
        add(model);
    }

    public boolean add(@Nullable TModel model) {
        if (model == null) {
            return false;
        }
        Transaction transaction = FlowManager.getDatabaseForTable(this.internalCursorList.table()).beginTransactionAsync(new com.raizlabs.android.dbflow.structure.database.transaction.ProcessModelTransaction.Builder(this.saveModel).add(model).build()).error(this.internalErrorCallback).success(this.internalSuccessCallback).build();
        if (this.transact) {
            transaction.execute();
        } else {
            transaction.executeSync();
        }
        return true;
    }

    public boolean addAll(int location, @NonNull Collection<? extends TModel> collection) {
        return addAll(collection);
    }

    public boolean addAll(@NonNull Collection<? extends TModel> collection) {
        Transaction transaction = FlowManager.getDatabaseForTable(this.internalCursorList.table()).beginTransactionAsync(new com.raizlabs.android.dbflow.structure.database.transaction.ProcessModelTransaction.Builder(this.saveModel).addAll((Collection) collection).build()).error(this.internalErrorCallback).success(this.internalSuccessCallback).build();
        if (this.transact) {
            transaction.execute();
        } else {
            transaction.executeSync();
        }
        return true;
    }

    public void clear() {
        Transaction transaction = FlowManager.getDatabaseForTable(this.internalCursorList.table()).beginTransactionAsync(new com.raizlabs.android.dbflow.structure.database.transaction.QueryTransaction.Builder(SQLite.delete().from(this.internalCursorList.table())).build()).error(this.internalErrorCallback).success(this.internalSuccessCallback).build();
        if (this.transact) {
            transaction.execute();
        } else {
            transaction.executeSync();
        }
    }

    public boolean contains(@Nullable Object object) {
        if (object == null || !this.internalCursorList.table().isAssignableFrom(object.getClass())) {
            return false;
        }
        return this.internalCursorList.getInstanceAdapter().exists(object);
    }

    public boolean containsAll(@NonNull Collection<?> collection) {
        boolean contains = !collection.isEmpty();
        if (!contains) {
            return contains;
        }
        for (Object o : collection) {
            if (!contains(o)) {
                return false;
            }
        }
        return contains;
    }

    public long getCount() {
        return this.internalCursorList.getCount();
    }

    @Nullable
    public TModel getItem(long position) {
        return this.internalCursorList.getItem(position);
    }

    @Nullable
    public Cursor cursor() {
        return this.internalCursorList.cursor();
    }

    @Nullable
    public TModel get(int row) {
        return this.internalCursorList.getItem((long) row);
    }

    public int indexOf(Object object) {
        throw new UnsupportedOperationException("We cannot determine which index in the table this item exists at efficiently");
    }

    public boolean isEmpty() {
        return this.internalCursorList.isEmpty();
    }

    @NonNull
    public FlowCursorIterator<TModel> iterator() {
        return new FlowCursorIterator(this);
    }

    @NonNull
    public FlowCursorIterator<TModel> iterator(int startingLocation, long limit) {
        return new FlowCursorIterator(this, startingLocation, limit);
    }

    public int lastIndexOf(Object object) {
        throw new UnsupportedOperationException("We cannot determine which index in the table this item exists at efficiently");
    }

    @NonNull
    public ListIterator<TModel> listIterator() {
        return new FlowCursorIterator(this);
    }

    @NonNull
    public ListIterator<TModel> listIterator(int location) {
        return new FlowCursorIterator(this, location);
    }

    public TModel remove(int location) {
        TModel model = this.internalCursorList.getItem((long) location);
        Transaction transaction = FlowManager.getDatabaseForTable(this.internalCursorList.table()).beginTransactionAsync(new com.raizlabs.android.dbflow.structure.database.transaction.ProcessModelTransaction.Builder(this.deleteModel).add(model).build()).error(this.internalErrorCallback).success(this.internalSuccessCallback).build();
        if (this.transact) {
            transaction.execute();
        } else {
            transaction.executeSync();
        }
        return model;
    }

    public boolean remove(Object object) {
        if (!this.internalCursorList.table().isAssignableFrom(object.getClass())) {
            return false;
        }
        Transaction transaction = FlowManager.getDatabaseForTable(this.internalCursorList.table()).beginTransactionAsync(new com.raizlabs.android.dbflow.structure.database.transaction.ProcessModelTransaction.Builder(this.deleteModel).add(object).build()).error(this.internalErrorCallback).success(this.internalSuccessCallback).build();
        if (this.transact) {
            transaction.execute();
        } else {
            transaction.executeSync();
        }
        return true;
    }

    public boolean removeAll(@NonNull Collection<?> collection) {
        Transaction transaction = FlowManager.getDatabaseForTable(this.internalCursorList.table()).beginTransactionAsync(new com.raizlabs.android.dbflow.structure.database.transaction.ProcessModelTransaction.Builder(this.deleteModel).addAll((Collection) collection).build()).error(this.internalErrorCallback).success(this.internalSuccessCallback).build();
        if (this.transact) {
            transaction.execute();
        } else {
            transaction.executeSync();
        }
        return true;
    }

    public boolean retainAll(@NonNull Collection<?> collection) {
        List<TModel> tableList = this.internalCursorList.getAll();
        tableList.removeAll(collection);
        Transaction transaction = FlowManager.getDatabaseForTable(this.internalCursorList.table()).beginTransactionAsync(new com.raizlabs.android.dbflow.structure.database.transaction.ProcessModelTransaction.Builder(tableList, this.deleteModel).build()).error(this.internalErrorCallback).success(this.internalSuccessCallback).build();
        if (this.transact) {
            transaction.execute();
        } else {
            transaction.executeSync();
        }
        return true;
    }

    public TModel set(int location, TModel object) {
        return set(object);
    }

    public TModel set(TModel object) {
        Transaction transaction = FlowManager.getDatabaseForTable(this.internalCursorList.table()).beginTransactionAsync(new com.raizlabs.android.dbflow.structure.database.transaction.ProcessModelTransaction.Builder(this.updateModel).add(object).build()).error(this.internalErrorCallback).success(this.internalSuccessCallback).build();
        if (this.transact) {
            transaction.execute();
        } else {
            transaction.executeSync();
        }
        return object;
    }

    public int size() {
        return (int) this.internalCursorList.getCount();
    }

    @NonNull
    public List<TModel> subList(int start, int end) {
        return this.internalCursorList.getAll().subList(start, end);
    }

    @NonNull
    public Object[] toArray() {
        return this.internalCursorList.getAll().toArray();
    }

    @NonNull
    public <T> T[] toArray(T[] array) {
        return this.internalCursorList.getAll().toArray(array);
    }

    public void close() {
        this.internalCursorList.close();
    }
}
