package com.raizlabs.android.dbflow.list;

import android.database.Cursor;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import java.util.ConcurrentModificationException;
import java.util.ListIterator;

public class FlowCursorIterator<TModel> implements ListIterator<TModel>, AutoCloseable {
    private long count;
    private final IFlowCursorIterator<TModel> cursorList;
    private long reverseIndex;
    private long startingCount;

    public FlowCursorIterator(@NonNull IFlowCursorIterator<TModel> cursorList) {
        this(cursorList, 0, cursorList.getCount());
    }

    public FlowCursorIterator(@NonNull IFlowCursorIterator<TModel> cursorList, int startingLocation) {
        this(cursorList, startingLocation, cursorList.getCount() - ((long) startingLocation));
    }

    public FlowCursorIterator(@NonNull IFlowCursorIterator<TModel> cursorList, int startingLocation, long count) {
        this.cursorList = cursorList;
        this.count = count;
        Cursor cursor = cursorList.cursor();
        if (cursor != null) {
            if (this.count > ((long) (cursor.getCount() - startingLocation))) {
                this.count = (long) (cursor.getCount() - startingLocation);
            }
            cursor.moveToPosition(startingLocation - 1);
            this.startingCount = cursorList.getCount();
            this.reverseIndex = this.count;
            this.reverseIndex -= (long) startingLocation;
            if (this.reverseIndex < 0) {
                this.reverseIndex = 0;
            }
        }
    }

    public void close() throws Exception {
        this.cursorList.close();
    }

    public void add(@Nullable TModel tModel) {
        throw new UnsupportedOperationException("Cursor Iterator: Cannot add a model in the iterator");
    }

    public boolean hasNext() {
        checkSizes();
        return this.reverseIndex > 0;
    }

    public boolean hasPrevious() {
        checkSizes();
        return this.reverseIndex < this.count;
    }

    @Nullable
    public TModel next() {
        checkSizes();
        TModel item = this.cursorList.getItem(this.count - this.reverseIndex);
        this.reverseIndex--;
        return item;
    }

    public int nextIndex() {
        return (int) (this.reverseIndex + 1);
    }

    @Nullable
    public TModel previous() {
        checkSizes();
        TModel item = this.cursorList.getItem(this.count - this.reverseIndex);
        this.reverseIndex++;
        return item;
    }

    public int previousIndex() {
        return (int) this.reverseIndex;
    }

    public void remove() {
        throw new UnsupportedOperationException("Cursor Iterator: cannot remove from an active Iterator ");
    }

    public void set(@Nullable TModel tModel) {
        throw new UnsupportedOperationException("Cursor Iterator: cannot set on an active Iterator ");
    }

    private void checkSizes() {
        if (this.startingCount != this.cursorList.getCount()) {
            throw new ConcurrentModificationException("Cannot change Cursor data during iteration.");
        }
    }
}
