package com.raizlabs.android.dbflow.config;

import dev.ukanth.ufirewall.log.LogData_Table;
import dev.ukanth.ufirewall.log.LogDatabase;

public final class LogDatabaseLogs_Database extends DatabaseDefinition {
    public LogDatabaseLogs_Database(DatabaseHolder holder) {
        addModelAdapter(new LogData_Table(this), holder);
    }

    public final Class<?> getAssociatedDatabaseClassFile() {
        return LogDatabase.class;
    }

    public final boolean isForeignKeysSupported() {
        return false;
    }

    public final boolean isInMemory() {
        return false;
    }

    public final boolean backupEnabled() {
        return false;
    }

    public final boolean areConsistencyChecksEnabled() {
        return false;
    }

    public final int getDatabaseVersion() {
        return 1;
    }

    public final String getDatabaseName() {
        return LogDatabase.NAME;
    }
}
