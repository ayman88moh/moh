package com.raizlabs.android.dbflow.config;

import dev.ukanth.ufirewall.profiles.ProfileData_Table;
import dev.ukanth.ufirewall.profiles.ProfilesDatabase;

public final class ProfilesDatabaseprofiles_Database extends DatabaseDefinition {
    public ProfilesDatabaseprofiles_Database(DatabaseHolder holder) {
        addModelAdapter(new ProfileData_Table(this), holder);
    }

    public final Class<?> getAssociatedDatabaseClassFile() {
        return ProfilesDatabase.class;
    }

    public final boolean isForeignKeysSupported() {
        return false;
    }

    public final boolean isInMemory() {
        return false;
    }

    public final boolean backupEnabled() {
        return false;
    }

    public final boolean areConsistencyChecksEnabled() {
        return false;
    }

    public final int getDatabaseVersion() {
        return 1;
    }

    public final String getDatabaseName() {
        return ProfilesDatabase.NAME;
    }
}
