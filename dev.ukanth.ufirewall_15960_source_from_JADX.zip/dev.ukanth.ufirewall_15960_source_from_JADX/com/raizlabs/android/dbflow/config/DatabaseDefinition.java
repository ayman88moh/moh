package com.raizlabs.android.dbflow.config;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.StringUtils;
import com.raizlabs.android.dbflow.runtime.BaseTransactionManager;
import com.raizlabs.android.dbflow.runtime.ContentResolverNotifier;
import com.raizlabs.android.dbflow.runtime.ModelNotifier;
import com.raizlabs.android.dbflow.sql.migration.Migration;
import com.raizlabs.android.dbflow.structure.ModelAdapter;
import com.raizlabs.android.dbflow.structure.ModelViewAdapter;
import com.raizlabs.android.dbflow.structure.QueryModelAdapter;
import com.raizlabs.android.dbflow.structure.database.DatabaseHelperListener;
import com.raizlabs.android.dbflow.structure.database.DatabaseWrapper;
import com.raizlabs.android.dbflow.structure.database.FlowSQLiteOpenHelper;
import com.raizlabs.android.dbflow.structure.database.OpenHelper;
import com.raizlabs.android.dbflow.structure.database.transaction.DefaultTransactionManager;
import com.raizlabs.android.dbflow.structure.database.transaction.ITransaction;
import com.raizlabs.android.dbflow.structure.database.transaction.Transaction.Builder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public abstract class DatabaseDefinition {
    @Nullable
    private DatabaseConfig databaseConfig = ((DatabaseConfig) FlowManager.getConfig().databaseConfigMap().get(getAssociatedDatabaseClassFile()));
    private DatabaseHelperListener helperListener;
    private boolean isResetting = false;
    private final Map<Integer, List<Migration>> migrationMap = new HashMap();
    private final Map<Class<?>, ModelAdapter> modelAdapters = new HashMap();
    @Nullable
    private ModelNotifier modelNotifier;
    private final Map<String, Class<?>> modelTableNames = new HashMap();
    private final Map<Class<?>, ModelViewAdapter> modelViewAdapterMap = new LinkedHashMap();
    private OpenHelper openHelper;
    private final Map<Class<?>, QueryModelAdapter> queryModelAdapterMap = new LinkedHashMap();
    @NonNull
    private BaseTransactionManager transactionManager;

    public abstract boolean areConsistencyChecksEnabled();

    public abstract boolean backupEnabled();

    @NonNull
    public abstract Class<?> getAssociatedDatabaseClassFile();

    @NonNull
    public abstract String getDatabaseName();

    public abstract int getDatabaseVersion();

    public abstract boolean isForeignKeysSupported();

    public abstract boolean isInMemory();

    public DatabaseDefinition() {
        if (this.databaseConfig != null) {
            for (TableConfig tableConfig : this.databaseConfig.tableConfigMap().values()) {
                ModelAdapter modelAdapter = (ModelAdapter) this.modelAdapters.get(tableConfig.tableClass());
                if (modelAdapter != null) {
                    if (tableConfig.listModelLoader() != null) {
                        modelAdapter.setListModelLoader(tableConfig.listModelLoader());
                    }
                    if (tableConfig.singleModelLoader() != null) {
                        modelAdapter.setSingleModelLoader(tableConfig.singleModelLoader());
                    }
                    if (tableConfig.modelSaver() != null) {
                        modelAdapter.setModelSaver(tableConfig.modelSaver());
                    }
                }
            }
            this.helperListener = this.databaseConfig.helperListener();
        }
        if (this.databaseConfig == null || this.databaseConfig.transactionManagerCreator() == null) {
            this.transactionManager = new DefaultTransactionManager(this);
        } else {
            this.transactionManager = this.databaseConfig.transactionManagerCreator().createManager(this);
        }
    }

    protected <T> void addModelAdapter(ModelAdapter<T> modelAdapter, DatabaseHolder holder) {
        holder.putDatabaseForTable(modelAdapter.getModelClass(), this);
        this.modelTableNames.put(modelAdapter.getTableName(), modelAdapter.getModelClass());
        this.modelAdapters.put(modelAdapter.getModelClass(), modelAdapter);
    }

    protected <T> void addModelViewAdapter(ModelViewAdapter<T> modelViewAdapter, DatabaseHolder holder) {
        holder.putDatabaseForTable(modelViewAdapter.getModelClass(), this);
        this.modelViewAdapterMap.put(modelViewAdapter.getModelClass(), modelViewAdapter);
    }

    protected <T> void addQueryModelAdapter(QueryModelAdapter<T> queryModelAdapter, DatabaseHolder holder) {
        holder.putDatabaseForTable(queryModelAdapter.getModelClass(), this);
        this.queryModelAdapterMap.put(queryModelAdapter.getModelClass(), queryModelAdapter);
    }

    protected void addMigration(int version, Migration migration) {
        List<Migration> list = (List) this.migrationMap.get(Integer.valueOf(version));
        if (list == null) {
            list = new ArrayList();
            this.migrationMap.put(Integer.valueOf(version), list);
        }
        list.add(migration);
    }

    @NonNull
    public List<Class<?>> getModelClasses() {
        return new ArrayList(this.modelAdapters.keySet());
    }

    @NonNull
    public BaseTransactionManager getTransactionManager() {
        return this.transactionManager;
    }

    @NonNull
    public List<ModelAdapter> getModelAdapters() {
        return new ArrayList(this.modelAdapters.values());
    }

    @Nullable
    public <T> ModelAdapter<T> getModelAdapterForTable(Class<T> table) {
        return (ModelAdapter) this.modelAdapters.get(table);
    }

    @Nullable
    public Class<?> getModelClassForName(String tableName) {
        return (Class) this.modelTableNames.get(tableName);
    }

    @NonNull
    public List<Class<?>> getModelViews() {
        return new ArrayList(this.modelViewAdapterMap.keySet());
    }

    @Nullable
    public <T> ModelViewAdapter<T> getModelViewAdapterForTable(Class<T> table) {
        return (ModelViewAdapter) this.modelViewAdapterMap.get(table);
    }

    @NonNull
    public List<ModelViewAdapter> getModelViewAdapters() {
        return new ArrayList(this.modelViewAdapterMap.values());
    }

    @NonNull
    public List<QueryModelAdapter> getModelQueryAdapters() {
        return new ArrayList(this.queryModelAdapterMap.values());
    }

    @Nullable
    public <T> QueryModelAdapter<T> getQueryModelAdapterForQueryClass(Class<T> queryModel) {
        return (QueryModelAdapter) this.queryModelAdapterMap.get(queryModel);
    }

    @NonNull
    public Map<Integer, List<Migration>> getMigrations() {
        return this.migrationMap;
    }

    @NonNull
    public synchronized OpenHelper getHelper() {
        if (this.openHelper == null) {
            DatabaseConfig config = (DatabaseConfig) FlowManager.getConfig().databaseConfigMap().get(getAssociatedDatabaseClassFile());
            if (config == null || config.helperCreator() == null) {
                this.openHelper = new FlowSQLiteOpenHelper(this, this.helperListener);
            } else {
                this.openHelper = config.helperCreator().createHelper(this, this.helperListener);
            }
            this.openHelper.performRestoreFromBackup();
        }
        return this.openHelper;
    }

    @NonNull
    public DatabaseWrapper getWritableDatabase() {
        return getHelper().getDatabase();
    }

    @NonNull
    public ModelNotifier getModelNotifier() {
        if (this.modelNotifier == null) {
            DatabaseConfig config = (DatabaseConfig) FlowManager.getConfig().databaseConfigMap().get(getAssociatedDatabaseClassFile());
            if (config == null || config.modelNotifier() == null) {
                this.modelNotifier = new ContentResolverNotifier();
            } else {
                this.modelNotifier = config.modelNotifier();
            }
        }
        return this.modelNotifier;
    }

    @NonNull
    public Builder beginTransactionAsync(@NonNull ITransaction transaction) {
        return new Builder(transaction, this);
    }

    public void executeTransaction(@NonNull ITransaction transaction) {
        DatabaseWrapper database = getWritableDatabase();
        try {
            database.beginTransaction();
            transaction.execute(database);
            database.setTransactionSuccessful();
        } finally {
            database.endTransaction();
        }
    }

    @NonNull
    public String getDatabaseFileName() {
        return getDatabaseName() + (StringUtils.isNotNullOrEmpty(getDatabaseExtensionName()) ? "." + getDatabaseExtensionName() : "");
    }

    @NonNull
    public String getDatabaseExtensionName() {
        return "db";
    }

    public void reset(@NonNull Context context) {
        if (!this.isResetting) {
            this.isResetting = true;
            getTransactionManager().stopQueue();
            getHelper().closeDB();
            for (ModelAdapter modelAdapter : this.modelAdapters.values()) {
                modelAdapter.closeInsertStatement();
                modelAdapter.closeCompiledStatement();
            }
            context.deleteDatabase(getDatabaseFileName());
            if (this.databaseConfig == null || this.databaseConfig.transactionManagerCreator() == null) {
                this.transactionManager = new DefaultTransactionManager(this);
            } else {
                this.transactionManager = this.databaseConfig.transactionManagerCreator().createManager(this);
            }
            this.openHelper = null;
            this.isResetting = false;
            getHelper().getDatabase();
        }
    }

    public void destroy(@NonNull Context context) {
        if (!this.isResetting) {
            this.isResetting = true;
            getTransactionManager().stopQueue();
            getHelper().closeDB();
            context.deleteDatabase(getDatabaseFileName());
            this.openHelper = null;
            this.isResetting = false;
        }
    }

    public boolean isDatabaseIntegrityOk() {
        return getHelper().isDatabaseIntegrityOk();
    }

    public void backupDatabase() {
        getHelper().backupDB();
    }
}
