package com.raizlabs.android.dbflow.config;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.config.FlowConfig.Builder;
import com.raizlabs.android.dbflow.config.FlowLog.Level;
import com.raizlabs.android.dbflow.converter.TypeConverter;
import com.raizlabs.android.dbflow.runtime.ModelNotifier;
import com.raizlabs.android.dbflow.runtime.TableNotifierRegister;
import com.raizlabs.android.dbflow.sql.QueryBuilder;
import com.raizlabs.android.dbflow.sql.migration.Migration;
import com.raizlabs.android.dbflow.structure.InstanceAdapter;
import com.raizlabs.android.dbflow.structure.InvalidDBConfiguration;
import com.raizlabs.android.dbflow.structure.ModelAdapter;
import com.raizlabs.android.dbflow.structure.ModelViewAdapter;
import com.raizlabs.android.dbflow.structure.QueryModelAdapter;
import com.raizlabs.android.dbflow.structure.RetrievalAdapter;
import com.raizlabs.android.dbflow.structure.database.DatabaseWrapper;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class FlowManager {
    private static final String DEFAULT_DATABASE_HOLDER_CLASSNAME = (DEFAULT_DATABASE_HOLDER_PACKAGE_NAME + "." + DEFAULT_DATABASE_HOLDER_NAME);
    private static final String DEFAULT_DATABASE_HOLDER_NAME = "GeneratedDatabaseHolder";
    private static final String DEFAULT_DATABASE_HOLDER_PACKAGE_NAME = FlowManager.class.getPackage().getName();
    static FlowConfig config;
    private static GlobalDatabaseHolder globalDatabaseHolder = new GlobalDatabaseHolder();
    private static HashSet<Class<? extends DatabaseHolder>> loadedModules = new HashSet();

    public static class ModuleNotFoundException extends RuntimeException {
        public ModuleNotFoundException(String detailMessage) {
            super(detailMessage);
        }

        public ModuleNotFoundException(String detailMessage, Throwable throwable) {
            super(detailMessage, throwable);
        }

        public ModuleNotFoundException(Throwable throwable) {
            super(throwable);
        }
    }

    private static class GlobalDatabaseHolder extends DatabaseHolder {
        private boolean initialized;

        private GlobalDatabaseHolder() {
            this.initialized = false;
        }

        public void add(DatabaseHolder holder) {
            this.databaseDefinitionMap.putAll(holder.databaseDefinitionMap);
            this.databaseNameMap.putAll(holder.databaseNameMap);
            this.typeConverters.putAll(holder.typeConverters);
            this.databaseClassLookupMap.putAll(holder.databaseClassLookupMap);
            this.initialized = true;
        }

        public boolean isInitialized() {
            return this.initialized;
        }
    }

    @NonNull
    public static String getTableName(Class<?> table) {
        ModelAdapter modelAdapter = getModelAdapterOrNull(table);
        if (modelAdapter != null) {
            return modelAdapter.getTableName();
        }
        ModelViewAdapter modelViewAdapter = getModelViewAdapterOrNull(table);
        if (modelViewAdapter != null) {
            return modelViewAdapter.getViewName();
        }
        throwCannotFindAdapter("ModelAdapter/ModelViewAdapter", table);
        return null;
    }

    public static Class<?> getTableClassForName(String databaseName, String tableName) {
        DatabaseDefinition databaseDefinition = getDatabase(databaseName);
        Class<?> modelClass = databaseDefinition.getModelClassForName(tableName);
        if (modelClass == null) {
            modelClass = databaseDefinition.getModelClassForName(QueryBuilder.quote(tableName));
            if (modelClass == null) {
                throw new IllegalArgumentException(String.format("The specified table %1s was not found. Did you forget to add the @Table annotation and point it to %1s?", new Object[]{tableName, databaseName}));
            }
        }
        return modelClass;
    }

    @NonNull
    public static DatabaseDefinition getDatabaseForTable(Class<?> table) {
        checkDatabaseHolder();
        DatabaseDefinition databaseDefinition = globalDatabaseHolder.getDatabaseForTable(table);
        if (databaseDefinition != null) {
            return databaseDefinition;
        }
        throw new InvalidDBConfiguration("Model object: " + table.getName() + " is not registered with a Database. Did you forget an annotation?");
    }

    @NonNull
    public static DatabaseDefinition getDatabase(Class<?> databaseClass) {
        checkDatabaseHolder();
        DatabaseDefinition databaseDefinition = globalDatabaseHolder.getDatabase((Class) databaseClass);
        if (databaseDefinition != null) {
            return databaseDefinition;
        }
        throw new InvalidDBConfiguration("Database: " + databaseClass.getName() + " is not a registered Database. Did you forget the @Database annotation?");
    }

    @NonNull
    public static DatabaseWrapper getWritableDatabaseForTable(Class<?> table) {
        return getDatabaseForTable(table).getWritableDatabase();
    }

    @NonNull
    public static DatabaseDefinition getDatabase(String databaseName) {
        checkDatabaseHolder();
        DatabaseDefinition database = globalDatabaseHolder.getDatabase(databaseName);
        if (database != null) {
            return database;
        }
        throw new InvalidDBConfiguration("The specified database" + databaseName + " was not found. Did you forget the @Database annotation?");
    }

    @NonNull
    public static DatabaseWrapper getWritableDatabase(String databaseName) {
        return getDatabase(databaseName).getWritableDatabase();
    }

    @NonNull
    public static DatabaseWrapper getWritableDatabase(Class<?> databaseClass) {
        return getDatabase((Class) databaseClass).getWritableDatabase();
    }

    public static void initModule(Class<? extends DatabaseHolder> generatedClassName) {
        loadDatabaseHolder(generatedClassName);
    }

    public static FlowConfig getConfig() {
        if (config != null) {
            return config;
        }
        throw new IllegalStateException("Configuration is not initialized. Please call init(FlowConfig) in your application class.");
    }

    protected static void loadDatabaseHolder(Class<? extends DatabaseHolder> holderClass) {
        if (!loadedModules.contains(holderClass)) {
            try {
                DatabaseHolder dbHolder = (DatabaseHolder) holderClass.newInstance();
                if (dbHolder != null) {
                    globalDatabaseHolder.add(dbHolder);
                    loadedModules.add(holderClass);
                }
            } catch (Throwable e) {
                e.printStackTrace();
                ModuleNotFoundException moduleNotFoundException = new ModuleNotFoundException("Cannot load " + holderClass, e);
            }
        }
    }

    public static void reset() {
        for (Entry<Class<?>, DatabaseDefinition> value : globalDatabaseHolder.databaseClassLookupMap.entrySet()) {
            ((DatabaseDefinition) value.getValue()).reset(getContext());
        }
        globalDatabaseHolder.reset();
        loadedModules.clear();
    }

    @NonNull
    public static Context getContext() {
        if (config != null) {
            return config.getContext();
        }
        throw new IllegalStateException("You must provide a valid FlowConfig instance. We recommend calling init() in your application class.");
    }

    public static void init(@NonNull Context context) {
        init(new Builder(context).build());
    }

    public static void init(@NonNull FlowConfig flowConfig) {
        config = flowConfig;
        try {
            loadDatabaseHolder(Class.forName(DEFAULT_DATABASE_HOLDER_CLASSNAME));
        } catch (ModuleNotFoundException e) {
            FlowLog.log(Level.W, e.getMessage());
        } catch (ClassNotFoundException e2) {
            FlowLog.log(Level.W, "Could not find the default GeneratedDatabaseHolder");
        }
        if (!(flowConfig.databaseHolders() == null || flowConfig.databaseHolders().isEmpty())) {
            for (Class<? extends DatabaseHolder> holder : flowConfig.databaseHolders()) {
                loadDatabaseHolder(holder);
            }
        }
        if (flowConfig.openDatabasesOnInit()) {
            for (DatabaseDefinition databaseDefinition : globalDatabaseHolder.getDatabaseDefinitions()) {
                databaseDefinition.getWritableDatabase();
            }
        }
    }

    public static TypeConverter getTypeConverterForClass(Class<?> objectClass) {
        checkDatabaseHolder();
        return globalDatabaseHolder.getTypeConverterForClass(objectClass);
    }

    public static synchronized void destroy() {
        synchronized (FlowManager.class) {
            for (Entry<Class<?>, DatabaseDefinition> value : globalDatabaseHolder.databaseClassLookupMap.entrySet()) {
                ((DatabaseDefinition) value.getValue()).destroy(getContext());
            }
            config = null;
            globalDatabaseHolder = new GlobalDatabaseHolder();
            loadedModules.clear();
        }
    }

    @NonNull
    public static <TModel> InstanceAdapter<TModel> getInstanceAdapter(Class<TModel> modelClass) {
        InstanceAdapter internalAdapter = getModelAdapterOrNull(modelClass);
        if (internalAdapter == null) {
            internalAdapter = getModelViewAdapterOrNull(modelClass);
            if (internalAdapter == null) {
                internalAdapter = getQueryModelAdapterOrNull(modelClass);
            }
        }
        if (internalAdapter == null) {
            throwCannotFindAdapter("InstanceAdapter", modelClass);
        }
        return internalAdapter;
    }

    @NonNull
    public static <TModel> RetrievalAdapter<TModel> getRetrievalAdapter(Class<TModel> modelClass) {
        RetrievalAdapter<TModel> retrievalAdapter = getModelAdapterOrNull(modelClass);
        if (retrievalAdapter == null) {
            retrievalAdapter = getModelViewAdapterOrNull(modelClass);
            if (retrievalAdapter == null) {
                retrievalAdapter = getQueryModelAdapterOrNull(modelClass);
            }
        }
        if (retrievalAdapter == null) {
            throwCannotFindAdapter("RetrievalAdapter", modelClass);
        }
        return retrievalAdapter;
    }

    @NonNull
    public static <TModel> ModelAdapter<TModel> getModelAdapter(Class<TModel> modelClass) {
        ModelAdapter modelAdapter = getModelAdapterOrNull(modelClass);
        if (modelAdapter == null) {
            throwCannotFindAdapter("ModelAdapter", modelClass);
        }
        return modelAdapter;
    }

    @NonNull
    public static <TModelView> ModelViewAdapter<TModelView> getModelViewAdapter(Class<TModelView> modelViewClass) {
        ModelViewAdapter modelViewAdapter = getModelViewAdapterOrNull(modelViewClass);
        if (modelViewAdapter == null) {
            throwCannotFindAdapter("ModelViewAdapter", modelViewClass);
        }
        return modelViewAdapter;
    }

    @NonNull
    public static <TQueryModel> QueryModelAdapter<TQueryModel> getQueryModelAdapter(Class<TQueryModel> queryModelClass) {
        QueryModelAdapter queryModelAdapter = getQueryModelAdapterOrNull(queryModelClass);
        if (queryModelAdapter == null) {
            throwCannotFindAdapter("QueryModelAdapter", queryModelClass);
        }
        return queryModelAdapter;
    }

    @NonNull
    public static ModelNotifier getModelNotifierForTable(Class<?> table) {
        return getDatabaseForTable(table).getModelNotifier();
    }

    @NonNull
    public static TableNotifierRegister newRegisterForTable(Class<?> table) {
        return getModelNotifierForTable(table).newRegister();
    }

    @Nullable
    private static <T> ModelAdapter<T> getModelAdapterOrNull(Class<T> modelClass) {
        return getDatabaseForTable(modelClass).getModelAdapterForTable(modelClass);
    }

    @Nullable
    private static <T> ModelViewAdapter<T> getModelViewAdapterOrNull(Class<T> modelClass) {
        return getDatabaseForTable(modelClass).getModelViewAdapterForTable(modelClass);
    }

    @Nullable
    private static <T> QueryModelAdapter<T> getQueryModelAdapterOrNull(Class<T> modelClass) {
        return getDatabaseForTable(modelClass).getQueryModelAdapterForQueryClass(modelClass);
    }

    static Map<Integer, List<Migration>> getMigrations(String databaseName) {
        return getDatabase(databaseName).getMigrations();
    }

    public static boolean isDatabaseIntegrityOk(String databaseName) {
        return getDatabase(databaseName).getHelper().isDatabaseIntegrityOk();
    }

    private static void throwCannotFindAdapter(String type, Class<?> clazz) {
        throw new IllegalArgumentException("Cannot find " + type + " for " + clazz + ". Ensure the class is annotated with proper annotation.");
    }

    private static void checkDatabaseHolder() {
        if (!globalDatabaseHolder.isInitialized()) {
            throw new IllegalStateException("The global database holder is not initialized. Ensure you call FlowManager.init() before accessing the database.");
        }
    }
}
