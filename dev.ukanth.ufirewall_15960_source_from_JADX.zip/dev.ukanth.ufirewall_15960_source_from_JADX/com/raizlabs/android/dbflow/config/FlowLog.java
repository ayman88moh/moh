package com.raizlabs.android.dbflow.config;

import android.os.Build.VERSION;
import android.util.Log;

public class FlowLog {
    public static final String TAG = FlowLog.class.getSimpleName();
    private static Level level = Level.E;

    public enum Level {
        V {
            void call(String tag, String message, Throwable throwable) {
                Log.v(tag, message, throwable);
            }
        },
        D {
            void call(String tag, String message, Throwable throwable) {
                Log.d(tag, message, throwable);
            }
        },
        I {
            void call(String tag, String message, Throwable throwable) {
                Log.i(tag, message, throwable);
            }
        },
        W {
            void call(String tag, String message, Throwable throwable) {
                Log.w(tag, message, throwable);
            }
        },
        E {
            void call(String tag, String message, Throwable throwable) {
                Log.e(tag, message, throwable);
            }
        },
        WTF {
            void call(String tag, String message, Throwable throwable) {
                if (VERSION.SDK_INT >= 8) {
                    Log.wtf(tag, message, throwable);
                } else {
                    Log.e(tag, "!!!!!!!!*******" + message + "********!!!!!!", throwable);
                }
            }
        };

        abstract void call(String str, String str2, Throwable th);
    }

    public static void setMinimumLoggingLevel(Level level) {
        level = level;
    }

    public static void log(Level level, String message) {
        log(level, message, null);
    }

    public static void log(Level level, String message, Throwable throwable) {
        log(level, TAG, message, throwable);
    }

    public static void log(Level level, String tag, String message, Throwable throwable) {
        if (isEnabled(level)) {
            level.call(tag, message, throwable);
        }
    }

    public static boolean isEnabled(Level level) {
        return level.ordinal() >= level.ordinal();
    }

    public static void logError(Throwable throwable) {
        log(Level.E, throwable);
    }

    public static void log(Level level, Throwable throwable) {
        log(level, TAG, "", throwable);
    }
}
