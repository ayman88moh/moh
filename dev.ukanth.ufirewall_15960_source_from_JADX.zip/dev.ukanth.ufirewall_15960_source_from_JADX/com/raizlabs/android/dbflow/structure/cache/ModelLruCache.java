package com.raizlabs.android.dbflow.structure.cache;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

public class ModelLruCache<TModel> extends ModelCache<TModel, LruCache<Long, TModel>> {
    public static <TModel> ModelLruCache<TModel> newInstance(int size) {
        if (size <= 0) {
            size = 25;
        }
        return new ModelLruCache(size);
    }

    protected ModelLruCache(int size) {
        super(new LruCache(size));
    }

    public void addModel(@Nullable Object id, @NonNull TModel model) {
        if (id instanceof Number) {
            synchronized (((LruCache) getCache())) {
                ((LruCache) getCache()).put(Long.valueOf(((Number) id).longValue()), model);
            }
            return;
        }
        throw new IllegalArgumentException("A ModelLruCache must use an id that can cast toa Number to convert it into a long");
    }

    public TModel removeModel(@NonNull Object id) {
        if (id instanceof Number) {
            TModel model;
            synchronized (((LruCache) getCache())) {
                model = ((LruCache) getCache()).remove(Long.valueOf(((Number) id).longValue()));
            }
            return model;
        }
        throw new IllegalArgumentException("A ModelLruCache uses an id that can cast toa Number to convert it into a long");
    }

    public void clear() {
        synchronized (((LruCache) getCache())) {
            ((LruCache) getCache()).evictAll();
        }
    }

    public void setCacheSize(int size) {
        ((LruCache) getCache()).resize(size);
    }

    public TModel get(@Nullable Object id) {
        if (id instanceof Number) {
            return ((LruCache) getCache()).get(Long.valueOf(((Number) id).longValue()));
        }
        throw new IllegalArgumentException("A ModelLruCache must use an id that can cast toa Number to convert it into a long");
    }
}
