package com.raizlabs.android.dbflow.structure;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.sql.BaseAsyncObject;
import com.raizlabs.android.dbflow.structure.database.DatabaseWrapper;
import com.raizlabs.android.dbflow.structure.database.transaction.ProcessModelTransaction.Builder;
import com.raizlabs.android.dbflow.structure.database.transaction.ProcessModelTransaction.ProcessModel;
import com.raizlabs.android.dbflow.structure.database.transaction.Transaction;
import java.lang.ref.WeakReference;

public class AsyncModel<TModel> extends BaseAsyncObject<AsyncModel<TModel>> implements Model {
    private final TModel model;
    private ModelAdapter<TModel> modelAdapter;
    private transient WeakReference<OnModelChangedListener<TModel>> onModelChangedListener;

    public interface OnModelChangedListener<T> {
        void onModelChanged(@NonNull T t);
    }

    class C05081 implements ProcessModel<TModel> {
        C05081() {
        }

        public void processModel(TModel model, DatabaseWrapper wrapper) {
            AsyncModel.this.getModelAdapter().save(model, wrapper);
        }
    }

    class C05092 implements ProcessModel<TModel> {
        C05092() {
        }

        public void processModel(TModel model, DatabaseWrapper wrapper) {
            AsyncModel.this.getModelAdapter().delete(model, wrapper);
        }
    }

    class C05103 implements ProcessModel<TModel> {
        C05103() {
        }

        public void processModel(TModel model, DatabaseWrapper wrapper) {
            AsyncModel.this.getModelAdapter().update(model, wrapper);
        }
    }

    class C05114 implements ProcessModel<TModel> {
        C05114() {
        }

        public void processModel(TModel model, DatabaseWrapper wrapper) {
            AsyncModel.this.getModelAdapter().insert(model, wrapper);
        }
    }

    class C05125 implements ProcessModel<TModel> {
        C05125() {
        }

        public void processModel(TModel model, DatabaseWrapper wrapper) {
            AsyncModel.this.getModelAdapter().load(model, wrapper);
        }
    }

    public AsyncModel(@NonNull TModel referenceModel) {
        super(referenceModel.getClass());
        this.model = referenceModel;
    }

    public AsyncModel<TModel> withListener(@Nullable OnModelChangedListener<TModel> onModelChangedListener) {
        this.onModelChangedListener = new WeakReference(onModelChangedListener);
        return this;
    }

    private ModelAdapter<TModel> getModelAdapter() {
        if (this.modelAdapter == null) {
            this.modelAdapter = FlowManager.getModelAdapter(this.model.getClass());
        }
        return this.modelAdapter;
    }

    public boolean save(@NonNull DatabaseWrapper wrapper) {
        return save();
    }

    public boolean save() {
        executeTransaction(new Builder(new C05081()).add(this.model).build());
        return false;
    }

    public boolean delete(@NonNull DatabaseWrapper wrapper) {
        return delete();
    }

    public boolean delete() {
        executeTransaction(new Builder(new C05092()).add(this.model).build());
        return false;
    }

    public boolean update(@NonNull DatabaseWrapper wrapper) {
        return update();
    }

    public boolean update() {
        executeTransaction(new Builder(new C05103()).add(this.model).build());
        return false;
    }

    public long insert(DatabaseWrapper wrapper) {
        return insert();
    }

    public long insert() {
        executeTransaction(new Builder(new C05114()).add(this.model).build());
        return -1;
    }

    public void load(@NonNull DatabaseWrapper wrapper) {
        load();
    }

    public void load() {
        executeTransaction(new Builder(new C05125()).add(this.model).build());
    }

    public boolean exists(@NonNull DatabaseWrapper wrapper) {
        return exists();
    }

    public boolean exists() {
        return getModelAdapter().exists(this.model);
    }

    @NonNull
    public AsyncModel<? extends Model> async() {
        return this;
    }

    protected void onSuccess(@NonNull Transaction transaction) {
        if (this.onModelChangedListener != null && this.onModelChangedListener.get() != null) {
            ((OnModelChangedListener) this.onModelChangedListener.get()).onModelChanged(this.model);
        }
    }
}
