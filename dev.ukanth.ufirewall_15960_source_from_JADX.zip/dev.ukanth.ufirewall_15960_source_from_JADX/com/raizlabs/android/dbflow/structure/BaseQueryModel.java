package com.raizlabs.android.dbflow.structure;

import android.support.annotation.NonNull;
import com.raizlabs.android.dbflow.structure.database.DatabaseWrapper;

public class BaseQueryModel extends NoModificationModel {
    public /* bridge */ /* synthetic */ RetrievalAdapter getRetrievalAdapter() {
        return super.getRetrievalAdapter();
    }

    public /* bridge */ /* synthetic */ void load() {
        super.load();
    }

    public /* bridge */ /* synthetic */ void load(@NonNull DatabaseWrapper databaseWrapper) {
        super.load(databaseWrapper);
    }

    public boolean exists() {
        throw new InvalidSqlViewOperationException("Query " + getClass().getName() + " does not exist as a table.It's a convenient representation of a complex SQLite query.");
    }

    public boolean exists(@NonNull DatabaseWrapper databaseWrapper) {
        return exists();
    }
}
