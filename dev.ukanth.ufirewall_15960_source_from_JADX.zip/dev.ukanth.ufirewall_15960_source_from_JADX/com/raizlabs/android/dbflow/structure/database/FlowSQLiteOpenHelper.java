package com.raizlabs.android.dbflow.structure.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.config.DatabaseDefinition;
import com.raizlabs.android.dbflow.config.FlowManager;

public class FlowSQLiteOpenHelper extends SQLiteOpenHelper implements OpenHelper {
    private AndroidDatabase androidDatabase;
    private DatabaseHelperDelegate databaseHelperDelegate;

    private class BackupHelper extends SQLiteOpenHelper implements OpenHelper {
        private AndroidDatabase androidDatabase;
        private final BaseDatabaseHelper baseDatabaseHelper;

        public BackupHelper(Context context, String name, int version, DatabaseDefinition databaseDefinition) {
            super(context, name, null, version);
            this.baseDatabaseHelper = new BaseDatabaseHelper(databaseDefinition);
        }

        @NonNull
        public DatabaseWrapper getDatabase() {
            if (this.androidDatabase == null) {
                this.androidDatabase = AndroidDatabase.from(getWritableDatabase());
            }
            return this.androidDatabase;
        }

        public void performRestoreFromBackup() {
        }

        @Nullable
        public DatabaseHelperDelegate getDelegate() {
            return null;
        }

        public boolean isDatabaseIntegrityOk() {
            return false;
        }

        public void backupDB() {
        }

        public void setDatabaseListener(@Nullable DatabaseHelperListener helperListener) {
        }

        public void onCreate(SQLiteDatabase db) {
            this.baseDatabaseHelper.onCreate(AndroidDatabase.from(db));
        }

        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            this.baseDatabaseHelper.onUpgrade(AndroidDatabase.from(db), oldVersion, newVersion);
        }

        public void onOpen(SQLiteDatabase db) {
            this.baseDatabaseHelper.onOpen(AndroidDatabase.from(db));
        }

        public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            this.baseDatabaseHelper.onDowngrade(AndroidDatabase.from(db), oldVersion, newVersion);
        }

        public void closeDB() {
        }
    }

    public FlowSQLiteOpenHelper(@NonNull DatabaseDefinition databaseDefinition, @NonNull DatabaseHelperListener listener) {
        super(FlowManager.getContext(), databaseDefinition.isInMemory() ? null : databaseDefinition.getDatabaseFileName(), null, databaseDefinition.getDatabaseVersion());
        OpenHelper backupHelper = null;
        if (databaseDefinition.backupEnabled()) {
            backupHelper = new BackupHelper(FlowManager.getContext(), DatabaseHelperDelegate.getTempDbFileName(databaseDefinition), databaseDefinition.getDatabaseVersion(), databaseDefinition);
        }
        this.databaseHelperDelegate = new DatabaseHelperDelegate(listener, databaseDefinition, backupHelper);
    }

    public void performRestoreFromBackup() {
        this.databaseHelperDelegate.performRestoreFromBackup();
    }

    @Nullable
    public DatabaseHelperDelegate getDelegate() {
        return this.databaseHelperDelegate;
    }

    public boolean isDatabaseIntegrityOk() {
        return this.databaseHelperDelegate.isDatabaseIntegrityOk();
    }

    public void backupDB() {
        this.databaseHelperDelegate.backupDB();
    }

    @NonNull
    public DatabaseWrapper getDatabase() {
        if (this.androidDatabase == null || !this.androidDatabase.getDatabase().isOpen()) {
            this.androidDatabase = AndroidDatabase.from(getWritableDatabase());
        }
        return this.androidDatabase;
    }

    public void setDatabaseListener(@Nullable DatabaseHelperListener listener) {
        this.databaseHelperDelegate.setDatabaseHelperListener(listener);
    }

    public void onCreate(@NonNull SQLiteDatabase db) {
        this.databaseHelperDelegate.onCreate(AndroidDatabase.from(db));
    }

    public void onUpgrade(@NonNull SQLiteDatabase db, int oldVersion, int newVersion) {
        this.databaseHelperDelegate.onUpgrade(AndroidDatabase.from(db), oldVersion, newVersion);
    }

    public void onOpen(@NonNull SQLiteDatabase db) {
        this.databaseHelperDelegate.onOpen(AndroidDatabase.from(db));
    }

    public void onDowngrade(@NonNull SQLiteDatabase db, int oldVersion, int newVersion) {
        this.databaseHelperDelegate.onDowngrade(AndroidDatabase.from(db), oldVersion, newVersion);
    }

    public void closeDB() {
        getDatabase();
        this.androidDatabase.getDatabase().close();
    }
}
