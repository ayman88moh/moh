package com.raizlabs.android.dbflow.structure.database;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.runtime.NotifyDistributor;
import com.raizlabs.android.dbflow.sql.language.BaseQueriable;

public class DatabaseStatementWrapper<TModel> extends BaseDatabaseStatement {
    @NonNull
    private final DatabaseStatement databaseStatement;
    private final BaseQueriable<TModel> modelQueriable;

    public DatabaseStatementWrapper(@NonNull DatabaseStatement databaseStatement, @NonNull BaseQueriable<TModel> modelQueriable) {
        this.databaseStatement = databaseStatement;
        this.modelQueriable = modelQueriable;
    }

    public long executeUpdateDelete() {
        long affected = this.databaseStatement.executeUpdateDelete();
        if (affected > 0) {
            NotifyDistributor.get().notifyTableChanged(this.modelQueriable.getTable(), this.modelQueriable.getPrimaryAction());
        }
        return affected;
    }

    public void execute() {
        this.databaseStatement.execute();
    }

    public void close() {
        this.databaseStatement.close();
    }

    public long simpleQueryForLong() {
        return this.databaseStatement.simpleQueryForLong();
    }

    @Nullable
    public String simpleQueryForString() {
        return this.databaseStatement.simpleQueryForString();
    }

    public long executeInsert() {
        long affected = this.databaseStatement.executeInsert();
        if (affected > 0) {
            NotifyDistributor.get().notifyTableChanged(this.modelQueriable.getTable(), this.modelQueriable.getPrimaryAction());
        }
        return affected;
    }

    public void bindString(int index, String s) {
        this.databaseStatement.bindString(index, s);
    }

    public void bindNull(int index) {
        this.databaseStatement.bindNull(index);
    }

    public void bindLong(int index, long aLong) {
        this.databaseStatement.bindLong(index, aLong);
    }

    public void bindDouble(int index, double aDouble) {
        this.databaseStatement.bindDouble(index, aDouble);
    }

    public void bindBlob(int index, byte[] bytes) {
        this.databaseStatement.bindBlob(index, bytes);
    }
}
