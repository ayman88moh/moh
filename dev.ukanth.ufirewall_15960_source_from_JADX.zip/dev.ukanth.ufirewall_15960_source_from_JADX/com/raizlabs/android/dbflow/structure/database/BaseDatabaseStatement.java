package com.raizlabs.android.dbflow.structure.database;

import android.support.annotation.Nullable;

public abstract class BaseDatabaseStatement implements DatabaseStatement {
    public void bindStringOrNull(int index, @Nullable String s) {
        if (s != null) {
            bindString(index, s);
        } else {
            bindNull(index);
        }
    }

    public void bindNumber(int index, @Nullable Number number) {
        bindNumberOrNull(index, number);
    }

    public void bindNumberOrNull(int index, @Nullable Number number) {
        if (number != null) {
            bindLong(index, number.longValue());
        } else {
            bindNull(index);
        }
    }

    public void bindDoubleOrNull(int index, @Nullable Double aDouble) {
        if (aDouble != null) {
            bindDouble(index, aDouble.doubleValue());
        } else {
            bindNull(index);
        }
    }

    public void bindFloatOrNull(int index, @Nullable Float aFloat) {
        if (aFloat != null) {
            bindDouble(index, (double) aFloat.floatValue());
        } else {
            bindNull(index);
        }
    }

    public void bindBlobOrNull(int index, @Nullable byte[] bytes) {
        if (bytes != null) {
            bindBlob(index, bytes);
        } else {
            bindNull(index);
        }
    }
}
