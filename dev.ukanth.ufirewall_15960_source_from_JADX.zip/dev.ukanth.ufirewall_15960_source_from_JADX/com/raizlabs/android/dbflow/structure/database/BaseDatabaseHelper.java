package com.raizlabs.android.dbflow.structure.database;

import android.database.sqlite.SQLiteException;
import android.support.annotation.NonNull;
import com.raizlabs.android.dbflow.config.DatabaseDefinition;
import com.raizlabs.android.dbflow.config.FlowLog;
import com.raizlabs.android.dbflow.config.FlowLog.Level;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.config.NaturalOrderComparator;
import com.raizlabs.android.dbflow.sql.QueryBuilder;
import com.raizlabs.android.dbflow.sql.language.Operator.Operation;
import com.raizlabs.android.dbflow.sql.migration.Migration;
import com.raizlabs.android.dbflow.structure.ModelAdapter;
import com.raizlabs.android.dbflow.structure.ModelViewAdapter;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BaseDatabaseHelper {
    public static final String MIGRATION_PATH = "migrations";
    private final DatabaseDefinition databaseDefinition;

    public BaseDatabaseHelper(@NonNull DatabaseDefinition databaseDefinition) {
        this.databaseDefinition = databaseDefinition;
    }

    @NonNull
    public DatabaseDefinition getDatabaseDefinition() {
        return this.databaseDefinition;
    }

    public void onCreate(@NonNull DatabaseWrapper db) {
        checkForeignKeySupport(db);
        executeCreations(db);
        executeMigrations(db, -1, db.getVersion());
    }

    public void onUpgrade(@NonNull DatabaseWrapper db, int oldVersion, int newVersion) {
        checkForeignKeySupport(db);
        executeCreations(db);
        executeMigrations(db, oldVersion, newVersion);
    }

    public void onOpen(@NonNull DatabaseWrapper db) {
        checkForeignKeySupport(db);
    }

    public void onDowngrade(@NonNull DatabaseWrapper db, int oldVersion, int newVersion) {
        checkForeignKeySupport(db);
    }

    protected void checkForeignKeySupport(@NonNull DatabaseWrapper database) {
        if (this.databaseDefinition.isForeignKeysSupported()) {
            database.execSQL("PRAGMA foreign_keys=ON;");
            FlowLog.log(Level.I, "Foreign Keys supported. Enabling foreign key features.");
        }
    }

    protected void executeCreations(@NonNull DatabaseWrapper database) {
        try {
            database.beginTransaction();
            for (ModelAdapter modelAdapter : this.databaseDefinition.getModelAdapters()) {
                database.execSQL(modelAdapter.getCreationQuery());
            }
            for (ModelViewAdapter modelView : this.databaseDefinition.getModelViewAdapters()) {
                try {
                    database.execSQL(new QueryBuilder().append("CREATE VIEW IF NOT EXISTS").appendSpaceSeparated(modelView.getViewName()).append("AS ").append(modelView.getCreationQuery()).getQuery());
                } catch (SQLiteException e) {
                    FlowLog.logError(e);
                }
            }
            database.setTransactionSuccessful();
            database.endTransaction();
        } catch (SQLiteException e2) {
            FlowLog.logError(e2);
        } catch (Throwable th) {
            database.endTransaction();
        }
    }

    protected void executeMigrations(@NonNull DatabaseWrapper db, int oldVersion, int newVersion) {
        try {
            List<String> files = Arrays.asList(FlowManager.getContext().getAssets().list("migrations/" + this.databaseDefinition.getDatabaseName()));
            Collections.sort(files, new NaturalOrderComparator());
            Map<Integer, List<String>> migrationFileMap = new HashMap();
            for (String file : files) {
                try {
                    Integer version = Integer.valueOf(file.replace(".sql", ""));
                    List<String> fileList = (List) migrationFileMap.get(version);
                    if (fileList == null) {
                        fileList = new ArrayList();
                        migrationFileMap.put(version, fileList);
                    }
                    fileList.add(file);
                } catch (NumberFormatException e) {
                    FlowLog.log(Level.W, "Skipping invalidly named file: " + file, e);
                }
            }
            Map<Integer, List<Migration>> migrationMap = this.databaseDefinition.getMigrations();
            int curVersion = oldVersion + 1;
            db.beginTransaction();
            for (int i = curVersion; i <= newVersion; i++) {
                List<String> migrationFiles = (List) migrationFileMap.get(Integer.valueOf(i));
                if (migrationFiles != null) {
                    for (String migrationFile : migrationFiles) {
                        executeSqlScript(db, migrationFile);
                        FlowLog.log(Level.I, migrationFile + " executed successfully.");
                    }
                }
                List<Migration> migrationsList = (List) migrationMap.get(Integer.valueOf(i));
                if (migrationsList != null) {
                    for (Migration migration : migrationsList) {
                        migration.onPreMigrate();
                        migration.migrate(db);
                        migration.onPostMigrate();
                        FlowLog.log(Level.I, migration.getClass() + " executed successfully.");
                    }
                }
            }
            db.setTransactionSuccessful();
            db.endTransaction();
        } catch (IOException e2) {
            FlowLog.log(Level.E, "Failed to execute migrations.", e2);
        } catch (Throwable th) {
            db.endTransaction();
        }
    }

    private void executeSqlScript(@NonNull DatabaseWrapper db, @NonNull String file) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(FlowManager.getContext().getAssets().open("migrations/" + getDatabaseDefinition().getDatabaseName() + Operation.DIVISION + file)));
            String querySuffix = ";";
            String queryCommentPrefix = "--";
            StringBuffer query = new StringBuffer();
            while (true) {
                String line = reader.readLine();
                if (line == null) {
                    break;
                }
                line = line.trim();
                boolean isEndOfQuery = line.endsWith(querySuffix);
                if (!line.startsWith(queryCommentPrefix)) {
                    if (isEndOfQuery) {
                        line = line.substring(0, line.length() - querySuffix.length());
                    }
                    query.append(" ").append(line);
                    if (isEndOfQuery) {
                        db.execSQL(query.toString());
                        query = new StringBuffer();
                    }
                }
            }
            String queryString = query.toString();
            if (queryString.trim().length() > 0) {
                db.execSQL(queryString);
            }
        } catch (IOException e) {
            FlowLog.log(Level.E, "Failed to execute " + file, e);
        }
    }
}
