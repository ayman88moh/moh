package com.raizlabs.android.dbflow.structure.database;

import android.database.Cursor;
import android.database.CursorWrapper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

public class FlowCursor extends CursorWrapper {
    private Cursor cursor;

    public static FlowCursor from(@NonNull Cursor cursor) {
        if (cursor instanceof FlowCursor) {
            return (FlowCursor) cursor;
        }
        return new FlowCursor(cursor);
    }

    private FlowCursor(@NonNull Cursor cursor) {
        super(cursor);
        this.cursor = cursor;
    }

    public Cursor getWrappedCursor() {
        return this.cursor;
    }

    public String getStringOrDefault(int index, String defValue) {
        if (index == -1 || this.cursor.isNull(index)) {
            return defValue;
        }
        return this.cursor.getString(index);
    }

    @Nullable
    public String getStringOrDefault(String columnName) {
        return getStringOrDefault(this.cursor.getColumnIndex(columnName));
    }

    @Nullable
    public String getStringOrDefault(int index) {
        if (index == -1 || this.cursor.isNull(index)) {
            return null;
        }
        return this.cursor.getString(index);
    }

    public String getStringOrDefault(String columnName, String defValue) {
        return getStringOrDefault(this.cursor.getColumnIndex(columnName), defValue);
    }

    public int getIntOrDefault(String columnName) {
        return getIntOrDefault(this.cursor.getColumnIndex(columnName));
    }

    public int getIntOrDefault(int index) {
        if (index == -1 || this.cursor.isNull(index)) {
            return 0;
        }
        return this.cursor.getInt(index);
    }

    public int getIntOrDefault(int index, int defValue) {
        if (index == -1 || this.cursor.isNull(index)) {
            return defValue;
        }
        return this.cursor.getInt(index);
    }

    public int getIntOrDefault(String columnName, int defValue) {
        return getIntOrDefault(this.cursor.getColumnIndex(columnName), defValue);
    }

    public Integer getIntOrDefault(int index, Integer defValue) {
        if (index == -1 || this.cursor.isNull(index)) {
            return defValue;
        }
        return Integer.valueOf(this.cursor.getInt(index));
    }

    public Integer getIntOrDefault(String columnName, Integer defValue) {
        return getIntOrDefault(this.cursor.getColumnIndex(columnName), defValue);
    }

    public double getDoubleOrDefault(int index, double defValue) {
        if (index == -1 || this.cursor.isNull(index)) {
            return defValue;
        }
        return this.cursor.getDouble(index);
    }

    public double getDoubleOrDefault(String columnName) {
        return getDoubleOrDefault(this.cursor.getColumnIndex(columnName));
    }

    public double getDoubleOrDefault(int index) {
        if (index == -1 || this.cursor.isNull(index)) {
            return 0.0d;
        }
        return this.cursor.getDouble(index);
    }

    public double getDoubleOrDefault(String columnName, double defValue) {
        return getDoubleOrDefault(this.cursor.getColumnIndex(columnName), defValue);
    }

    public Double getDoubleOrDefault(int index, Double defValue) {
        if (index == -1 || this.cursor.isNull(index)) {
            return defValue;
        }
        return Double.valueOf(this.cursor.getDouble(index));
    }

    public Double getDoubleOrDefault(String columnName, Double defValue) {
        return getDoubleOrDefault(this.cursor.getColumnIndex(columnName), defValue);
    }

    public float getFloatOrDefault(int index, float defValue) {
        if (index == -1 || this.cursor.isNull(index)) {
            return defValue;
        }
        return this.cursor.getFloat(index);
    }

    public float getFloatOrDefault(String columnName) {
        return getFloatOrDefault(this.cursor.getColumnIndex(columnName));
    }

    public float getFloatOrDefault(int index) {
        if (index == -1 || this.cursor.isNull(index)) {
            return 0.0f;
        }
        return this.cursor.getFloat(index);
    }

    public float getFloatOrDefault(String columnName, float defValue) {
        return getFloatOrDefault(this.cursor.getColumnIndex(columnName), defValue);
    }

    public Float getFloatOrDefault(int index, Float defValue) {
        if (index == -1 || this.cursor.isNull(index)) {
            return defValue;
        }
        return Float.valueOf(this.cursor.getFloat(index));
    }

    public Float getFloatOrDefault(String columnName, Float defValue) {
        return getFloatOrDefault(this.cursor.getColumnIndex(columnName), defValue);
    }

    public long getLongOrDefault(int index, long defValue) {
        if (index == -1 || this.cursor.isNull(index)) {
            return defValue;
        }
        return this.cursor.getLong(index);
    }

    public long getLongOrDefault(String columnName) {
        return getLongOrDefault(this.cursor.getColumnIndex(columnName));
    }

    public long getLongOrDefault(int index) {
        if (index == -1 || this.cursor.isNull(index)) {
            return 0;
        }
        return this.cursor.getLong(index);
    }

    public long getLongOrDefault(String columnName, long defValue) {
        return getLongOrDefault(this.cursor.getColumnIndex(columnName), defValue);
    }

    public Long getLongOrDefault(int index, Long defValue) {
        if (index == -1 || this.cursor.isNull(index)) {
            return defValue;
        }
        return Long.valueOf(this.cursor.getLong(index));
    }

    public Long getLongOrDefault(String columnName, Long defValue) {
        return getLongOrDefault(this.cursor.getColumnIndex(columnName), defValue);
    }

    public short getShortOrDefault(int index, short defValue) {
        if (index == -1 || this.cursor.isNull(index)) {
            return defValue;
        }
        return this.cursor.getShort(index);
    }

    public short getShortOrDefault(String columnName) {
        return getShortOrDefault(this.cursor.getColumnIndex(columnName));
    }

    public short getShortOrDefault(int index) {
        if (index == -1 || this.cursor.isNull(index)) {
            return (short) 0;
        }
        return this.cursor.getShort(index);
    }

    public short getShortOrDefault(String columnName, short defValue) {
        return getShortOrDefault(this.cursor.getColumnIndex(columnName), defValue);
    }

    public Short getShortOrDefault(int index, Short defValue) {
        if (index == -1 || this.cursor.isNull(index)) {
            return defValue;
        }
        return Short.valueOf(this.cursor.getShort(index));
    }

    public Short getShortOrDefault(String columnName, Short defValue) {
        return getShortOrDefault(this.cursor.getColumnIndex(columnName), defValue);
    }

    public byte[] getBlobOrDefault(int index, byte[] defValue) {
        if (index == -1 || this.cursor.isNull(index)) {
            return defValue;
        }
        return this.cursor.getBlob(index);
    }

    public byte[] getBlobOrDefault(String columnName, byte[] defValue) {
        return getBlobOrDefault(this.cursor.getColumnIndex(columnName), defValue);
    }

    public boolean getBooleanOrDefault(int index, boolean defValue) {
        if (index == -1 || this.cursor.isNull(index)) {
            return defValue;
        }
        return getBoolean(index);
    }

    public boolean getBooleanOrDefault(String columnName) {
        return getBooleanOrDefault(this.cursor.getColumnIndex(columnName));
    }

    public boolean getBooleanOrDefault(int index) {
        if (index == -1 || this.cursor.isNull(index)) {
            return false;
        }
        return getBoolean(index);
    }

    public boolean getBooleanOrDefault(String columnName, boolean defValue) {
        return getBooleanOrDefault(this.cursor.getColumnIndex(columnName), defValue);
    }

    public boolean getBoolean(int index) {
        return this.cursor.getInt(index) == 1;
    }
}
