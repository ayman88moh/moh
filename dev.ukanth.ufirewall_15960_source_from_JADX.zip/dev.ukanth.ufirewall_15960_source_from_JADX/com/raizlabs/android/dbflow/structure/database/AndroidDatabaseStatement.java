package com.raizlabs.android.dbflow.structure.database;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

public class AndroidDatabaseStatement extends BaseDatabaseStatement {
    private final SQLiteDatabase database;
    private final SQLiteStatement statement;

    public long executeUpdateDelete() {
        /* JADX: method processing error */
/*
Error: java.util.NoSuchElementException
	at java.util.HashMap$HashIterator.nextNode(HashMap.java:1431)
	at java.util.HashMap$KeyIterator.next(HashMap.java:1453)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.applyRemove(BlockFinallyExtract.java:535)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.extractFinally(BlockFinallyExtract.java:175)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.processExceptionHandler(BlockFinallyExtract.java:79)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.visit(BlockFinallyExtract.java:51)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r6 = this;
        r0 = 0;
        r3 = android.os.Build.VERSION.SDK_INT;
        r4 = 11;
        if (r3 < r4) goto L_0x0010;
    L_0x0008:
        r3 = r6.statement;
        r3 = r3.executeUpdateDelete();
        r0 = (long) r3;
    L_0x000f:
        return r0;
    L_0x0010:
        r3 = r6.statement;
        r3.execute();
        r2 = 0;
        r3 = r6.database;	 Catch:{ SQLException -> 0x003d, all -> 0x0044 }
        r4 = "SELECT changes() AS affected_row_count";	 Catch:{ SQLException -> 0x003d, all -> 0x0044 }
        r5 = 0;	 Catch:{ SQLException -> 0x003d, all -> 0x0044 }
        r2 = r3.rawQuery(r4, r5);	 Catch:{ SQLException -> 0x003d, all -> 0x0044 }
        if (r2 == 0) goto L_0x0037;	 Catch:{ SQLException -> 0x003d, all -> 0x0044 }
    L_0x0021:
        r3 = r2.getCount();	 Catch:{ SQLException -> 0x003d, all -> 0x0044 }
        if (r3 <= 0) goto L_0x0037;	 Catch:{ SQLException -> 0x003d, all -> 0x0044 }
    L_0x0027:
        r3 = r2.moveToFirst();	 Catch:{ SQLException -> 0x003d, all -> 0x0044 }
        if (r3 == 0) goto L_0x0037;	 Catch:{ SQLException -> 0x003d, all -> 0x0044 }
    L_0x002d:
        r3 = "affected_row_count";	 Catch:{ SQLException -> 0x003d, all -> 0x0044 }
        r3 = r2.getColumnIndex(r3);	 Catch:{ SQLException -> 0x003d, all -> 0x0044 }
        r0 = r2.getLong(r3);	 Catch:{ SQLException -> 0x003d, all -> 0x0044 }
    L_0x0037:
        if (r2 == 0) goto L_0x000f;
    L_0x0039:
        r2.close();
        goto L_0x000f;
    L_0x003d:
        r3 = move-exception;
        if (r2 == 0) goto L_0x000f;
    L_0x0040:
        r2.close();
        goto L_0x000f;
    L_0x0044:
        r3 = move-exception;
        if (r2 == 0) goto L_0x004a;
    L_0x0047:
        r2.close();
    L_0x004a:
        throw r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.raizlabs.android.dbflow.structure.database.AndroidDatabaseStatement.executeUpdateDelete():long");
    }

    public static AndroidDatabaseStatement from(@NonNull SQLiteStatement sqLiteStatement, @NonNull SQLiteDatabase database) {
        return new AndroidDatabaseStatement(sqLiteStatement, database);
    }

    AndroidDatabaseStatement(@NonNull SQLiteStatement statement, @NonNull SQLiteDatabase database) {
        this.statement = statement;
        this.database = database;
    }

    @NonNull
    public SQLiteStatement getStatement() {
        return this.statement;
    }

    public void execute() {
        this.statement.execute();
    }

    public void close() {
        this.statement.close();
    }

    public long simpleQueryForLong() {
        return this.statement.simpleQueryForLong();
    }

    @Nullable
    public String simpleQueryForString() {
        return this.statement.simpleQueryForString();
    }

    public long executeInsert() {
        return this.statement.executeInsert();
    }

    public void bindString(int index, String s) {
        this.statement.bindString(index, s);
    }

    public void bindNull(int index) {
        this.statement.bindNull(index);
    }

    public void bindLong(int index, long aLong) {
        this.statement.bindLong(index, aLong);
    }

    public void bindDouble(int index, double aDouble) {
        this.statement.bindDouble(index, aDouble);
    }

    public void bindBlob(int index, byte[] bytes) {
        this.statement.bindBlob(index, bytes);
    }
}
