package com.raizlabs.android.dbflow.structure.database.transaction;

import android.os.Looper;
import android.os.Process;
import android.support.annotation.NonNull;
import com.raizlabs.android.dbflow.config.FlowLog;
import com.raizlabs.android.dbflow.config.FlowLog.Level;
import java.util.Iterator;
import java.util.concurrent.LinkedBlockingQueue;

public class DefaultTransactionQueue extends Thread implements ITransactionQueue {
    private boolean isQuitting = false;
    private final LinkedBlockingQueue<Transaction> queue = new LinkedBlockingQueue();

    public DefaultTransactionQueue(String name) {
        super(name);
    }

    public void run() {
        Looper.prepare();
        Process.setThreadPriority(10);
        while (true) {
            try {
                Transaction transaction = (Transaction) this.queue.take();
                if (!this.isQuitting) {
                    transaction.executeSync();
                }
            } catch (InterruptedException e) {
                synchronized (this) {
                    if (this.isQuitting) {
                        synchronized (this.queue) {
                            this.queue.clear();
                            return;
                        }
                    }
                }
            }
        }
    }

    public void add(@NonNull Transaction runnable) {
        synchronized (this.queue) {
            if (!this.queue.contains(runnable)) {
                this.queue.add(runnable);
            }
        }
    }

    public void cancel(@NonNull Transaction runnable) {
        synchronized (this.queue) {
            if (this.queue.contains(runnable)) {
                this.queue.remove(runnable);
            }
        }
    }

    public void cancel(@NonNull String tag) {
        synchronized (this.queue) {
            Iterator<Transaction> it = this.queue.iterator();
            while (it.hasNext()) {
                Transaction next = (Transaction) it.next();
                if (next.name() != null && next.name().equals(tag)) {
                    it.remove();
                }
            }
        }
    }

    public void startIfNotAlive() {
        synchronized (this) {
            if (!isAlive()) {
                try {
                    start();
                } catch (Throwable i) {
                    FlowLog.log(Level.E, i);
                }
            }
        }
    }

    public void quit() {
        synchronized (this) {
            this.isQuitting = true;
        }
        interrupt();
    }
}
