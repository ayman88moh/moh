package com.raizlabs.android.dbflow.structure.provider;

import android.database.Cursor;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.sql.language.OperatorGroup;
import com.raizlabs.android.dbflow.structure.BaseModel;
import com.raizlabs.android.dbflow.structure.database.FlowCursor;

public abstract class BaseProviderModel extends BaseModel implements ModelProvider {
    public boolean delete() {
        return ContentUtils.delete(getDeleteUri(), this) > 0;
    }

    public boolean save() {
        int count = ContentUtils.update(getUpdateUri(), this);
        if (count == 0) {
            if (ContentUtils.insert(getInsertUri(), this) != null) {
                return true;
            }
            return false;
        } else if (count <= 0) {
            return false;
        } else {
            return true;
        }
    }

    public boolean update() {
        return ContentUtils.update(getUpdateUri(), this) > 0;
    }

    public long insert() {
        ContentUtils.insert(getInsertUri(), this);
        return 0;
    }

    public boolean exists() {
        boolean exists = false;
        Cursor cursor = ContentUtils.query(FlowManager.getContext().getContentResolver(), getQueryUri(), getModelAdapter().getPrimaryConditionClause(this), "", new String[0]);
        if (cursor != null && cursor.getCount() > 0) {
            exists = true;
        }
        if (cursor != null) {
            cursor.close();
        }
        return exists;
    }

    public void load(@NonNull OperatorGroup whereConditions, @Nullable String orderBy, String... columns) {
        FlowCursor cursor = FlowCursor.from(ContentUtils.query(FlowManager.getContext().getContentResolver(), getQueryUri(), whereConditions, orderBy, columns));
        if (cursor != null && cursor.moveToFirst()) {
            getModelAdapter().loadFromCursor(cursor, this);
            cursor.close();
        }
    }

    public void load() {
        load(getModelAdapter().getPrimaryConditionClause(this), "", new String[0]);
    }
}
