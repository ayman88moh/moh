package com.raizlabs.android.dbflow.structure.provider;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.sql.language.OperatorGroup;
import com.raizlabs.android.dbflow.structure.BaseModel;
import com.raizlabs.android.dbflow.structure.database.FlowCursor;

public abstract class BaseSyncableProviderModel extends BaseModel implements ModelProvider {
    public long insert() {
        long rowId = super.insert();
        ContentUtils.insert(getInsertUri(), this);
        return rowId;
    }

    public boolean save() {
        if (exists()) {
            if (!super.save() || ContentUtils.update(getUpdateUri(), this) <= 0) {
                return false;
            }
            return true;
        } else if (!super.save() || ContentUtils.insert(getInsertUri(), this) == null) {
            return false;
        } else {
            return true;
        }
    }

    public boolean delete() {
        return super.delete() && ContentUtils.delete(getDeleteUri(), this) > 0;
    }

    public boolean update() {
        return super.update() && ContentUtils.update(getUpdateUri(), this) > 0;
    }

    public void load(@NonNull OperatorGroup whereOperatorGroup, @Nullable String orderBy, String... columns) {
        FlowCursor cursor = FlowCursor.from(ContentUtils.query(FlowManager.getContext().getContentResolver(), getQueryUri(), whereOperatorGroup, orderBy, columns));
        if (cursor != null && cursor.moveToFirst()) {
            getModelAdapter().loadFromCursor(cursor, this);
            cursor.close();
        }
    }

    public void load() {
        load(getModelAdapter().getPrimaryConditionClause(this), "", new String[0]);
    }
}
