package com.raizlabs.android.dbflow.runtime;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.structure.BaseModel.Action;
import com.raizlabs.android.dbflow.structure.ModelAdapter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class DirectModelNotifier implements ModelNotifier {
    private static DirectModelNotifier notifier;
    private final Map<Class<?>, Set<OnModelStateChangedListener>> modelChangedListenerMap = new LinkedHashMap();
    private final TableNotifierRegister singleRegister = new DirectTableNotifierRegister();
    private final Map<Class<?>, Set<OnTableChangedListener>> tableChangedListenerMap = new LinkedHashMap();

    public interface OnModelStateChangedListener<T> {
        void onModelChanged(@NonNull T t, @NonNull Action action);
    }

    private class DirectTableNotifierRegister implements TableNotifierRegister {
        private final OnTableChangedListener internalChangeListener;
        @Nullable
        private OnTableChangedListener modelChangedListener;
        private List<Class> registeredTables;

        class C05041 implements OnTableChangedListener {
            C05041() {
            }

            public void onTableChanged(@Nullable Class<?> table, @NonNull Action action) {
                if (DirectTableNotifierRegister.this.modelChangedListener != null) {
                    DirectTableNotifierRegister.this.modelChangedListener.onTableChanged(table, action);
                }
            }
        }

        private DirectTableNotifierRegister() {
            this.registeredTables = new ArrayList();
            this.internalChangeListener = new C05041();
        }

        public <T> void register(@NonNull Class<T> tClass) {
            this.registeredTables.add(tClass);
            DirectModelNotifier.this.registerForTableChanges(tClass, this.internalChangeListener);
        }

        public <T> void unregister(@NonNull Class<T> tClass) {
            this.registeredTables.remove(tClass);
            DirectModelNotifier.this.unregisterForTableChanges(tClass, this.internalChangeListener);
        }

        public void unregisterAll() {
            for (Class table : this.registeredTables) {
                DirectModelNotifier.this.unregisterForTableChanges(table, this.internalChangeListener);
            }
            this.modelChangedListener = null;
        }

        public void setListener(@Nullable OnTableChangedListener modelChangedListener) {
            this.modelChangedListener = modelChangedListener;
        }

        public boolean isSubscribed() {
            return !this.registeredTables.isEmpty();
        }
    }

    public interface ModelChangedListener<T> extends OnModelStateChangedListener<T>, OnTableChangedListener {
    }

    @NonNull
    public static DirectModelNotifier get() {
        if (notifier == null) {
            notifier = new DirectModelNotifier();
        }
        return notifier;
    }

    private DirectModelNotifier() {
        if (notifier != null) {
            throw new IllegalStateException("Cannot instantiate more than one DirectNotifier. Use DirectNotifier.get()");
        }
    }

    public <T> void notifyModelChanged(@NonNull T model, @NonNull ModelAdapter<T> adapter, @NonNull Action action) {
        Set<OnModelStateChangedListener> listeners = (Set) this.modelChangedListenerMap.get(adapter.getModelClass());
        if (listeners != null) {
            for (OnModelStateChangedListener listener : listeners) {
                if (listener != null) {
                    listener.onModelChanged(model, action);
                }
            }
        }
    }

    public <T> void notifyTableChanged(@NonNull Class<T> table, @NonNull Action action) {
        Set<OnTableChangedListener> listeners = (Set) this.tableChangedListenerMap.get(table);
        if (listeners != null) {
            for (OnTableChangedListener listener : listeners) {
                if (listener != null) {
                    listener.onTableChanged(table, action);
                }
            }
        }
    }

    public TableNotifierRegister newRegister() {
        return this.singleRegister;
    }

    public <T> void registerForModelChanges(@NonNull Class<T> table, @NonNull ModelChangedListener<T> listener) {
        registerForModelStateChanges(table, listener);
        registerForTableChanges(table, listener);
    }

    public <T> void registerForModelStateChanges(@NonNull Class<T> table, @NonNull OnModelStateChangedListener<T> listener) {
        Set<OnModelStateChangedListener> listeners = (Set) this.modelChangedListenerMap.get(table);
        if (listeners == null) {
            listeners = new LinkedHashSet();
            this.modelChangedListenerMap.put(table, listeners);
        }
        listeners.add(listener);
    }

    public <T> void registerForTableChanges(@NonNull Class<T> table, @NonNull OnTableChangedListener listener) {
        Set<OnTableChangedListener> listeners = (Set) this.tableChangedListenerMap.get(table);
        if (listeners == null) {
            listeners = new LinkedHashSet();
            this.tableChangedListenerMap.put(table, listeners);
        }
        listeners.add(listener);
    }

    public <T> void unregisterForModelChanges(@NonNull Class<T> table, @NonNull ModelChangedListener<T> listener) {
        unregisterForModelStateChanges(table, listener);
        unregisterForTableChanges(table, listener);
    }

    public <T> void unregisterForModelStateChanges(@NonNull Class<T> table, @NonNull OnModelStateChangedListener<T> listener) {
        Set<OnModelStateChangedListener> listeners = (Set) this.modelChangedListenerMap.get(table);
        if (listeners != null) {
            listeners.remove(listener);
        }
    }

    public <T> void unregisterForTableChanges(@NonNull Class<T> table, @NonNull OnTableChangedListener listener) {
        Set<OnTableChangedListener> listeners = (Set) this.tableChangedListenerMap.get(table);
        if (listeners != null) {
            listeners.remove(listener);
        }
    }
}
