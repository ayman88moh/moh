package com.raizlabs.android.dbflow.runtime;

import android.os.Looper;
import android.os.Process;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.config.DatabaseDefinition;
import com.raizlabs.android.dbflow.config.FlowLog;
import com.raizlabs.android.dbflow.config.FlowLog.Level;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.structure.Model;
import com.raizlabs.android.dbflow.structure.database.DatabaseWrapper;
import com.raizlabs.android.dbflow.structure.database.transaction.ProcessModelTransaction.Builder;
import com.raizlabs.android.dbflow.structure.database.transaction.ProcessModelTransaction.ProcessModel;
import com.raizlabs.android.dbflow.structure.database.transaction.Transaction;
import com.raizlabs.android.dbflow.structure.database.transaction.Transaction.Error;
import com.raizlabs.android.dbflow.structure.database.transaction.Transaction.Success;
import java.util.ArrayList;
import java.util.Collection;

public class DBBatchSaveQueue extends Thread {
    private static final int MODEL_SAVE_SIZE = 50;
    private static final int sMODEL_SAVE_CHECK_TIME = 30000;
    private DatabaseDefinition databaseDefinition;
    private Runnable emptyTransactionListener;
    private final Error errorCallback = new C05033();
    private Error errorListener;
    private boolean isQuitting = false;
    private long modelSaveCheckTime = 30000;
    private int modelSaveSize = 50;
    private final ProcessModel modelSaver = new C05011();
    private final ArrayList<Object> models;
    private final Success successCallback = new C05022();
    private Success successListener;

    class C05011 implements ProcessModel {
        C05011() {
        }

        public void processModel(Object model, DatabaseWrapper wrapper) {
            if (model instanceof Model) {
                ((Model) model).save();
            } else if (model != null) {
                FlowManager.getModelAdapter(model.getClass()).save(model);
            }
        }
    }

    class C05022 implements Success {
        C05022() {
        }

        public void onSuccess(@NonNull Transaction transaction) {
            if (DBBatchSaveQueue.this.successListener != null) {
                DBBatchSaveQueue.this.successListener.onSuccess(transaction);
            }
        }
    }

    class C05033 implements Error {
        C05033() {
        }

        public void onError(@NonNull Transaction transaction, @NonNull Throwable error) {
            if (DBBatchSaveQueue.this.errorListener != null) {
                DBBatchSaveQueue.this.errorListener.onError(transaction, error);
            }
        }
    }

    DBBatchSaveQueue(DatabaseDefinition databaseDefinition) {
        super("DBBatchSaveQueue");
        this.databaseDefinition = databaseDefinition;
        this.models = new ArrayList();
    }

    public void setModelSaveSize(int mModelSaveSize) {
        this.modelSaveSize = mModelSaveSize;
    }

    public void setModelSaveCheckTime(long time) {
        this.modelSaveCheckTime = time;
    }

    public void setErrorListener(@Nullable Error errorListener) {
        this.errorListener = errorListener;
    }

    public void setSuccessListener(@Nullable Success successListener) {
        this.successListener = successListener;
    }

    public void setEmptyTransactionListener(@Nullable Runnable emptyTransactionListener) {
        this.emptyTransactionListener = emptyTransactionListener;
    }

    public void run() {
        super.run();
        Looper.prepare();
        Process.setThreadPriority(10);
        do {
            synchronized (this.models) {
                Collection tmpModels = new ArrayList(this.models);
                this.models.clear();
            }
            if (tmpModels.size() > 0) {
                this.databaseDefinition.beginTransactionAsync(new Builder(this.modelSaver).addAll(tmpModels).build()).success(this.successCallback).error(this.errorCallback).build().execute();
            } else if (this.emptyTransactionListener != null) {
                this.emptyTransactionListener.run();
            }
            try {
                Thread.sleep(this.modelSaveCheckTime);
            } catch (InterruptedException e) {
                FlowLog.log(Level.I, "DBRequestQueue Batch interrupted to start saving");
            }
        } while (!this.isQuitting);
    }

    public void purgeQueue() {
        interrupt();
    }

    public void add(@NonNull Object inModel) {
        synchronized (this.models) {
            this.models.add(inModel);
            if (this.models.size() > this.modelSaveSize) {
                interrupt();
            }
        }
    }

    public void addAll(@NonNull Collection<Object> list) {
        synchronized (this.models) {
            this.models.addAll(list);
            if (this.models.size() > this.modelSaveSize) {
                interrupt();
            }
        }
    }

    public void addAll2(@NonNull Collection<?> list) {
        synchronized (this.models) {
            this.models.addAll(list);
            if (this.models.size() > this.modelSaveSize) {
                interrupt();
            }
        }
    }

    public void remove(@NonNull Object outModel) {
        synchronized (this.models) {
            this.models.remove(outModel);
        }
    }

    public void removeAll(@NonNull Collection<Object> outCollection) {
        synchronized (this.models) {
            this.models.removeAll(outCollection);
        }
    }

    public void removeAll2(@NonNull Collection<?> outCollection) {
        synchronized (this.models) {
            this.models.removeAll(outCollection);
        }
    }

    public void quit() {
        this.isQuitting = true;
    }
}
