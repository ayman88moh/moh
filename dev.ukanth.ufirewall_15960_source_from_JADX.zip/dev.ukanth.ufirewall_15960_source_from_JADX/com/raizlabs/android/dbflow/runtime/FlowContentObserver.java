package com.raizlabs.android.dbflow.runtime;

import android.annotation.TargetApi;
import android.content.ContentResolver;
import android.content.Context;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.sql.SqlUtils;
import com.raizlabs.android.dbflow.sql.language.NameAlias.Builder;
import com.raizlabs.android.dbflow.sql.language.Operator;
import com.raizlabs.android.dbflow.sql.language.SQLOperator;
import com.raizlabs.android.dbflow.structure.BaseModel.Action;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.atomic.AtomicInteger;

public class FlowContentObserver extends ContentObserver {
    private static final AtomicInteger REGISTERED_COUNT = new AtomicInteger(0);
    private static boolean forceNotify = false;
    protected boolean isInTransaction = false;
    private final Set<OnModelStateChangedListener> modelChangeListeners = new CopyOnWriteArraySet();
    private final Set<Uri> notificationUris = new HashSet();
    private boolean notifyAllUris = false;
    private final Set<OnTableChangedListener> onTableChangedListeners = new CopyOnWriteArraySet();
    private final Map<String, Class<?>> registeredTables = new HashMap();
    private final Set<Uri> tableUris = new HashSet();

    public interface OnModelStateChangedListener {
        void onModelStateChanged(@Nullable Class<?> cls, Action action, @NonNull SQLOperator[] sQLOperatorArr);
    }

    public interface ContentChangeListener extends OnModelStateChangedListener, OnTableChangedListener {
    }

    public static boolean shouldNotify() {
        return forceNotify || REGISTERED_COUNT.get() > 0;
    }

    public static void clearRegisteredObserverCount() {
        REGISTERED_COUNT.set(0);
    }

    public static void setShouldForceNotify(boolean forceNotify) {
        forceNotify = forceNotify;
    }

    public FlowContentObserver() {
        super(null);
    }

    public FlowContentObserver(@Nullable Handler handler) {
        super(handler);
    }

    public void setNotifyAllUris(boolean notifyAllUris) {
        this.notifyAllUris = notifyAllUris;
    }

    public void beginTransaction() {
        if (!this.isInTransaction) {
            this.isInTransaction = true;
        }
    }

    public void endTransactionAndNotify() {
        if (this.isInTransaction) {
            this.isInTransaction = false;
            if (VERSION.SDK_INT < 16) {
                onChange(true);
                return;
            }
            synchronized (this.notificationUris) {
                for (Uri uri : this.notificationUris) {
                    onChange(true, uri, true);
                }
                this.notificationUris.clear();
            }
            synchronized (this.tableUris) {
                for (Uri uri2 : this.tableUris) {
                    for (OnTableChangedListener onTableChangedListener : this.onTableChangedListeners) {
                        onTableChangedListener.onTableChanged((Class) this.registeredTables.get(uri2.getAuthority()), Action.valueOf(uri2.getFragment()));
                    }
                }
                this.tableUris.clear();
            }
        }
    }

    public void addModelChangeListener(@NonNull OnModelStateChangedListener modelChangeListener) {
        this.modelChangeListeners.add(modelChangeListener);
    }

    public void removeModelChangeListener(@NonNull OnModelStateChangedListener modelChangeListener) {
        this.modelChangeListeners.remove(modelChangeListener);
    }

    public void addOnTableChangedListener(@NonNull OnTableChangedListener onTableChangedListener) {
        this.onTableChangedListeners.add(onTableChangedListener);
    }

    public void removeTableChangedListener(@NonNull OnTableChangedListener onTableChangedListener) {
        this.onTableChangedListeners.remove(onTableChangedListener);
    }

    public void addContentChangeListener(@NonNull ContentChangeListener contentChangeListener) {
        this.modelChangeListeners.add(contentChangeListener);
        this.onTableChangedListeners.add(contentChangeListener);
    }

    public void removeContentChangeListener(@NonNull ContentChangeListener contentChangeListener) {
        this.modelChangeListeners.remove(contentChangeListener);
        this.onTableChangedListeners.remove(contentChangeListener);
    }

    public void registerForContentChanges(@NonNull Context context, @NonNull Class<?> table) {
        registerForContentChanges(context.getContentResolver(), (Class) table);
    }

    public void registerForContentChanges(@NonNull ContentResolver contentResolver, @NonNull Class<?> table) {
        contentResolver.registerContentObserver(SqlUtils.getNotificationUri(table, null), true, this);
        REGISTERED_COUNT.incrementAndGet();
        if (!this.registeredTables.containsValue(table)) {
            this.registeredTables.put(FlowManager.getTableName(table), table);
        }
    }

    public void unregisterForContentChanges(@NonNull Context context) {
        context.getContentResolver().unregisterContentObserver(this);
        REGISTERED_COUNT.decrementAndGet();
        this.registeredTables.clear();
    }

    public boolean isSubscribed() {
        return !this.registeredTables.isEmpty();
    }

    public void onChange(boolean selfChange) {
        for (OnModelStateChangedListener modelChangeListener : this.modelChangeListeners) {
            modelChangeListener.onModelStateChanged(null, Action.CHANGE, new SQLOperator[0]);
        }
        for (OnTableChangedListener onTableChangedListener : this.onTableChangedListeners) {
            onTableChangedListener.onTableChanged(null, Action.CHANGE);
        }
    }

    @TargetApi(16)
    public void onChange(boolean selfChange, Uri uri) {
        onChange(selfChange, uri, false);
    }

    @TargetApi(16)
    private void onChange(boolean selfChanges, Uri uri, boolean calledInternally) {
        String fragment = uri.getFragment();
        String tableName = uri.getAuthority();
        Set<String> queryNames = uri.getQueryParameterNames();
        SQLOperator[] columnsChanged = new SQLOperator[queryNames.size()];
        if (!queryNames.isEmpty()) {
            int index = 0;
            for (String key : queryNames) {
                columnsChanged[index] = Operator.op(new Builder(Uri.decode(key)).build()).eq(Uri.decode(uri.getQueryParameter(key)));
                index++;
            }
        }
        Class<?> table = (Class) this.registeredTables.get(tableName);
        Action action = Action.valueOf(fragment);
        if (this.isInTransaction) {
            if (!this.notifyAllUris) {
                action = Action.CHANGE;
                uri = SqlUtils.getNotificationUri(table, action);
            }
            synchronized (this.notificationUris) {
                this.notificationUris.add(uri);
            }
            synchronized (this.tableUris) {
                this.tableUris.add(SqlUtils.getNotificationUri(table, action));
            }
            return;
        }
        for (OnModelStateChangedListener modelChangeListener : this.modelChangeListeners) {
            modelChangeListener.onModelStateChanged(table, action, columnsChanged);
        }
        if (!calledInternally) {
            for (OnTableChangedListener onTableChangeListener : this.onTableChangedListeners) {
                onTableChangeListener.onTableChanged(table, action);
            }
        }
    }
}
