package com.raizlabs.android.dbflow.sql.saveable;

import android.support.annotation.NonNull;
import com.raizlabs.android.dbflow.structure.database.DatabaseStatement;
import com.raizlabs.android.dbflow.structure.database.DatabaseWrapper;
import java.util.Collection;

public class ListModelSaver<TModel> {
    private final ModelSaver<TModel> modelSaver;

    public ListModelSaver(@NonNull ModelSaver<TModel> modelSaver) {
        this.modelSaver = modelSaver;
    }

    public synchronized void saveAll(@NonNull Collection<TModel> tableCollection) {
        saveAll(tableCollection, this.modelSaver.getWritableDatabase());
    }

    public synchronized void saveAll(@NonNull Collection<TModel> tableCollection, @NonNull DatabaseWrapper wrapper) {
        if (!tableCollection.isEmpty()) {
            DatabaseStatement statement = this.modelSaver.getModelAdapter().getInsertStatement(wrapper);
            DatabaseStatement updateStatement = this.modelSaver.getModelAdapter().getUpdateStatement(wrapper);
            try {
                for (TModel model : tableCollection) {
                    this.modelSaver.save((Object) model, wrapper, statement, updateStatement);
                }
                statement.close();
            } catch (Throwable th) {
                statement.close();
            }
        }
    }

    public synchronized void insertAll(@NonNull Collection<TModel> tableCollection) {
        insertAll(tableCollection, this.modelSaver.getWritableDatabase());
    }

    public synchronized void insertAll(@NonNull Collection<TModel> tableCollection, @NonNull DatabaseWrapper wrapper) {
        if (!tableCollection.isEmpty()) {
            DatabaseStatement statement = this.modelSaver.getModelAdapter().getInsertStatement(wrapper);
            try {
                for (TModel model : tableCollection) {
                    this.modelSaver.insert(model, statement, wrapper);
                }
                statement.close();
            } catch (Throwable th) {
                statement.close();
            }
        }
    }

    public synchronized void updateAll(@NonNull Collection<TModel> tableCollection) {
        updateAll(tableCollection, this.modelSaver.getWritableDatabase());
    }

    public synchronized void updateAll(@NonNull Collection<TModel> tableCollection, @NonNull DatabaseWrapper wrapper) {
        if (!tableCollection.isEmpty()) {
            DatabaseStatement updateStatement = this.modelSaver.getModelAdapter().getUpdateStatement(wrapper);
            try {
                for (TModel model : tableCollection) {
                    this.modelSaver.update((Object) model, wrapper, updateStatement);
                }
                updateStatement.close();
            } catch (Throwable th) {
                updateStatement.close();
            }
        }
    }

    public synchronized void deleteAll(@NonNull Collection<TModel> tableCollection) {
        deleteAll(tableCollection, this.modelSaver.getWritableDatabase());
    }

    public synchronized void deleteAll(@NonNull Collection<TModel> tableCollection, @NonNull DatabaseWrapper wrapper) {
        if (!tableCollection.isEmpty()) {
            DatabaseStatement deleteStatement = this.modelSaver.getModelAdapter().getDeleteStatement(wrapper);
            try {
                for (TModel model : tableCollection) {
                    this.modelSaver.delete(model, deleteStatement, wrapper);
                }
                deleteStatement.close();
            } catch (Throwable th) {
                deleteStatement.close();
            }
        }
    }

    @NonNull
    public ModelSaver<TModel> getModelSaver() {
        return this.modelSaver;
    }
}
