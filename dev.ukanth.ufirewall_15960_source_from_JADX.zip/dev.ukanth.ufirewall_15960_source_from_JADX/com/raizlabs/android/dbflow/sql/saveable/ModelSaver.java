package com.raizlabs.android.dbflow.sql.saveable;

import android.content.ContentValues;
import android.support.annotation.NonNull;
import com.raizlabs.android.dbflow.annotation.ConflictAction;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.runtime.NotifyDistributor;
import com.raizlabs.android.dbflow.structure.BaseModel.Action;
import com.raizlabs.android.dbflow.structure.ModelAdapter;
import com.raizlabs.android.dbflow.structure.database.DatabaseStatement;
import com.raizlabs.android.dbflow.structure.database.DatabaseWrapper;

public class ModelSaver<TModel> {
    private static final int INSERT_FAILED = -1;
    private ModelAdapter<TModel> modelAdapter;

    public void setModelAdapter(@NonNull ModelAdapter<TModel> modelAdapter) {
        this.modelAdapter = modelAdapter;
    }

    public synchronized boolean save(@NonNull TModel model) {
        return save((Object) model, getWritableDatabase(), this.modelAdapter.getInsertStatement(), this.modelAdapter.getUpdateStatement());
    }

    public synchronized boolean save(@NonNull TModel model, @NonNull DatabaseWrapper wrapper) {
        return save((Object) model, wrapper, this.modelAdapter.getInsertStatement(wrapper), this.modelAdapter.getUpdateStatement(wrapper));
    }

    public synchronized boolean save(@NonNull TModel model, @NonNull DatabaseWrapper wrapper, @NonNull DatabaseStatement insertStatement, @NonNull DatabaseStatement updateStatement) {
        boolean exists;
        exists = this.modelAdapter.exists(model, wrapper);
        if (exists) {
            exists = update((Object) model, wrapper, updateStatement);
        }
        if (!exists) {
            exists = insert(model, insertStatement, wrapper) > -1;
        }
        if (exists) {
            NotifyDistributor.get().notifyModelChanged(model, this.modelAdapter, Action.SAVE);
        }
        return exists;
    }

    public synchronized boolean update(@NonNull TModel model) {
        return update((Object) model, getWritableDatabase(), this.modelAdapter.getUpdateStatement());
    }

    public synchronized boolean update(@NonNull TModel model, @NonNull DatabaseWrapper wrapper) {
        boolean success;
        DatabaseStatement insertStatement = this.modelAdapter.getUpdateStatement(wrapper);
        try {
            success = update((Object) model, wrapper, insertStatement);
            insertStatement.close();
        } catch (Throwable th) {
            insertStatement.close();
        }
        return success;
    }

    public synchronized boolean update(@NonNull TModel model, @NonNull DatabaseWrapper wrapper, @NonNull DatabaseStatement databaseStatement) {
        boolean successful;
        this.modelAdapter.saveForeignKeys(model, wrapper);
        this.modelAdapter.bindToUpdateStatement(databaseStatement, model);
        successful = databaseStatement.executeUpdateDelete() != 0;
        if (successful) {
            NotifyDistributor.get().notifyModelChanged(model, this.modelAdapter, Action.UPDATE);
        }
        return successful;
    }

    public synchronized long insert(@NonNull TModel model) {
        return insert(model, this.modelAdapter.getInsertStatement(), getWritableDatabase());
    }

    public synchronized long insert(@NonNull TModel model, @NonNull DatabaseWrapper wrapper) {
        long result;
        DatabaseStatement insertStatement = this.modelAdapter.getInsertStatement(wrapper);
        try {
            result = insert(model, insertStatement, wrapper);
            insertStatement.close();
        } catch (Throwable th) {
            insertStatement.close();
        }
        return result;
    }

    public synchronized long insert(@NonNull TModel model, @NonNull DatabaseStatement insertStatement, @NonNull DatabaseWrapper wrapper) {
        long id;
        this.modelAdapter.saveForeignKeys(model, wrapper);
        this.modelAdapter.bindToInsertStatement(insertStatement, model);
        id = insertStatement.executeInsert();
        if (id > -1) {
            this.modelAdapter.updateAutoIncrement(model, Long.valueOf(id));
            NotifyDistributor.get().notifyModelChanged(model, this.modelAdapter, Action.INSERT);
        }
        return id;
    }

    public synchronized boolean delete(@NonNull TModel model) {
        return delete(model, this.modelAdapter.getDeleteStatement(), getWritableDatabase());
    }

    public synchronized boolean delete(@NonNull TModel model, @NonNull DatabaseWrapper wrapper) {
        boolean success;
        DatabaseStatement deleteStatement = this.modelAdapter.getDeleteStatement(wrapper);
        try {
            success = delete(model, deleteStatement, wrapper);
            deleteStatement.close();
        } catch (Throwable th) {
            deleteStatement.close();
        }
        return success;
    }

    public synchronized boolean delete(@NonNull TModel model, @NonNull DatabaseStatement deleteStatement, @NonNull DatabaseWrapper wrapper) {
        boolean success = false;
        synchronized (this) {
            this.modelAdapter.deleteForeignKeys(model, wrapper);
            this.modelAdapter.bindToDeleteStatement(deleteStatement, model);
            if (deleteStatement.executeUpdateDelete() != 0) {
                success = true;
            }
            if (success) {
                NotifyDistributor.get().notifyModelChanged(model, this.modelAdapter, Action.DELETE);
            }
            this.modelAdapter.updateAutoIncrement(model, Integer.valueOf(0));
        }
        return success;
    }

    @NonNull
    protected DatabaseWrapper getWritableDatabase() {
        return FlowManager.getDatabaseForTable(this.modelAdapter.getModelClass()).getWritableDatabase();
    }

    @NonNull
    public ModelAdapter<TModel> getModelAdapter() {
        return this.modelAdapter;
    }

    @Deprecated
    public synchronized boolean save(@NonNull TModel model, @NonNull DatabaseWrapper wrapper, @NonNull DatabaseStatement insertStatement, @NonNull ContentValues contentValues) {
        boolean exists;
        exists = this.modelAdapter.exists(model, wrapper);
        if (exists) {
            exists = update((Object) model, wrapper, contentValues);
        }
        if (!exists) {
            exists = insert(model, insertStatement, wrapper) > -1;
        }
        if (exists) {
            NotifyDistributor.get().notifyModelChanged(model, this.modelAdapter, Action.SAVE);
        }
        return exists;
    }

    @Deprecated
    public synchronized boolean update(@NonNull TModel model, @NonNull DatabaseWrapper wrapper, @NonNull ContentValues contentValues) {
        boolean successful;
        this.modelAdapter.saveForeignKeys(model, wrapper);
        this.modelAdapter.bindToContentValues(contentValues, model);
        successful = wrapper.updateWithOnConflict(this.modelAdapter.getTableName(), contentValues, this.modelAdapter.getPrimaryConditionClause(model).getQuery(), null, ConflictAction.getSQLiteDatabaseAlgorithmInt(this.modelAdapter.getUpdateOnConflictAction())) != 0;
        if (successful) {
            NotifyDistributor.get().notifyModelChanged(model, this.modelAdapter, Action.UPDATE);
        }
        return successful;
    }
}
