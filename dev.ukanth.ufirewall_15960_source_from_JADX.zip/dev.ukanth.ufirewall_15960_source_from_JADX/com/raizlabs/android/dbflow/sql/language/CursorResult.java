package com.raizlabs.android.dbflow.sql.language;

import android.database.Cursor;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.list.FlowCursorIterator;
import com.raizlabs.android.dbflow.list.IFlowCursorIterator;
import com.raizlabs.android.dbflow.structure.InstanceAdapter;
import com.raizlabs.android.dbflow.structure.database.FlowCursor;
import java.util.ArrayList;
import java.util.List;

public class CursorResult<TModel> implements IFlowCursorIterator<TModel> {
    @Nullable
    private FlowCursor cursor;
    private final InstanceAdapter<TModel> retrievalAdapter;

    CursorResult(Class<TModel> modelClass, @Nullable Cursor cursor) {
        if (cursor != null) {
            this.cursor = FlowCursor.from(cursor);
        }
        this.retrievalAdapter = FlowManager.getInstanceAdapter(modelClass);
    }

    public void swapCursor(@Nullable FlowCursor cursor) {
        if (!(this.cursor == null || this.cursor.isClosed())) {
            this.cursor.close();
        }
        this.cursor = cursor;
    }

    @NonNull
    public List<TModel> toList() {
        return this.cursor != null ? this.retrievalAdapter.getListModelLoader().convertToData(this.cursor, null) : new ArrayList();
    }

    @NonNull
    public List<TModel> toListClose() {
        List<TModel> list = this.cursor != null ? this.retrievalAdapter.getListModelLoader().load(this.cursor) : new ArrayList();
        close();
        return list;
    }

    @NonNull
    public <TCustom> List<TCustom> toCustomList(@NonNull Class<TCustom> customClass) {
        return this.cursor != null ? FlowManager.getQueryModelAdapter(customClass).getListModelLoader().convertToData(this.cursor, null) : new ArrayList();
    }

    @NonNull
    public <TCustom> List<TCustom> toCustomListClose(@NonNull Class<TCustom> customClass) {
        List<TCustom> customList = this.cursor != null ? FlowManager.getQueryModelAdapter(customClass).getListModelLoader().load(this.cursor) : new ArrayList();
        close();
        return customList;
    }

    @Nullable
    public TModel toModel() {
        return this.cursor != null ? this.retrievalAdapter.getSingleModelLoader().convertToData(this.cursor, null) : null;
    }

    @Nullable
    public TModel toModelClose() {
        TModel model = this.cursor != null ? this.retrievalAdapter.getSingleModelLoader().load(this.cursor) : null;
        close();
        return model;
    }

    @Nullable
    public <TCustom> TCustom toCustomModel(@NonNull Class<TCustom> customClass) {
        if (this.cursor != null) {
            return FlowManager.getQueryModelAdapter(customClass).getSingleModelLoader().convertToData(this.cursor, null);
        }
        return null;
    }

    @Nullable
    public <TCustom> TCustom toCustomModelClose(@NonNull Class<TCustom> customClass) {
        TCustom customList = this.cursor != null ? FlowManager.getQueryModelAdapter(customClass).getSingleModelLoader().load(this.cursor) : null;
        close();
        return customList;
    }

    @Nullable
    public TModel getItem(long position) {
        if (this.cursor == null || !this.cursor.moveToPosition((int) position)) {
            return null;
        }
        return this.retrievalAdapter.getSingleModelLoader().convertToData(this.cursor, null, false);
    }

    @NonNull
    public FlowCursorIterator<TModel> iterator() {
        return new FlowCursorIterator(this);
    }

    @NonNull
    public FlowCursorIterator<TModel> iterator(int startingLocation, long limit) {
        return new FlowCursorIterator(this, startingLocation, limit);
    }

    public long getCount() {
        return this.cursor == null ? 0 : (long) this.cursor.getCount();
    }

    @Nullable
    public Cursor cursor() {
        return this.cursor;
    }

    public void close() {
        if (this.cursor != null) {
            this.cursor.close();
        }
    }
}
