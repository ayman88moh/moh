package com.raizlabs.android.dbflow.sql.language.property;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.sql.language.NameAlias;
import com.raizlabs.android.dbflow.sql.language.Operator;
import com.raizlabs.android.dbflow.sql.queriable.ModelQueriable;

public class PropertyFactory {
    @NonNull
    public static Property<Character> from(char c) {
        return new Property(null, NameAlias.rawBuilder("'" + c + "'").build());
    }

    @NonNull
    public static Property<Integer> from(int i) {
        return new Property(null, NameAlias.rawBuilder(i + "").build());
    }

    @NonNull
    public static Property<Double> from(double d) {
        return new Property(null, NameAlias.rawBuilder(d + "").build());
    }

    @NonNull
    public static Property<Long> from(long l) {
        return new Property(null, NameAlias.rawBuilder(l + "").build());
    }

    @NonNull
    public static Property<Float> from(float f) {
        return new Property(null, NameAlias.rawBuilder(f + "").build());
    }

    @NonNull
    public static Property<Short> from(short s) {
        return new Property(null, NameAlias.rawBuilder(s + "").build());
    }

    @NonNull
    public static Property<Byte> from(byte b) {
        return new Property(null, NameAlias.rawBuilder(b + "").build());
    }

    @NonNull
    public static <T> Property<T> from(@Nullable T type) {
        return new Property(null, NameAlias.rawBuilder(Operator.convertValueToString(type)).build());
    }

    @NonNull
    public static <TModel> Property<TModel> from(@NonNull ModelQueriable<TModel> queriable) {
        return from(queriable.getTable(), "(" + String.valueOf(queriable.getQuery()).trim() + ")");
    }

    @NonNull
    public static <T> Property<T> from(@Nullable Class<T> cls, @Nullable String stringRepresentation) {
        return new Property(null, NameAlias.rawBuilder(stringRepresentation).build());
    }
}
