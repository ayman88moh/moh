package com.raizlabs.android.dbflow.sql.language;

import android.support.annotation.NonNull;
import com.raizlabs.android.dbflow.sql.Query;
import com.raizlabs.android.dbflow.sql.QueryBuilder;

public class Delete implements Query {
    public static <TModel> void table(@NonNull Class<TModel> table, SQLOperator... conditions) {
        new Delete().from(table).where(conditions).executeUpdateDelete();
    }

    public static void tables(Class<?>... tables) {
        for (Class modelClass : tables) {
            table(modelClass, new SQLOperator[0]);
        }
    }

    @NonNull
    public <TModel> From<TModel> from(@NonNull Class<TModel> table) {
        return new From(this, table);
    }

    public String getQuery() {
        return new QueryBuilder().append(TriggerMethod.DELETE).appendSpace().getQuery();
    }
}
