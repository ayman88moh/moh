package com.raizlabs.android.dbflow.sql.language;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.sql.Query;
import com.raizlabs.android.dbflow.sql.QueryBuilder;
import com.raizlabs.android.dbflow.sql.language.property.IProperty;

public class CaseCondition<TReturn> implements Query {
    private final Case<TReturn> caze;
    private boolean isThenPropertySet;
    private IProperty property;
    private SQLOperator sqlOperator;
    private IProperty thenProperty;
    private TReturn thenValue;
    private TReturn whenValue;

    CaseCondition(Case<TReturn> caze, @NonNull SQLOperator sqlOperator) {
        this.caze = caze;
        this.sqlOperator = sqlOperator;
    }

    CaseCondition(Case<TReturn> caze, TReturn whenValue) {
        this.caze = caze;
        this.whenValue = whenValue;
    }

    CaseCondition(Case<TReturn> caze, @NonNull IProperty property) {
        this.caze = caze;
        this.property = property;
    }

    @NonNull
    public Case<TReturn> then(@Nullable TReturn value) {
        this.thenValue = value;
        return this.caze;
    }

    @NonNull
    public Case<TReturn> then(@NonNull IProperty value) {
        this.thenProperty = value;
        this.isThenPropertySet = true;
        return this.caze;
    }

    public String getQuery() {
        QueryBuilder queryBuilder = new QueryBuilder(" WHEN ");
        if (this.caze.isEfficientCase()) {
            queryBuilder.append(BaseOperator.convertValueToString(this.property != null ? this.property : this.whenValue, false));
        } else {
            this.sqlOperator.appendConditionToQuery(queryBuilder);
        }
        queryBuilder.append(" THEN ").append(BaseOperator.convertValueToString(this.isThenPropertySet ? this.thenProperty : this.thenValue, false));
        return queryBuilder.getQuery();
    }

    public String toString() {
        return getQuery();
    }
}
