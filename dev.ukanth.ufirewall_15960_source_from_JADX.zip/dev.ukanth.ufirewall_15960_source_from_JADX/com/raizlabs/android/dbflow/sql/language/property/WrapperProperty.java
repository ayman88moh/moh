package com.raizlabs.android.dbflow.sql.language.property;

import android.support.annotation.NonNull;
import com.raizlabs.android.dbflow.sql.language.NameAlias;

public class WrapperProperty<T, V> extends Property<V> {
    private WrapperProperty<V, T> databaseProperty;

    public WrapperProperty(@NonNull Class<?> table, @NonNull NameAlias nameAlias) {
        super((Class) table, nameAlias);
    }

    public WrapperProperty(@NonNull Class<?> table, @NonNull String columnName) {
        super((Class) table, columnName);
    }

    @NonNull
    public Property<T> invertProperty() {
        if (this.databaseProperty == null) {
            this.databaseProperty = new WrapperProperty(this.table, this.nameAlias);
        }
        return this.databaseProperty;
    }
}
