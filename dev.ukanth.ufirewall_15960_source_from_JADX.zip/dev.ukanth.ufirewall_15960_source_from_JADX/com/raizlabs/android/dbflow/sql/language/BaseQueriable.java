package com.raizlabs.android.dbflow.sql.language;

import android.database.Cursor;
import android.support.annotation.NonNull;
import com.raizlabs.android.dbflow.config.FlowLog;
import com.raizlabs.android.dbflow.config.FlowLog.Level;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.runtime.NotifyDistributor;
import com.raizlabs.android.dbflow.sql.SqlUtils;
import com.raizlabs.android.dbflow.sql.queriable.Queriable;
import com.raizlabs.android.dbflow.structure.BaseModel.Action;
import com.raizlabs.android.dbflow.structure.database.DatabaseStatement;
import com.raizlabs.android.dbflow.structure.database.DatabaseStatementWrapper;
import com.raizlabs.android.dbflow.structure.database.DatabaseWrapper;
import com.raizlabs.android.dbflow.structure.database.FlowCursor;

public abstract class BaseQueriable<TModel> implements Queriable, Actionable {
    private final Class<TModel> table;

    @NonNull
    public abstract Action getPrimaryAction();

    protected BaseQueriable(Class<TModel> table) {
        this.table = table;
    }

    @NonNull
    public Class<TModel> getTable() {
        return this.table;
    }

    public long count(@NonNull DatabaseWrapper databaseWrapper) {
        try {
            String query = getQuery();
            FlowLog.log(Level.V, "Executing query: " + query);
            return SqlUtils.longForQuery(databaseWrapper, query);
        } catch (Throwable sde) {
            FlowLog.log(Level.W, sde);
            return 0;
        }
    }

    public long count() {
        return count(FlowManager.getWritableDatabaseForTable(this.table));
    }

    public boolean hasData() {
        return count() > 0;
    }

    public boolean hasData(@NonNull DatabaseWrapper databaseWrapper) {
        return count(databaseWrapper) > 0;
    }

    public FlowCursor query() {
        query(FlowManager.getWritableDatabaseForTable(this.table));
        return null;
    }

    public FlowCursor query(@NonNull DatabaseWrapper databaseWrapper) {
        if (getPrimaryAction().equals(Action.INSERT)) {
            DatabaseStatement databaseStatement = compileStatement(databaseWrapper);
            databaseStatement.executeInsert();
            databaseStatement.close();
        } else {
            String query = getQuery();
            FlowLog.log(Level.V, "Executing query: " + query);
            databaseWrapper.execSQL(query);
        }
        return null;
    }

    public long executeInsert() {
        return executeInsert(FlowManager.getWritableDatabaseForTable(this.table));
    }

    public long executeInsert(@NonNull DatabaseWrapper databaseWrapper) {
        return compileStatement().executeInsert();
    }

    public void execute() {
        Cursor cursor = query();
        if (cursor != null) {
            cursor.close();
        } else {
            NotifyDistributor.get().notifyTableChanged(getTable(), getPrimaryAction());
        }
    }

    public void execute(@NonNull DatabaseWrapper databaseWrapper) {
        Cursor cursor = query(databaseWrapper);
        if (cursor != null) {
            cursor.close();
        } else {
            NotifyDistributor.get().notifyTableChanged(getTable(), getPrimaryAction());
        }
    }

    @NonNull
    public DatabaseStatement compileStatement() {
        return compileStatement(FlowManager.getWritableDatabaseForTable(this.table));
    }

    @NonNull
    public DatabaseStatement compileStatement(@NonNull DatabaseWrapper databaseWrapper) {
        String query = getQuery();
        FlowLog.log(Level.V, "Compiling Query Into Statement: " + query);
        return new DatabaseStatementWrapper(databaseWrapper.compileStatement(query), this);
    }

    public String toString() {
        return getQuery();
    }
}
