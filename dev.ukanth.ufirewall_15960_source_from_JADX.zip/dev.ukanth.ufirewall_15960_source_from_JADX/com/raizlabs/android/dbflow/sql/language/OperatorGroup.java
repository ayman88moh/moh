package com.raizlabs.android.dbflow.sql.language;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.sql.Query;
import com.raizlabs.android.dbflow.sql.QueryBuilder;
import com.raizlabs.android.dbflow.sql.language.Operator.Operation;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class OperatorGroup extends BaseOperator implements Query, Iterable<SQLOperator> {
    private boolean allCommaSeparated;
    @NonNull
    private final List<SQLOperator> conditionsList;
    private boolean isChanged;
    private QueryBuilder query;
    private boolean useParenthesis;

    @NonNull
    public static OperatorGroup clause() {
        return new OperatorGroup();
    }

    @NonNull
    public static OperatorGroup clause(SQLOperator... condition) {
        return new OperatorGroup().andAll(condition);
    }

    public static OperatorGroup nonGroupingClause() {
        return new OperatorGroup().setUseParenthesis(false);
    }

    public static OperatorGroup nonGroupingClause(SQLOperator... condition) {
        return new OperatorGroup().setUseParenthesis(false).andAll(condition);
    }

    protected OperatorGroup(NameAlias columnName) {
        super(columnName);
        this.conditionsList = new ArrayList();
        this.useParenthesis = true;
        this.separator = Operation.AND;
    }

    protected OperatorGroup() {
        this(null);
    }

    @NonNull
    public OperatorGroup setAllCommaSeparated(boolean allCommaSeparated) {
        this.allCommaSeparated = allCommaSeparated;
        this.isChanged = true;
        return this;
    }

    @NonNull
    public OperatorGroup setUseParenthesis(boolean useParenthesis) {
        this.useParenthesis = useParenthesis;
        this.isChanged = true;
        return this;
    }

    @NonNull
    public OperatorGroup or(SQLOperator sqlOperator) {
        return operator(Operation.OR, sqlOperator);
    }

    @NonNull
    public OperatorGroup and(SQLOperator sqlOperator) {
        return operator(Operation.AND, sqlOperator);
    }

    @NonNull
    public OperatorGroup andAll(SQLOperator... sqlOperators) {
        for (SQLOperator sqlOperator : sqlOperators) {
            and(sqlOperator);
        }
        return this;
    }

    @NonNull
    public OperatorGroup andAll(Collection<SQLOperator> sqlOperators) {
        for (SQLOperator sqlOperator : sqlOperators) {
            and(sqlOperator);
        }
        return this;
    }

    @NonNull
    public OperatorGroup orAll(SQLOperator... sqlOperators) {
        for (SQLOperator sqlOperator : sqlOperators) {
            or(sqlOperator);
        }
        return this;
    }

    @NonNull
    public OperatorGroup orAll(Collection<SQLOperator> sqlOperators) {
        for (SQLOperator sqlOperator : sqlOperators) {
            or(sqlOperator);
        }
        return this;
    }

    @NonNull
    private OperatorGroup operator(String operator, @Nullable SQLOperator sqlOperator) {
        if (sqlOperator != null) {
            setPreviousSeparator(operator);
            this.conditionsList.add(sqlOperator);
            this.isChanged = true;
        }
        return this;
    }

    public void appendConditionToQuery(@NonNull QueryBuilder queryBuilder) {
        int conditionListSize = this.conditionsList.size();
        if (this.useParenthesis && conditionListSize > 0) {
            queryBuilder.append("(");
        }
        int i = 0;
        while (i < conditionListSize) {
            SQLOperator condition = (SQLOperator) this.conditionsList.get(i);
            condition.appendConditionToQuery(queryBuilder);
            if (!this.allCommaSeparated && condition.hasSeparator() && i < conditionListSize - 1) {
                queryBuilder.appendSpaceSeparated(condition.separator());
            } else if (i < conditionListSize - 1) {
                queryBuilder.append(", ");
            }
            i++;
        }
        if (this.useParenthesis && conditionListSize > 0) {
            queryBuilder.append(")");
        }
    }

    private void setPreviousSeparator(String separator) {
        if (this.conditionsList.size() > 0) {
            ((SQLOperator) this.conditionsList.get(this.conditionsList.size() - 1)).separator(separator);
        }
    }

    public String getQuery() {
        if (this.isChanged) {
            this.query = getQuerySafe();
        }
        return this.query == null ? "" : this.query.toString();
    }

    public String toString() {
        return getQuerySafe().toString();
    }

    public int size() {
        return this.conditionsList.size();
    }

    @NonNull
    public List<SQLOperator> getConditions() {
        return this.conditionsList;
    }

    public Iterator<SQLOperator> iterator() {
        return this.conditionsList.iterator();
    }

    private QueryBuilder getQuerySafe() {
        QueryBuilder query = new QueryBuilder();
        appendConditionToQuery(query);
        return query;
    }
}
