package com.raizlabs.android.dbflow.sql.language;

import android.database.DatabaseUtils;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.converter.TypeConverter;
import com.raizlabs.android.dbflow.data.Blob;
import com.raizlabs.android.dbflow.sql.Query;
import com.raizlabs.android.dbflow.sql.QueryBuilder;
import com.raizlabs.android.dbflow.sql.SqlUtils;
import com.raizlabs.android.dbflow.sql.language.Operator.Operation;

public abstract class BaseOperator implements SQLOperator {
    protected boolean isValueSet;
    @NonNull
    protected NameAlias nameAlias;
    protected String operation = "";
    protected String postArg;
    protected String separator;
    protected Object value;

    @Nullable
    public static String convertValueToString(Object value, boolean appendInnerQueryParenthesis) {
        return convertValueToString(value, appendInnerQueryParenthesis, true);
    }

    @Nullable
    public static String convertValueToString(@Nullable Object value, boolean appendInnerQueryParenthesis, boolean typeConvert) {
        if (value == null) {
            return "NULL";
        }
        if (typeConvert) {
            TypeConverter typeConverter = FlowManager.getTypeConverterForClass(value.getClass());
            if (typeConverter != null) {
                value = typeConverter.getDBValue(value);
            }
        }
        if (value instanceof Number) {
            return String.valueOf(value);
        }
        if (value instanceof Enum) {
            return DatabaseUtils.sqlEscapeString(((Enum) value).name());
        }
        if (appendInnerQueryParenthesis && (value instanceof BaseModelQueriable)) {
            return String.format("(%1s)", new Object[]{((BaseModelQueriable) value).getQuery().trim()});
        } else if (value instanceof NameAlias) {
            return ((NameAlias) value).getQuery();
        } else {
            if (value instanceof SQLOperator) {
                QueryBuilder queryBuilder = new QueryBuilder();
                ((SQLOperator) value).appendConditionToQuery(queryBuilder);
                return queryBuilder.toString();
            } else if (value instanceof Query) {
                return ((Query) value).getQuery();
            } else {
                if ((value instanceof Blob) || (value instanceof byte[])) {
                    byte[] bytes;
                    if (value instanceof Blob) {
                        bytes = ((Blob) value).getBlob();
                    } else {
                        bytes = (byte[]) value;
                    }
                    return "X" + DatabaseUtils.sqlEscapeString(SqlUtils.byteArrayToHexString(bytes));
                }
                String stringVal = String.valueOf(value);
                if (stringVal.equals(Operation.EMPTY_PARAM)) {
                    return stringVal;
                }
                return DatabaseUtils.sqlEscapeString(stringVal);
            }
        }
    }

    @NonNull
    public static String joinArguments(@NonNull CharSequence delimiter, @NonNull Iterable tokens, @NonNull BaseOperator condition) {
        StringBuilder sb = new StringBuilder();
        boolean firstTime = true;
        for (Object token : tokens) {
            if (firstTime) {
                firstTime = false;
            } else {
                sb.append(delimiter);
            }
            sb.append(condition.convertObjectToString(token, false));
        }
        return sb.toString();
    }

    @NonNull
    public static String joinArguments(@NonNull CharSequence delimiter, @NonNull Object[] tokens) {
        StringBuilder sb = new StringBuilder();
        boolean firstTime = true;
        for (Object token : tokens) {
            if (firstTime) {
                firstTime = false;
            } else {
                sb.append(delimiter);
            }
            sb.append(convertValueToString(token, false, true));
        }
        return sb.toString();
    }

    @NonNull
    public static String joinArguments(@NonNull CharSequence delimiter, @NonNull Iterable tokens) {
        StringBuilder sb = new StringBuilder();
        boolean firstTime = true;
        for (Object token : tokens) {
            if (firstTime) {
                firstTime = false;
            } else {
                sb.append(delimiter);
            }
            sb.append(convertValueToString(token, false, true));
        }
        return sb.toString();
    }

    BaseOperator(@NonNull NameAlias nameAlias) {
        this.nameAlias = nameAlias;
    }

    public Object value() {
        return this.value;
    }

    @NonNull
    public String columnName() {
        return this.nameAlias.getQuery();
    }

    @NonNull
    public SQLOperator separator(@NonNull String separator) {
        this.separator = separator;
        return this;
    }

    @Nullable
    public String separator() {
        return this.separator;
    }

    public boolean hasSeparator() {
        return this.separator != null && this.separator.length() > 0;
    }

    @NonNull
    public String operation() {
        return this.operation;
    }

    public String postArgument() {
        return this.postArg;
    }

    NameAlias columnAlias() {
        return this.nameAlias;
    }

    public String convertObjectToString(Object object, boolean appendInnerParenthesis) {
        return convertValueToString(object, appendInnerParenthesis);
    }
}
