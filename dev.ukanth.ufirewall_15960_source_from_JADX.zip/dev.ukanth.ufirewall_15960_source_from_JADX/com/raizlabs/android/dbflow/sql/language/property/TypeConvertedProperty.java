package com.raizlabs.android.dbflow.sql.language.property;

import android.support.annotation.NonNull;
import com.raizlabs.android.dbflow.converter.TypeConverter;
import com.raizlabs.android.dbflow.sql.language.NameAlias;
import com.raizlabs.android.dbflow.sql.language.Operator;

public class TypeConvertedProperty<T, V> extends Property<V> {
    private boolean convertToDB;
    private TypeConvertedProperty<V, T> databaseProperty;
    private final TypeConverterGetter getter;

    public interface TypeConverterGetter {
        TypeConverter getTypeConverter(Class<?> cls);
    }

    class C05071 implements TypeConverterGetter {
        C05071() {
        }

        public TypeConverter getTypeConverter(Class<?> modelClass) {
            return TypeConvertedProperty.this.getter.getTypeConverter(modelClass);
        }
    }

    public TypeConvertedProperty(Class<?> table, NameAlias nameAlias, boolean convertToDB, TypeConverterGetter getter) {
        super((Class) table, nameAlias);
        this.convertToDB = convertToDB;
        this.getter = getter;
    }

    public TypeConvertedProperty(Class<?> table, String columnName, boolean convertToDB, TypeConverterGetter getter) {
        super((Class) table, columnName);
        this.convertToDB = convertToDB;
        this.getter = getter;
    }

    @NonNull
    protected Operator<V> getCondition() {
        return Operator.op(getNameAlias(), this.getter.getTypeConverter(this.table), this.convertToDB);
    }

    @NonNull
    public Property<T> invertProperty() {
        if (this.databaseProperty == null) {
            this.databaseProperty = new TypeConvertedProperty(this.table, this.nameAlias, !this.convertToDB, new C05071());
        }
        return this.databaseProperty;
    }
}
