package com.raizlabs.android.dbflow.sql.language;

import android.support.annotation.NonNull;
import com.raizlabs.android.dbflow.sql.language.property.IProperty;
import com.raizlabs.android.dbflow.sql.language.property.Property;

public class SQLite {
    @NonNull
    public static Select select(IProperty... properties) {
        return new Select(properties);
    }

    @NonNull
    public static Select selectCountOf(IProperty... properties) {
        return new Select(Method.count(properties));
    }

    @NonNull
    public static <TModel> Update<TModel> update(@NonNull Class<TModel> table) {
        return new Update(table);
    }

    @NonNull
    public static <TModel> Insert<TModel> insert(@NonNull Class<TModel> table) {
        return new Insert(table);
    }

    @NonNull
    public static Delete delete() {
        return new Delete();
    }

    @NonNull
    public static <TModel> From<TModel> delete(@NonNull Class<TModel> table) {
        return delete().from(table);
    }

    @NonNull
    public static <TModel> Index<TModel> index(@NonNull String name) {
        return new Index(name);
    }

    @NonNull
    public static Trigger createTrigger(@NonNull String name) {
        return Trigger.create(name);
    }

    @NonNull
    public static <TReturn> CaseCondition<TReturn> caseWhen(@NonNull SQLOperator operator) {
        return new Case().when(operator);
    }

    @NonNull
    public static <TReturn> Case<TReturn> _case(@NonNull Property<TReturn> caseColumn) {
        return new Case(caseColumn);
    }

    @NonNull
    public static <TReturn> Case<TReturn> _case(@NonNull IProperty caseColumn) {
        return new Case(caseColumn);
    }
}
