package com.raizlabs.android.dbflow.sql.language;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.sql.Query;
import com.raizlabs.android.dbflow.sql.QueryBuilder;
import com.raizlabs.android.dbflow.sql.language.Join.JoinType;
import com.raizlabs.android.dbflow.sql.language.NameAlias.Builder;
import com.raizlabs.android.dbflow.sql.language.property.IndexProperty;
import com.raizlabs.android.dbflow.sql.queriable.ModelQueriable;
import com.raizlabs.android.dbflow.structure.BaseModel.Action;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class From<TModel> extends BaseTransformable<TModel> {
    @NonNull
    private final List<Join> joins = new ArrayList();
    @NonNull
    private Query queryBase;
    @Nullable
    private NameAlias tableAlias;

    private NameAlias getTableAlias() {
        if (this.tableAlias == null) {
            this.tableAlias = new Builder(FlowManager.getTableName(getTable())).build();
        }
        return this.tableAlias;
    }

    public From(@NonNull Query querybase, @NonNull Class<TModel> table) {
        super(table);
        this.queryBase = querybase;
    }

    @NonNull
    public From<TModel> as(String alias) {
        this.tableAlias = getTableAlias().newBuilder().as(alias).build();
        return this;
    }

    @NonNull
    public <TJoin> Join<TJoin, TModel> join(Class<TJoin> table, @NonNull JoinType joinType) {
        Join<TJoin, TModel> join = new Join(this, (Class) table, joinType);
        this.joins.add(join);
        return join;
    }

    @NonNull
    public <TJoin> Join<TJoin, TModel> join(ModelQueriable<TJoin> modelQueriable, @NonNull JoinType joinType) {
        Join<TJoin, TModel> join = new Join(this, joinType, (ModelQueriable) modelQueriable);
        this.joins.add(join);
        return join;
    }

    @NonNull
    public <TJoin> Join<TJoin, TModel> crossJoin(Class<TJoin> table) {
        return join((Class) table, JoinType.CROSS);
    }

    @NonNull
    public <TJoin> Join<TJoin, TModel> crossJoin(ModelQueriable<TJoin> modelQueriable) {
        return join((ModelQueriable) modelQueriable, JoinType.CROSS);
    }

    @NonNull
    public <TJoin> Join<TJoin, TModel> innerJoin(Class<TJoin> table) {
        return join((Class) table, JoinType.INNER);
    }

    @NonNull
    public <TJoin> Join<TJoin, TModel> innerJoin(ModelQueriable<TJoin> modelQueriable) {
        return join((ModelQueriable) modelQueriable, JoinType.INNER);
    }

    @NonNull
    public <TJoin> Join<TJoin, TModel> leftOuterJoin(Class<TJoin> table) {
        return join((Class) table, JoinType.LEFT_OUTER);
    }

    @NonNull
    public <TJoin> Join<TJoin, TModel> leftOuterJoin(ModelQueriable<TJoin> modelQueriable) {
        return join((ModelQueriable) modelQueriable, JoinType.LEFT_OUTER);
    }

    @NonNull
    public <TJoin> Join<TJoin, TModel> naturalJoin(Class<TJoin> table) {
        return join((Class) table, JoinType.NATURAL);
    }

    @NonNull
    public <TJoin> Join<TJoin, TModel> naturalJoin(ModelQueriable<TJoin> modelQueriable) {
        return join((ModelQueriable) modelQueriable, JoinType.NATURAL);
    }

    @NonNull
    public IndexedBy<TModel> indexedBy(IndexProperty<TModel> indexProperty) {
        return new IndexedBy(indexProperty, this);
    }

    @NonNull
    public Action getPrimaryAction() {
        return this.queryBase instanceof Delete ? Action.DELETE : Action.CHANGE;
    }

    public String getQuery() {
        QueryBuilder queryBuilder = new QueryBuilder().append(this.queryBase.getQuery());
        if (!(this.queryBase instanceof Update)) {
            queryBuilder.append("FROM ");
        }
        queryBuilder.append(getTableAlias());
        if (this.queryBase instanceof Select) {
            if (!this.joins.isEmpty()) {
                queryBuilder.appendSpace();
            }
            for (Join join : this.joins) {
                queryBuilder.append(join.getQuery());
            }
        } else {
            queryBuilder.appendSpace();
        }
        return queryBuilder.getQuery();
    }

    @NonNull
    public Query getQueryBuilderBase() {
        return this.queryBase;
    }

    @NonNull
    public Set<Class<?>> getAssociatedTables() {
        Set<Class<?>> tables = new LinkedHashSet();
        tables.add(getTable());
        for (Join join : this.joins) {
            tables.add(join.getTable());
        }
        return tables;
    }
}
