package com.raizlabs.android.dbflow.sql.language.property;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.sql.language.BaseModelQueriable;
import com.raizlabs.android.dbflow.sql.language.IConditional;
import com.raizlabs.android.dbflow.sql.language.IOperator;
import com.raizlabs.android.dbflow.sql.language.NameAlias;
import com.raizlabs.android.dbflow.sql.language.NameAlias.Builder;
import com.raizlabs.android.dbflow.sql.language.Operator;
import com.raizlabs.android.dbflow.sql.language.Operator.Between;
import com.raizlabs.android.dbflow.sql.language.Operator.In;
import com.raizlabs.android.dbflow.sql.language.Operator.Operation;
import com.raizlabs.android.dbflow.sql.language.OrderBy;
import java.util.Collection;

public class Property<T> implements IProperty<Property<T>>, IConditional, IOperator<T> {
    public static final Property<?> ALL_PROPERTY = new Property<Object>(null, Operation.MULTIPLY) {
        @NonNull
        public /* bridge */ /* synthetic */ IProperty as(@NonNull String str) {
            return super.as(str);
        }

        @NonNull
        public /* bridge */ /* synthetic */ IProperty concatenate(@NonNull IProperty iProperty) {
            return super.concatenate(iProperty);
        }

        @NonNull
        public /* bridge */ /* synthetic */ IProperty distinct() {
            return super.distinct();
        }

        @NonNull
        public /* bridge */ /* synthetic */ IProperty div(@NonNull IProperty iProperty) {
            return super.div(iProperty);
        }

        @NonNull
        public /* bridge */ /* synthetic */ IProperty minus(@NonNull IProperty iProperty) {
            return super.minus(iProperty);
        }

        @NonNull
        public /* bridge */ /* synthetic */ IProperty plus(@NonNull IProperty iProperty) {
            return super.plus(iProperty);
        }

        @NonNull
        public /* bridge */ /* synthetic */ IProperty rem(@NonNull IProperty iProperty) {
            return super.rem(iProperty);
        }

        public /* bridge */ /* synthetic */ IProperty times(@NonNull IProperty iProperty) {
            return super.times(iProperty);
        }

        @NonNull
        public /* bridge */ /* synthetic */ IProperty withTable() {
            return super.withTable();
        }

        @NonNull
        public /* bridge */ /* synthetic */ IProperty withTable(@NonNull NameAlias nameAlias) {
            return super.withTable(nameAlias);
        }

        public String toString() {
            return this.nameAlias.nameRaw();
        }
    };
    public static final Property<?> WILDCARD = new Property(null, NameAlias.rawBuilder(Operation.EMPTY_PARAM).build());
    protected NameAlias nameAlias;
    @Nullable
    final Class<?> table;

    public Property(@Nullable Class<?> table, @NonNull NameAlias nameAlias) {
        this.table = table;
        this.nameAlias = nameAlias;
    }

    public Property(@Nullable Class<?> table, @Nullable String columnName) {
        this.table = table;
        if (columnName != null) {
            this.nameAlias = new Builder(columnName).build();
        }
    }

    public Property(@Nullable Class<?> table, @NonNull String columnName, @NonNull String aliasName) {
        this((Class) table, NameAlias.builder(columnName).as(aliasName).build());
    }

    @NonNull
    public Property<T> withTable() {
        return withTable(new Builder(FlowManager.getTableName(this.table)).build());
    }

    @NonNull
    public NameAlias getNameAlias() {
        return this.nameAlias;
    }

    public String getQuery() {
        return getNameAlias().getQuery();
    }

    @NonNull
    public String getCursorKey() {
        return getNameAlias().getQuery();
    }

    @NonNull
    public String getDefinition() {
        return getNameAlias().getFullQuery();
    }

    public String toString() {
        return getNameAlias().toString();
    }

    @NonNull
    public Operator is(@NonNull IConditional conditional) {
        return getCondition().is(conditional);
    }

    @NonNull
    public Operator eq(@NonNull IConditional conditional) {
        return getCondition().eq(conditional);
    }

    @NonNull
    public Operator isNot(@NonNull IConditional conditional) {
        return getCondition().isNot(conditional);
    }

    @NonNull
    public Operator notEq(@NonNull IConditional conditional) {
        return getCondition().notEq(conditional);
    }

    @NonNull
    public Operator like(@NonNull IConditional conditional) {
        return getCondition().like(conditional);
    }

    @NonNull
    public Operator glob(@NonNull IConditional conditional) {
        return getCondition().glob(conditional);
    }

    @NonNull
    public Operator<T> like(@NonNull String value) {
        return getCondition().like(value);
    }

    @NonNull
    public Operator<T> notLike(@NonNull String value) {
        return getCondition().notLike(value);
    }

    @NonNull
    public Operator<T> glob(@NonNull String value) {
        return getCondition().glob(value);
    }

    @NonNull
    public Operator greaterThan(@NonNull IConditional conditional) {
        return getCondition().greaterThan(conditional);
    }

    @NonNull
    public Operator greaterThanOrEq(@NonNull IConditional conditional) {
        return getCondition().greaterThanOrEq(conditional);
    }

    @NonNull
    public Operator lessThan(@NonNull IConditional conditional) {
        return getCondition().lessThan(conditional);
    }

    @NonNull
    public Operator lessThanOrEq(@NonNull IConditional conditional) {
        return getCondition().lessThanOrEq(conditional);
    }

    @NonNull
    public Between between(@NonNull IConditional conditional) {
        return getCondition().between(conditional);
    }

    @NonNull
    public In in(@NonNull IConditional firstConditional, @NonNull IConditional... conditionals) {
        return getCondition().in(firstConditional, conditionals);
    }

    @NonNull
    public In notIn(@NonNull IConditional firstConditional, @NonNull IConditional... conditionals) {
        return getCondition().notIn(firstConditional, conditionals);
    }

    @NonNull
    public Operator is(@NonNull BaseModelQueriable baseModelQueriable) {
        return getCondition().is(baseModelQueriable);
    }

    @NonNull
    public Operator isNull() {
        return getCondition().isNull();
    }

    @NonNull
    public Operator eq(@NonNull BaseModelQueriable baseModelQueriable) {
        return getCondition().eq(baseModelQueriable);
    }

    @NonNull
    public Operator isNot(@NonNull BaseModelQueriable baseModelQueriable) {
        return getCondition().isNot(baseModelQueriable);
    }

    @NonNull
    public Operator isNotNull() {
        return getCondition().isNotNull();
    }

    @NonNull
    public Operator notEq(@NonNull BaseModelQueriable baseModelQueriable) {
        return getCondition().notEq(baseModelQueriable);
    }

    @NonNull
    public Operator like(@NonNull BaseModelQueriable baseModelQueriable) {
        return getCondition().like(baseModelQueriable);
    }

    @NonNull
    public Operator notLike(@NonNull IConditional conditional) {
        return getCondition().notLike(conditional);
    }

    @NonNull
    public Operator notLike(@NonNull BaseModelQueriable baseModelQueriable) {
        return getCondition().notLike(baseModelQueriable);
    }

    @NonNull
    public Operator glob(@NonNull BaseModelQueriable baseModelQueriable) {
        return getCondition().glob(baseModelQueriable);
    }

    @NonNull
    public Operator greaterThan(@NonNull BaseModelQueriable baseModelQueriable) {
        return getCondition().greaterThan(baseModelQueriable);
    }

    @NonNull
    public Operator greaterThanOrEq(@NonNull BaseModelQueriable baseModelQueriable) {
        return getCondition().greaterThanOrEq(baseModelQueriable);
    }

    @NonNull
    public Operator lessThan(@NonNull BaseModelQueriable baseModelQueriable) {
        return getCondition().lessThan(baseModelQueriable);
    }

    @NonNull
    public Operator lessThanOrEq(@NonNull BaseModelQueriable baseModelQueriable) {
        return getCondition().lessThanOrEq(baseModelQueriable);
    }

    @NonNull
    public Between between(@NonNull BaseModelQueriable baseModelQueriable) {
        return getCondition().between(baseModelQueriable);
    }

    @NonNull
    public In in(@NonNull BaseModelQueriable firstBaseModelQueriable, @NonNull BaseModelQueriable... baseModelQueriables) {
        return getCondition().in(firstBaseModelQueriable, baseModelQueriables);
    }

    @NonNull
    public In notIn(@NonNull BaseModelQueriable firstBaseModelQueriable, @NonNull BaseModelQueriable... baseModelQueriables) {
        return getCondition().notIn(firstBaseModelQueriable, baseModelQueriables);
    }

    @NonNull
    public Operator concatenate(@NonNull IConditional conditional) {
        return getCondition().concatenate(conditional);
    }

    @NonNull
    public Operator plus(@NonNull BaseModelQueriable value) {
        return getCondition().plus(value);
    }

    @NonNull
    public Operator minus(@NonNull BaseModelQueriable value) {
        return getCondition().minus(value);
    }

    @NonNull
    public Operator div(@NonNull BaseModelQueriable value) {
        return getCondition().div(value);
    }

    @NonNull
    public Operator times(@NonNull BaseModelQueriable value) {
        return getCondition().times(value);
    }

    @NonNull
    public Operator rem(@NonNull BaseModelQueriable value) {
        return getCondition().rem(value);
    }

    @NonNull
    public Class<?> getTable() {
        return this.table;
    }

    @NonNull
    public Property<T> plus(@NonNull IProperty iProperty) {
        return new Property(this.table, NameAlias.joinNames(Operation.PLUS, this.nameAlias.fullName(), iProperty.toString()));
    }

    @NonNull
    public Property<T> minus(@NonNull IProperty iProperty) {
        return new Property(this.table, NameAlias.joinNames(Operation.MINUS, this.nameAlias.fullName(), iProperty.toString()));
    }

    @NonNull
    public Property<T> div(@NonNull IProperty iProperty) {
        return new Property(this.table, NameAlias.joinNames(Operation.DIVISION, this.nameAlias.fullName(), iProperty.toString()));
    }

    public Property<T> times(@NonNull IProperty iProperty) {
        return new Property(this.table, NameAlias.joinNames(Operation.MULTIPLY, this.nameAlias.fullName(), iProperty.toString()));
    }

    @NonNull
    public Property<T> rem(@NonNull IProperty iProperty) {
        return new Property(this.table, NameAlias.joinNames(Operation.MOD, this.nameAlias.fullName(), iProperty.toString()));
    }

    @NonNull
    public Property<T> concatenate(@NonNull IProperty iProperty) {
        return new Property(this.table, NameAlias.joinNames(Operation.CONCATENATE, this.nameAlias.fullName(), iProperty.toString()));
    }

    @NonNull
    public Property<T> as(@NonNull String aliasName) {
        return new Property(this.table, getNameAlias().newBuilder().as(aliasName).build());
    }

    @NonNull
    public Property<T> distinct() {
        return new Property(this.table, getDistinctAliasName());
    }

    @NonNull
    public Property<T> withTable(@NonNull NameAlias tableNameAlias) {
        return new Property(this.table, getNameAlias().newBuilder().withTable(tableNameAlias.getQuery()).build());
    }

    @NonNull
    public Operator<T> is(T value) {
        return getCondition().is((Object) value);
    }

    @NonNull
    public Operator<T> eq(T value) {
        return getCondition().eq((Object) value);
    }

    @NonNull
    public Operator<T> isNot(T value) {
        return getCondition().isNot((Object) value);
    }

    @NonNull
    public Operator<T> notEq(T value) {
        return getCondition().notEq((Object) value);
    }

    @NonNull
    public Operator<T> greaterThan(@NonNull T value) {
        return getCondition().greaterThan((Object) value);
    }

    @NonNull
    public Operator<T> greaterThanOrEq(@NonNull T value) {
        return getCondition().greaterThanOrEq((Object) value);
    }

    @NonNull
    public Operator<T> lessThan(@NonNull T value) {
        return getCondition().lessThan((Object) value);
    }

    @NonNull
    public Operator<T> lessThanOrEq(@NonNull T value) {
        return getCondition().lessThanOrEq((Object) value);
    }

    @NonNull
    public Between<T> between(@NonNull T value) {
        return getCondition().between((Object) value);
    }

    @NonNull
    public In<T> in(@NonNull T firstValue, T... values) {
        return getCondition().in((Object) firstValue, (Object[]) values);
    }

    @NonNull
    public In<T> notIn(@NonNull T firstValue, T... values) {
        return getCondition().notIn((Object) firstValue, (Object[]) values);
    }

    @NonNull
    public In<T> in(@NonNull Collection<T> values) {
        return getCondition().in(values);
    }

    @NonNull
    public In<T> notIn(@NonNull Collection<T> values) {
        return getCondition().notIn(values);
    }

    @NonNull
    public Operator<T> concatenate(T value) {
        return getCondition().concatenate((Object) value);
    }

    @NonNull
    public Operator<T> plus(@NonNull T value) {
        return getCondition().plus((Object) value);
    }

    @NonNull
    public Operator<T> minus(@NonNull T value) {
        return getCondition().minus((Object) value);
    }

    @NonNull
    public Operator<T> div(@NonNull T value) {
        return getCondition().div((Object) value);
    }

    public Operator<T> times(@NonNull T value) {
        return getCondition().times((Object) value);
    }

    @NonNull
    public Operator<T> rem(@NonNull T value) {
        return getCondition().rem((Object) value);
    }

    @NonNull
    public OrderBy asc() {
        return OrderBy.fromProperty(this).ascending();
    }

    @NonNull
    public OrderBy desc() {
        return OrderBy.fromProperty(this).descending();
    }

    protected NameAlias getDistinctAliasName() {
        return getNameAlias().newBuilder().distinct().build();
    }

    @NonNull
    protected Operator<T> getCondition() {
        return Operator.op(getNameAlias());
    }
}
