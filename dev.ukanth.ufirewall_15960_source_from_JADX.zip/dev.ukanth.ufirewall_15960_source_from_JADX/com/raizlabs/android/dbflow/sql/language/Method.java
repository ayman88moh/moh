package com.raizlabs.android.dbflow.sql.language;

import android.support.annotation.NonNull;
import com.raizlabs.android.dbflow.sql.SQLiteType;
import com.raizlabs.android.dbflow.sql.language.property.IProperty;
import com.raizlabs.android.dbflow.sql.language.property.Property;
import com.raizlabs.android.dbflow.sql.language.property.PropertyFactory;
import java.util.ArrayList;
import java.util.List;

public class Method extends Property {
    private final IProperty methodProperty;
    private List<String> operationsList;
    private final List<IProperty> propertyList;

    public static class Cast {
        private final IProperty property;

        private Cast(@NonNull IProperty property) {
            this.property = property;
        }

        public IProperty as(SQLiteType sqLiteType) {
            IProperty newProperty = new Property(this.property.getTable(), this.property.getNameAlias().newBuilder().shouldAddIdentifierToAliasName(false).as(sqLiteType.name()).build());
            return new Method("CAST", newProperty);
        }
    }

    @NonNull
    public static Method avg(IProperty... properties) {
        return new Method("AVG", properties);
    }

    @NonNull
    public static Method count(IProperty... properties) {
        return new Method("COUNT", properties);
    }

    @NonNull
    public static Method group_concat(IProperty... properties) {
        return new Method("GROUP_CONCAT", properties);
    }

    @NonNull
    public static Method max(IProperty... properties) {
        return new Method("MAX", properties);
    }

    @NonNull
    public static Method min(IProperty... properties) {
        return new Method("MIN", properties);
    }

    @NonNull
    public static Method sum(IProperty... properties) {
        return new Method("SUM", properties);
    }

    @NonNull
    public static Method total(IProperty... properties) {
        return new Method("TOTAL", properties);
    }

    @NonNull
    public static Cast cast(@NonNull IProperty property) {
        return new Cast(property);
    }

    @NonNull
    public static Method replace(@NonNull IProperty property, String findString, String replacement) {
        return new Method("REPLACE", property, PropertyFactory.from((Object) findString), PropertyFactory.from((Object) replacement));
    }

    public static Method strftime(@NonNull String formatString, @NonNull String timeString, String... modifiers) {
        List<IProperty> propertyList = new ArrayList();
        propertyList.add(PropertyFactory.from((Object) formatString));
        propertyList.add(PropertyFactory.from((Object) timeString));
        for (Object modifier : modifiers) {
            propertyList.add(PropertyFactory.from(modifier));
        }
        return new Method("strftime", (IProperty[]) propertyList.toArray(new IProperty[propertyList.size()]));
    }

    public static Method datetime(long timeStamp, String... modifiers) {
        List<IProperty> propertyList = new ArrayList();
        propertyList.add(PropertyFactory.from(timeStamp));
        for (Object modifier : modifiers) {
            propertyList.add(PropertyFactory.from(modifier));
        }
        return new Method("datetime", (IProperty[]) propertyList.toArray(new IProperty[propertyList.size()]));
    }

    public static Method date(@NonNull String timeString, String... modifiers) {
        List<IProperty> propertyList = new ArrayList();
        propertyList.add(PropertyFactory.from((Object) timeString));
        for (Object modifier : modifiers) {
            propertyList.add(PropertyFactory.from(modifier));
        }
        return new Method("date", (IProperty[]) propertyList.toArray(new IProperty[propertyList.size()]));
    }

    public static Method ifNull(@NonNull IProperty first, @NonNull IProperty secondIfFirstNull) {
        return new Method("IFNULL", first, secondIfFirstNull);
    }

    public static Method nullIf(@NonNull IProperty first, @NonNull IProperty second) {
        return new Method("NULLIF", first, second);
    }

    public Method(IProperty... properties) {
        this(null, properties);
    }

    public Method(String methodName, IProperty... properties) {
        super(null, (String) null);
        this.propertyList = new ArrayList();
        this.operationsList = new ArrayList();
        this.methodProperty = new Property(null, NameAlias.rawBuilder(methodName).build());
        if (properties.length == 0) {
            this.propertyList.add(Property.ALL_PROPERTY);
            return;
        }
        for (IProperty property : properties) {
            addProperty(property);
        }
    }

    @NonNull
    public Method plus(@NonNull IProperty property) {
        return append(property, " +");
    }

    @NonNull
    public Method minus(@NonNull IProperty property) {
        return append(property, " -");
    }

    @NonNull
    public Property div(@NonNull IProperty property) {
        return append(property, " /");
    }

    public Property times(@NonNull IProperty property) {
        return append(property, " *");
    }

    @NonNull
    public Property rem(@NonNull IProperty property) {
        return append(property, " %");
    }

    public Method addProperty(@NonNull IProperty property) {
        return append(property, ",");
    }

    public Method append(IProperty property, String operation) {
        if (this.propertyList.size() == 1 && this.propertyList.get(0) == Property.ALL_PROPERTY) {
            this.propertyList.remove(0);
        }
        this.propertyList.add(property);
        this.operationsList.add(operation);
        return this;
    }

    @NonNull
    protected List<IProperty> getPropertyList() {
        return this.propertyList;
    }

    @NonNull
    public NameAlias getNameAlias() {
        if (this.nameAlias == null) {
            String query = this.methodProperty.getQuery();
            if (query == null) {
                query = "";
            }
            query = query + "(";
            List<IProperty> propertyList = getPropertyList();
            for (int i = 0; i < propertyList.size(); i++) {
                IProperty property = (IProperty) propertyList.get(i);
                if (i > 0) {
                    query = query + ((String) this.operationsList.get(i)) + " ";
                }
                query = query + property.toString();
            }
            this.nameAlias = NameAlias.rawBuilder(query + ")").build();
        }
        return this.nameAlias;
    }
}
