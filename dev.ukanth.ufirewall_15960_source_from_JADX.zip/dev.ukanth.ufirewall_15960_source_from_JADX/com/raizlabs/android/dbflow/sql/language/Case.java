package com.raizlabs.android.dbflow.sql.language;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.sql.Query;
import com.raizlabs.android.dbflow.sql.QueryBuilder;
import com.raizlabs.android.dbflow.sql.language.property.IProperty;
import com.raizlabs.android.dbflow.sql.language.property.Property;
import java.util.ArrayList;
import java.util.List;

public class Case<TReturn> implements Query {
    private IProperty caseColumn;
    private List<CaseCondition<TReturn>> caseConditions = new ArrayList();
    private String columnName;
    private boolean efficientCase = false;
    private boolean elseSpecified = false;
    private TReturn elseValue;
    private boolean endSpecified = false;

    Case() {
    }

    Case(IProperty caseColumn) {
        this.caseColumn = caseColumn;
        if (caseColumn != null) {
            this.efficientCase = true;
        }
    }

    @NonNull
    public CaseCondition<TReturn> when(@NonNull SQLOperator sqlOperator) {
        if (this.efficientCase) {
            throw new IllegalStateException("When using the efficient CASE method,you must pass in value only, not condition.");
        }
        CaseCondition<TReturn> caseCondition = new CaseCondition(this, sqlOperator);
        this.caseConditions.add(caseCondition);
        return caseCondition;
    }

    @NonNull
    public CaseCondition<TReturn> when(@Nullable TReturn whenValue) {
        if (this.efficientCase) {
            CaseCondition<TReturn> caseCondition = new CaseCondition(this, (Object) whenValue);
            this.caseConditions.add(caseCondition);
            return caseCondition;
        }
        throw new IllegalStateException("When not using the efficient CASE method, you must pass in the SQLOperator as a parameter");
    }

    @NonNull
    public CaseCondition<TReturn> when(@NonNull IProperty property) {
        if (this.efficientCase) {
            CaseCondition<TReturn> caseCondition = new CaseCondition(this, property);
            this.caseConditions.add(caseCondition);
            return caseCondition;
        }
        throw new IllegalStateException("When not using the efficient CASE method, you must pass in the SQLOperator as a parameter");
    }

    @NonNull
    public Case<TReturn> _else(@Nullable TReturn elseValue) {
        this.elseValue = elseValue;
        this.elseSpecified = true;
        return this;
    }

    @NonNull
    public Property<Case<TReturn>> end(@Nullable String columnName) {
        this.endSpecified = true;
        if (columnName != null) {
            this.columnName = QueryBuilder.quoteIfNeeded(columnName);
        }
        return new Property(null, NameAlias.rawBuilder(getQuery()).build());
    }

    @NonNull
    public Property<Case<TReturn>> end() {
        return end(null);
    }

    @NonNull
    public Operator endAsOperator() {
        return Operator.op(end().getNameAlias());
    }

    boolean isEfficientCase() {
        return this.efficientCase;
    }

    public String getQuery() {
        QueryBuilder queryBuilder = new QueryBuilder(" CASE");
        if (isEfficientCase()) {
            queryBuilder.append(" " + BaseOperator.convertValueToString(this.caseColumn, false));
        }
        queryBuilder.append(QueryBuilder.join((CharSequence) "", this.caseConditions));
        if (this.elseSpecified) {
            queryBuilder.append(" ELSE ").append(BaseOperator.convertValueToString(this.elseValue, false));
        }
        if (this.endSpecified) {
            queryBuilder.append(" END " + (this.columnName != null ? this.columnName : ""));
        }
        return queryBuilder.getQuery();
    }
}
