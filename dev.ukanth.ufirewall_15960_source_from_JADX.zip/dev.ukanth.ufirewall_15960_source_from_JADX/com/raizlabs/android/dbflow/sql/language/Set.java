package com.raizlabs.android.dbflow.sql.language;

import android.content.ContentValues;
import android.support.annotation.NonNull;
import com.raizlabs.android.dbflow.sql.Query;
import com.raizlabs.android.dbflow.sql.QueryBuilder;
import com.raizlabs.android.dbflow.sql.SqlUtils;
import com.raizlabs.android.dbflow.structure.BaseModel.Action;

public class Set<TModel> extends BaseTransformable<TModel> implements WhereBase<TModel> {
    private OperatorGroup operatorGroup = OperatorGroup.nonGroupingClause().setAllCommaSeparated(true);
    private Query update;

    public Set(@NonNull Query update, @NonNull Class<TModel> table) {
        super(table);
        this.update = update;
    }

    @NonNull
    public Set<TModel> conditions(SQLOperator... conditions) {
        this.operatorGroup.andAll(conditions);
        return this;
    }

    @NonNull
    public Set<TModel> conditionValues(@NonNull ContentValues contentValues) {
        SqlUtils.addContentValues(contentValues, this.operatorGroup);
        return this;
    }

    public String getQuery() {
        return new QueryBuilder(this.update.getQuery()).append("SET ").append(this.operatorGroup.getQuery()).appendSpace().getQuery();
    }

    @NonNull
    public Query getQueryBuilderBase() {
        return this.update;
    }

    @NonNull
    public Action getPrimaryAction() {
        return Action.UPDATE;
    }
}
