package com.raizlabs.android.dbflow.sql.language;

import android.support.annotation.NonNull;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.sql.QueryBuilder;
import com.raizlabs.android.dbflow.sql.language.property.IProperty;
import com.raizlabs.android.dbflow.sql.queriable.ModelQueriable;
import com.raizlabs.android.dbflow.structure.BaseModel.Action;
import com.raizlabs.android.dbflow.structure.database.DatabaseWrapper;
import com.raizlabs.android.dbflow.structure.database.FlowCursor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class Where<TModel> extends BaseModelQueriable<TModel> implements ModelQueriable<TModel>, Transformable<TModel> {
    private static final int VALUE_UNSET = -1;
    private final List<NameAlias> groupByList = new ArrayList();
    private OperatorGroup havingGroup;
    private int limit = -1;
    private int offset = -1;
    private OperatorGroup operatorGroup;
    private final List<OrderBy> orderByList = new ArrayList();
    private final WhereBase<TModel> whereBase;

    public Where(@NonNull WhereBase<TModel> whereBase, SQLOperator... conditions) {
        super(whereBase.getTable());
        this.whereBase = whereBase;
        this.operatorGroup = OperatorGroup.nonGroupingClause();
        this.havingGroup = OperatorGroup.nonGroupingClause();
        this.operatorGroup.andAll(conditions);
    }

    @NonNull
    public Where<TModel> and(@NonNull SQLOperator condition) {
        this.operatorGroup.and(condition);
        return this;
    }

    @NonNull
    public Where<TModel> or(@NonNull SQLOperator condition) {
        this.operatorGroup.or(condition);
        return this;
    }

    @NonNull
    public Where<TModel> andAll(@NonNull List<SQLOperator> conditions) {
        this.operatorGroup.andAll((Collection) conditions);
        return this;
    }

    @NonNull
    public Where<TModel> andAll(SQLOperator... conditions) {
        this.operatorGroup.andAll(conditions);
        return this;
    }

    @NonNull
    public Where<TModel> groupBy(NameAlias... columns) {
        Collections.addAll(this.groupByList, columns);
        return this;
    }

    @NonNull
    public Where<TModel> groupBy(IProperty... properties) {
        for (IProperty property : properties) {
            this.groupByList.add(property.getNameAlias());
        }
        return this;
    }

    @NonNull
    public Where<TModel> having(SQLOperator... conditions) {
        this.havingGroup.andAll(conditions);
        return this;
    }

    @NonNull
    public Where<TModel> orderBy(@NonNull NameAlias nameAlias, boolean ascending) {
        this.orderByList.add(new OrderBy(nameAlias, ascending));
        return this;
    }

    @NonNull
    public Where<TModel> orderBy(@NonNull IProperty property, boolean ascending) {
        this.orderByList.add(new OrderBy(property.getNameAlias(), ascending));
        return this;
    }

    @NonNull
    public Where<TModel> orderBy(@NonNull OrderBy orderBy) {
        this.orderByList.add(orderBy);
        return this;
    }

    @NonNull
    public Where<TModel> orderByAll(@NonNull List<OrderBy> orderBies) {
        this.orderByList.addAll(orderBies);
        return this;
    }

    @NonNull
    public Where<TModel> limit(int count) {
        this.limit = count;
        return this;
    }

    @NonNull
    public Where<TModel> offset(int offset) {
        this.offset = offset;
        return this;
    }

    @NonNull
    public Where<TModel> exists(@NonNull Where where) {
        this.operatorGroup.and(new ExistenceOperator().where(where));
        return this;
    }

    @NonNull
    public Action getPrimaryAction() {
        return this.whereBase.getPrimaryAction();
    }

    public String getQuery() {
        QueryBuilder queryBuilder = new QueryBuilder().append(this.whereBase.getQuery().trim()).appendSpace().appendQualifier("WHERE", this.operatorGroup.getQuery()).appendQualifier("GROUP BY", QueryBuilder.join((CharSequence) ",", this.groupByList)).appendQualifier("HAVING", this.havingGroup.getQuery()).appendQualifier("ORDER BY", QueryBuilder.join((CharSequence) ",", this.orderByList));
        if (this.limit > -1) {
            queryBuilder.appendQualifier("LIMIT", String.valueOf(this.limit));
        }
        if (this.offset > -1) {
            queryBuilder.appendQualifier("OFFSET", String.valueOf(this.offset));
        }
        return queryBuilder.getQuery();
    }

    public FlowCursor query(@NonNull DatabaseWrapper wrapper) {
        if (this.whereBase.getQueryBuilderBase() instanceof Select) {
            return wrapper.rawQuery(getQuery(), null);
        }
        return super.query(wrapper);
    }

    public FlowCursor query() {
        return query(FlowManager.getDatabaseForTable(getTable()).getWritableDatabase());
    }

    @NonNull
    public List<TModel> queryList() {
        checkSelect("query");
        return super.queryList();
    }

    public TModel querySingle() {
        checkSelect("query");
        limit(1);
        return super.querySingle();
    }

    @NonNull
    public WhereBase<TModel> getWhereBase() {
        return this.whereBase;
    }

    private void checkSelect(String methodName) {
        if (!(this.whereBase.getQueryBuilderBase() instanceof Select)) {
            throw new IllegalArgumentException("Please use " + methodName + "(). The beginning is not a ISelect");
        }
    }
}
