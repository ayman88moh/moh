package com.raizlabs.android.dbflow.sql.language;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.annotation.Collate;
import com.raizlabs.android.dbflow.config.FlowLog;
import com.raizlabs.android.dbflow.config.FlowLog.Level;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.converter.TypeConverter;
import com.raizlabs.android.dbflow.sql.Query;
import com.raizlabs.android.dbflow.sql.QueryBuilder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class Operator<T> extends BaseOperator implements IOperator<T> {
    private boolean convertToDB;
    private TypeConverter typeConverter;

    public static class Operation {
        public static final String AND = "AND";
        public static final String BETWEEN = "BETWEEN";
        public static final String CONCATENATE = "||";
        public static final String DIVISION = "/";
        public static final String EMPTY_PARAM = "?";
        public static final String EQUALS = "=";
        public static final String GLOB = "GLOB";
        public static final String GREATER_THAN = ">";
        public static final String GREATER_THAN_OR_EQUALS = ">=";
        public static final String IN = "IN";
        public static final String IS_NOT_NULL = "IS NOT NULL";
        public static final String IS_NULL = "IS NULL";
        public static final String LESS_THAN = "<";
        public static final String LESS_THAN_OR_EQUALS = "<=";
        public static final String LIKE = "LIKE";
        public static final String MINUS = "-";
        public static final String MOD = "%";
        public static final String MULTIPLY = "*";
        public static final String NOT_EQUALS = "!=";
        public static final String NOT_IN = "NOT IN";
        public static final String NOT_LIKE = "NOT LIKE";
        public static final String OR = "OR";
        public static final String PLUS = "+";
    }

    public static class Between<T> extends BaseOperator implements Query {
        @Nullable
        private T secondValue;

        private Between(Operator<T> operator, T value) {
            super(operator.nameAlias);
            this.operation = String.format(" %1s ", new Object[]{Operation.BETWEEN});
            this.value = value;
            this.isValueSet = true;
            this.postArg = operator.postArgument();
        }

        @NonNull
        public Between<T> and(@Nullable T secondValue) {
            this.secondValue = secondValue;
            return this;
        }

        @Nullable
        public T secondValue() {
            return this.secondValue;
        }

        public void appendConditionToQuery(@NonNull QueryBuilder queryBuilder) {
            queryBuilder.append(columnName()).append(operation()).append(convertObjectToString(value(), true)).appendSpaceSeparated(Operation.AND).append(convertObjectToString(secondValue(), true)).appendSpace().appendOptional(postArgument());
        }

        public String getQuery() {
            QueryBuilder builder = new QueryBuilder();
            appendConditionToQuery(builder);
            return builder.getQuery();
        }
    }

    public static class In<T> extends BaseOperator implements Query {
        private List<T> inArguments;

        @SafeVarargs
        private In(Operator<T> operator, T firstArgument, boolean isIn, T... arguments) {
            super(operator.columnAlias());
            this.inArguments = new ArrayList();
            this.inArguments.add(firstArgument);
            Collections.addAll(this.inArguments, arguments);
            String str = " %1s ";
            Object[] objArr = new Object[1];
            objArr[0] = isIn ? Operation.IN : Operation.NOT_IN;
            this.operation = String.format(str, objArr);
        }

        private In(Operator<T> operator, Collection<T> args, boolean isIn) {
            super(operator.columnAlias());
            this.inArguments = new ArrayList();
            this.inArguments.addAll(args);
            String str = " %1s ";
            Object[] objArr = new Object[1];
            objArr[0] = isIn ? Operation.IN : Operation.NOT_IN;
            this.operation = String.format(str, objArr);
        }

        @NonNull
        public In<T> and(@Nullable T argument) {
            this.inArguments.add(argument);
            return this;
        }

        public void appendConditionToQuery(@NonNull QueryBuilder queryBuilder) {
            queryBuilder.append(columnName()).append(operation()).append("(").append(BaseOperator.joinArguments(",", this.inArguments, this)).append(")");
        }

        public String getQuery() {
            QueryBuilder builder = new QueryBuilder();
            appendConditionToQuery(builder);
            return builder.getQuery();
        }
    }

    public static String convertValueToString(Object value) {
        return BaseOperator.convertValueToString(value, false);
    }

    @NonNull
    public static <T> Operator<T> op(NameAlias column) {
        return new Operator(column);
    }

    @NonNull
    public static <T> Operator<T> op(NameAlias alias, TypeConverter typeConverter, boolean convertToDB) {
        return new Operator(alias, typeConverter, convertToDB);
    }

    Operator(NameAlias nameAlias) {
        super(nameAlias);
    }

    Operator(NameAlias alias, TypeConverter typeConverter, boolean convertToDB) {
        super(alias);
        this.typeConverter = typeConverter;
        this.convertToDB = convertToDB;
    }

    Operator(Operator operator) {
        super(operator.nameAlias);
        this.typeConverter = operator.typeConverter;
        this.convertToDB = operator.convertToDB;
        this.value = operator.value;
    }

    public void appendConditionToQuery(@NonNull QueryBuilder queryBuilder) {
        queryBuilder.append(columnName()).append(operation());
        if (this.isValueSet) {
            queryBuilder.append(convertObjectToString(value(), true));
        }
        if (postArgument() != null) {
            queryBuilder.appendSpace().append(postArgument());
        }
    }

    @NonNull
    public Operator<T> is(T value) {
        this.operation = Operation.EQUALS;
        return value(value);
    }

    @NonNull
    public Operator<T> eq(T value) {
        return is((Object) value);
    }

    @NonNull
    public Operator<T> isNot(T value) {
        this.operation = Operation.NOT_EQUALS;
        return value(value);
    }

    @NonNull
    public Operator<T> notEq(T value) {
        return isNot((Object) value);
    }

    @NonNull
    public Operator<T> like(@NonNull String value) {
        this.operation = String.format(" %1s ", new Object[]{Operation.LIKE});
        return value(value);
    }

    @NonNull
    public Operator<T> notLike(@NonNull String value) {
        this.operation = String.format(" %1s ", new Object[]{Operation.NOT_LIKE});
        return value(value);
    }

    @NonNull
    public Operator<T> glob(@NonNull String value) {
        this.operation = String.format(" %1s ", new Object[]{Operation.GLOB});
        return value(value);
    }

    public Operator<T> value(Object value) {
        this.value = value;
        this.isValueSet = true;
        return this;
    }

    @NonNull
    public Operator<T> greaterThan(@NonNull T value) {
        this.operation = Operation.GREATER_THAN;
        return value(value);
    }

    @NonNull
    public Operator<T> greaterThanOrEq(@NonNull T value) {
        this.operation = Operation.GREATER_THAN_OR_EQUALS;
        return value(value);
    }

    @NonNull
    public Operator<T> lessThan(@NonNull T value) {
        this.operation = Operation.LESS_THAN;
        return value(value);
    }

    @NonNull
    public Operator<T> lessThanOrEq(@NonNull T value) {
        this.operation = Operation.LESS_THAN_OR_EQUALS;
        return value(value);
    }

    @NonNull
    public Operator<T> plus(@NonNull T value) {
        return assignValueOp(value, Operation.PLUS);
    }

    @NonNull
    public Operator<T> minus(@NonNull T value) {
        return assignValueOp(value, Operation.MINUS);
    }

    @NonNull
    public Operator<T> div(@NonNull T value) {
        return assignValueOp(value, Operation.DIVISION);
    }

    public Operator<T> times(@NonNull T value) {
        return assignValueOp(value, Operation.MULTIPLY);
    }

    @NonNull
    public Operator<T> rem(@NonNull T value) {
        return assignValueOp(value, Operation.MOD);
    }

    @NonNull
    public Operator<T> operation(String operation) {
        this.operation = operation;
        return this;
    }

    @NonNull
    public Operator<T> collate(String collation) {
        this.postArg = "COLLATE " + collation;
        return this;
    }

    @NonNull
    public Operator<T> collate(Collate collation) {
        if (collation.equals(Collate.NONE)) {
            this.postArg = null;
        } else {
            collate(collation.name());
        }
        return this;
    }

    @NonNull
    public Operator<T> postfix(String postfix) {
        this.postArg = postfix;
        return this;
    }

    @NonNull
    public Operator<T> isNull() {
        this.operation = String.format(" %1s ", new Object[]{Operation.IS_NULL});
        return this;
    }

    @NonNull
    public Operator<T> isNotNull() {
        this.operation = String.format(" %1s ", new Object[]{Operation.IS_NOT_NULL});
        return this;
    }

    @NonNull
    public Operator<T> separator(@NonNull String separator) {
        this.separator = separator;
        return this;
    }

    @NonNull
    public Operator is(@NonNull IConditional conditional) {
        return assignValueOp(conditional, Operation.EQUALS);
    }

    @NonNull
    public Operator eq(@NonNull IConditional conditional) {
        return assignValueOp(conditional, Operation.EQUALS);
    }

    @NonNull
    public Operator isNot(@NonNull IConditional conditional) {
        return assignValueOp(conditional, Operation.NOT_EQUALS);
    }

    @NonNull
    public Operator notEq(@NonNull IConditional conditional) {
        return assignValueOp(conditional, Operation.NOT_EQUALS);
    }

    @NonNull
    public Operator<T> like(@NonNull IConditional conditional) {
        return like(conditional.getQuery());
    }

    @NonNull
    public Operator<T> glob(@NonNull IConditional conditional) {
        return glob(conditional.getQuery());
    }

    @NonNull
    public Operator<T> greaterThan(@NonNull IConditional conditional) {
        return assignValueOp(conditional, Operation.GREATER_THAN);
    }

    @NonNull
    public Operator<T> greaterThanOrEq(@NonNull IConditional conditional) {
        return assignValueOp(conditional, Operation.GREATER_THAN_OR_EQUALS);
    }

    @NonNull
    public Operator<T> lessThan(@NonNull IConditional conditional) {
        return assignValueOp(conditional, Operation.LESS_THAN);
    }

    @NonNull
    public Operator<T> lessThanOrEq(@NonNull IConditional conditional) {
        return assignValueOp(conditional, Operation.LESS_THAN_OR_EQUALS);
    }

    @NonNull
    public Between between(@NonNull IConditional conditional) {
        return new Between(conditional);
    }

    @NonNull
    public In in(@NonNull IConditional firstConditional, @NonNull IConditional... conditionals) {
        return new In(firstConditional, true, conditionals);
    }

    @NonNull
    public In notIn(@NonNull IConditional firstConditional, @NonNull IConditional... conditionals) {
        return new In(firstConditional, false, conditionals);
    }

    @NonNull
    public In notIn(@NonNull BaseModelQueriable firstBaseModelQueriable, @NonNull BaseModelQueriable[] baseModelQueriables) {
        return new In(firstBaseModelQueriable, false, (Object[]) baseModelQueriables);
    }

    @NonNull
    public Operator is(@NonNull BaseModelQueriable baseModelQueriable) {
        return assignValueOp(baseModelQueriable, Operation.EQUALS);
    }

    @NonNull
    public Operator eq(@NonNull BaseModelQueriable baseModelQueriable) {
        return assignValueOp(baseModelQueriable, Operation.EQUALS);
    }

    @NonNull
    public Operator isNot(@NonNull BaseModelQueriable baseModelQueriable) {
        return assignValueOp(baseModelQueriable, Operation.NOT_EQUALS);
    }

    @NonNull
    public Operator notEq(@NonNull BaseModelQueriable baseModelQueriable) {
        return assignValueOp(baseModelQueriable, Operation.NOT_EQUALS);
    }

    @NonNull
    public Operator<T> like(@NonNull BaseModelQueriable baseModelQueriable) {
        return assignValueOp(baseModelQueriable, Operation.LIKE);
    }

    @NonNull
    public Operator notLike(@NonNull IConditional conditional) {
        return assignValueOp(conditional, Operation.NOT_LIKE);
    }

    @NonNull
    public Operator notLike(@NonNull BaseModelQueriable baseModelQueriable) {
        return assignValueOp(baseModelQueriable, Operation.NOT_LIKE);
    }

    @NonNull
    public Operator<T> glob(@NonNull BaseModelQueriable baseModelQueriable) {
        return assignValueOp(baseModelQueriable, Operation.GLOB);
    }

    @NonNull
    public Operator<T> greaterThan(@NonNull BaseModelQueriable baseModelQueriable) {
        return assignValueOp(baseModelQueriable, Operation.GREATER_THAN);
    }

    @NonNull
    public Operator<T> greaterThanOrEq(@NonNull BaseModelQueriable baseModelQueriable) {
        return assignValueOp(baseModelQueriable, Operation.GREATER_THAN_OR_EQUALS);
    }

    @NonNull
    public Operator<T> lessThan(@NonNull BaseModelQueriable baseModelQueriable) {
        return assignValueOp(baseModelQueriable, Operation.LESS_THAN);
    }

    @NonNull
    public Operator<T> lessThanOrEq(@NonNull BaseModelQueriable baseModelQueriable) {
        return assignValueOp(baseModelQueriable, Operation.LESS_THAN_OR_EQUALS);
    }

    @NonNull
    public Operator plus(IConditional value) {
        return assignValueOp(value, Operation.PLUS);
    }

    @NonNull
    public Operator minus(IConditional value) {
        return assignValueOp(value, Operation.MINUS);
    }

    @NonNull
    public Operator div(IConditional value) {
        return assignValueOp(value, Operation.DIVISION);
    }

    @NonNull
    public Operator times(IConditional value) {
        return assignValueOp(value, Operation.MULTIPLY);
    }

    @NonNull
    public Operator rem(IConditional value) {
        return assignValueOp(value, Operation.MOD);
    }

    @NonNull
    public Operator plus(@NonNull BaseModelQueriable value) {
        return assignValueOp(value, Operation.PLUS);
    }

    @NonNull
    public Operator minus(@NonNull BaseModelQueriable value) {
        return assignValueOp(value, Operation.MINUS);
    }

    @NonNull
    public Operator div(@NonNull BaseModelQueriable value) {
        return assignValueOp(value, Operation.DIVISION);
    }

    @NonNull
    public Operator times(@NonNull BaseModelQueriable value) {
        return assignValueOp(value, Operation.MULTIPLY);
    }

    @NonNull
    public Operator rem(@NonNull BaseModelQueriable value) {
        return assignValueOp(value, Operation.MOD);
    }

    @NonNull
    public Between between(@NonNull BaseModelQueriable baseModelQueriable) {
        return new Between(baseModelQueriable);
    }

    @NonNull
    public In in(@NonNull BaseModelQueriable firstBaseModelQueriable, @NonNull BaseModelQueriable... baseModelQueriables) {
        return new In(firstBaseModelQueriable, true, baseModelQueriables);
    }

    public String getQuery() {
        QueryBuilder queryBuilder = new QueryBuilder();
        appendConditionToQuery(queryBuilder);
        return queryBuilder.getQuery();
    }

    @NonNull
    public Operator<T> concatenate(Object value) {
        this.operation = new QueryBuilder(Operation.EQUALS).append(columnName()).toString();
        TypeConverter typeConverter = this.typeConverter;
        if (typeConverter == null && value != null) {
            typeConverter = FlowManager.getTypeConverterForClass(value.getClass());
        }
        if (typeConverter != null && this.convertToDB) {
            value = typeConverter.getDBValue(value);
        }
        if ((value instanceof String) || (value instanceof IOperator) || (value instanceof Character)) {
            this.operation = String.format("%1s %1s ", new Object[]{this.operation, Operation.CONCATENATE});
        } else if (value instanceof Number) {
            this.operation = String.format("%1s %1s ", new Object[]{this.operation, Operation.PLUS});
        } else {
            String str = "Cannot concatenate the %1s";
            Object[] objArr = new Object[1];
            objArr[0] = value != null ? value.getClass() : "null";
            throw new IllegalArgumentException(String.format(str, objArr));
        }
        this.value = value;
        this.isValueSet = true;
        return this;
    }

    @NonNull
    public Operator<T> concatenate(@NonNull IConditional conditional) {
        return concatenate((Object) conditional);
    }

    @NonNull
    public Between<T> between(@NonNull T value) {
        return new Between(value);
    }

    @SafeVarargs
    @NonNull
    public final In<T> in(@NonNull T firstArgument, T... arguments) {
        return new In(firstArgument, true, arguments);
    }

    @SafeVarargs
    @NonNull
    public final In<T> notIn(@NonNull T firstArgument, T... arguments) {
        return new In(firstArgument, false, arguments);
    }

    @NonNull
    public In<T> in(@NonNull Collection<T> values) {
        return new In((Collection) values, true);
    }

    @NonNull
    public In<T> notIn(@NonNull Collection<T> values) {
        return new In((Collection) values, false);
    }

    public String convertObjectToString(Object object, boolean appendInnerParenthesis) {
        if (this.typeConverter == null) {
            return super.convertObjectToString(object, appendInnerParenthesis);
        }
        Object converted = object;
        try {
            if (this.convertToDB) {
                converted = this.typeConverter.getDBValue(object);
            } else {
                converted = object;
            }
        } catch (Throwable c) {
            FlowLog.log(Level.W, c);
        }
        return BaseOperator.convertValueToString(converted, appendInnerParenthesis, false);
    }

    private Operator<T> assignValueOp(Object value, String operation) {
        this.operation = operation;
        return value(value);
    }
}
