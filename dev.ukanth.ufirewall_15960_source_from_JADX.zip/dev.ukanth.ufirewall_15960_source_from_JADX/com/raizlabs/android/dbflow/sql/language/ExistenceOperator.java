package com.raizlabs.android.dbflow.sql.language;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.sql.Query;
import com.raizlabs.android.dbflow.sql.QueryBuilder;

public class ExistenceOperator implements SQLOperator, Query {
    private Where innerWhere;

    public void appendConditionToQuery(@NonNull QueryBuilder queryBuilder) {
        queryBuilder.appendQualifier("EXISTS", "(" + this.innerWhere.getQuery().trim() + ")");
    }

    @NonNull
    public String columnName() {
        throw new RuntimeException("Method not valid for ExistenceOperator");
    }

    @Nullable
    public String separator() {
        throw new RuntimeException("Method not valid for ExistenceOperator");
    }

    @NonNull
    public SQLOperator separator(@NonNull String separator) {
        throw new RuntimeException("Method not valid for ExistenceOperator");
    }

    public boolean hasSeparator() {
        return false;
    }

    @NonNull
    public String operation() {
        return "";
    }

    public Object value() {
        return this.innerWhere;
    }

    public ExistenceOperator where(@NonNull Where where) {
        this.innerWhere = where;
        return this;
    }

    public String getQuery() {
        QueryBuilder queryBuilder = new QueryBuilder();
        appendConditionToQuery(queryBuilder);
        return queryBuilder.getQuery();
    }
}
