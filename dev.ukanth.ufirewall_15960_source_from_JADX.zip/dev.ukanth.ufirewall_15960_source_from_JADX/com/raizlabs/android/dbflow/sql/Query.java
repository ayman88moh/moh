package com.raizlabs.android.dbflow.sql;

public interface Query {
    String getQuery();
}
