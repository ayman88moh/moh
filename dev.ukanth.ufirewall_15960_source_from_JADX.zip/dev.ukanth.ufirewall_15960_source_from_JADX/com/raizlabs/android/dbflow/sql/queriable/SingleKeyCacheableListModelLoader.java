package com.raizlabs.android.dbflow.sql.queriable;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.structure.database.FlowCursor;
import java.util.ArrayList;
import java.util.List;

public class SingleKeyCacheableListModelLoader<TModel> extends CacheableListModelLoader<TModel> {
    public SingleKeyCacheableListModelLoader(@NonNull Class<TModel> tModelClass) {
        super(tModelClass);
    }

    @NonNull
    public List<TModel> convertToData(@NonNull FlowCursor cursor, @Nullable List<TModel> data) {
        if (data == null) {
            data = new ArrayList();
        }
        if (cursor.moveToFirst()) {
            do {
                Object cacheValue = getModelAdapter().getCachingColumnValueFromCursor(cursor);
                TModel model = getModelCache().get(cacheValue);
                if (model != null) {
                    getModelAdapter().reloadRelationships(model, cursor);
                    data.add(model);
                } else {
                    model = getModelAdapter().newInstance();
                    getModelAdapter().loadFromCursor(cursor, model);
                    getModelCache().addModel(cacheValue, model);
                    data.add(model);
                }
            } while (cursor.moveToNext());
        }
        return data;
    }
}
