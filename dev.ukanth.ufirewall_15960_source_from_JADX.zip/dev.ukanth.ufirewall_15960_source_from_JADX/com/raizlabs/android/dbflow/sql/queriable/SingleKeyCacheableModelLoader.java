package com.raizlabs.android.dbflow.sql.queriable;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.structure.database.FlowCursor;

public class SingleKeyCacheableModelLoader<TModel> extends CacheableModelLoader<TModel> {
    public SingleKeyCacheableModelLoader(@NonNull Class<TModel> modelClass) {
        super(modelClass);
    }

    @Nullable
    public TModel convertToData(@NonNull FlowCursor cursor, @Nullable TModel data, boolean moveToFirst) {
        if (moveToFirst && !cursor.moveToFirst()) {
            return null;
        }
        Object value = getModelAdapter().getCachingColumnValueFromCursor(cursor);
        TModel model = getModelCache().get(value);
        if (model == null) {
            if (data == null) {
                model = getModelAdapter().newInstance();
            } else {
                model = data;
            }
            getModelAdapter().loadFromCursor(cursor, model);
            getModelCache().addModel(value, model);
            return model;
        }
        getModelAdapter().reloadRelationships(model, cursor);
        return model;
    }
}
