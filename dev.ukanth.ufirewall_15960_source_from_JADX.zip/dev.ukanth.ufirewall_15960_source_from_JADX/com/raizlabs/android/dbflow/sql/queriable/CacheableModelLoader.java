package com.raizlabs.android.dbflow.sql.queriable;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.structure.ModelAdapter;
import com.raizlabs.android.dbflow.structure.cache.ModelCache;
import com.raizlabs.android.dbflow.structure.database.FlowCursor;

public class CacheableModelLoader<TModel> extends SingleModelLoader<TModel> {
    private ModelAdapter<TModel> modelAdapter;
    private ModelCache<TModel, ?> modelCache;

    public CacheableModelLoader(@NonNull Class<TModel> modelClass) {
        super(modelClass);
    }

    @NonNull
    public ModelAdapter<TModel> getModelAdapter() {
        if (this.modelAdapter == null) {
            if (getInstanceAdapter() instanceof ModelAdapter) {
                this.modelAdapter = (ModelAdapter) getInstanceAdapter();
                if (!this.modelAdapter.cachingEnabled()) {
                    throw new IllegalArgumentException("You cannot call this method for a table that has no caching id. Eitheruse one Primary Key or use the MultiCacheKeyConverter");
                }
            }
            throw new IllegalArgumentException("A non-Table type was used.");
        }
        return this.modelAdapter;
    }

    @NonNull
    public ModelCache<TModel, ?> getModelCache() {
        if (this.modelCache == null) {
            this.modelCache = getModelAdapter().getModelCache();
        }
        return this.modelCache;
    }

    @Nullable
    public TModel convertToData(@NonNull FlowCursor cursor, @Nullable TModel data, boolean moveToFirst) {
        if (moveToFirst && !cursor.moveToFirst()) {
            return null;
        }
        Object[] values = getModelAdapter().getCachingColumnValuesFromCursor(new Object[getModelAdapter().getCachingColumns().length], cursor);
        TModel model = getModelCache().get(getModelAdapter().getCachingId(values));
        if (model == null) {
            if (data == null) {
                model = getModelAdapter().newInstance();
            } else {
                model = data;
            }
            getModelAdapter().loadFromCursor(cursor, model);
            getModelCache().addModel(getModelAdapter().getCachingId(values), model);
            return model;
        }
        getModelAdapter().reloadRelationships(model, cursor);
        return model;
    }
}
