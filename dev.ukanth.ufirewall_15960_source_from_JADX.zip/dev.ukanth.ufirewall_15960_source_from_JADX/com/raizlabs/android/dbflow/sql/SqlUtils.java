package com.raizlabs.android.dbflow.sql;

import android.content.ContentValues;
import android.net.Uri;
import android.net.Uri.Builder;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.raizlabs.android.dbflow.StringUtils;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.raizlabs.android.dbflow.runtime.NotifyDistributor;
import com.raizlabs.android.dbflow.sql.language.NameAlias;
import com.raizlabs.android.dbflow.sql.language.Operator;
import com.raizlabs.android.dbflow.sql.language.OperatorGroup;
import com.raizlabs.android.dbflow.sql.language.SQLOperator;
import com.raizlabs.android.dbflow.structure.BaseModel.Action;
import com.raizlabs.android.dbflow.structure.ModelAdapter;
import com.raizlabs.android.dbflow.structure.database.DatabaseStatement;
import com.raizlabs.android.dbflow.structure.database.DatabaseWrapper;
import java.util.Map.Entry;

public class SqlUtils {
    private static final char[] hexArray = "0123456789ABCDEF".toCharArray();

    @Deprecated
    public static void notifyModelChanged(Class<?> table, Action action, Iterable<SQLOperator> sqlOperators) {
        FlowManager.getContext().getContentResolver().notifyChange(getNotificationUri((Class) table, action, (Iterable) sqlOperators), null, true);
    }

    @Deprecated
    public static <TModel> void notifyModelChanged(@Nullable TModel model, @NonNull ModelAdapter<TModel> modelAdapter, @NonNull Action action) {
        NotifyDistributor.get().notifyModelChanged(model, modelAdapter, action);
    }

    @Deprecated
    public static <TModel> void notifyTableChanged(@NonNull Class<TModel> table, @NonNull Action action) {
        NotifyDistributor.get().notifyTableChanged(table, action);
    }

    public static Uri getNotificationUri(@NonNull Class<?> modelClass, @Nullable Action action, @Nullable Iterable<SQLOperator> conditions) {
        Builder uriBuilder = new Builder().scheme("dbflow").authority(FlowManager.getTableName(modelClass));
        if (action != null) {
            uriBuilder.fragment(action.name());
        }
        if (conditions != null) {
            for (SQLOperator condition : conditions) {
                uriBuilder.appendQueryParameter(Uri.encode(condition.columnName()), Uri.encode(String.valueOf(condition.value())));
            }
        }
        return uriBuilder.build();
    }

    public static Uri getNotificationUri(@NonNull Class<?> modelClass, @NonNull Action action, @Nullable SQLOperator[] conditions) {
        Builder uriBuilder = new Builder().scheme("dbflow").authority(FlowManager.getTableName(modelClass));
        if (action != null) {
            uriBuilder.fragment(action.name());
        }
        if (conditions != null && conditions.length > 0) {
            for (SQLOperator condition : conditions) {
                if (condition != null) {
                    uriBuilder.appendQueryParameter(Uri.encode(condition.columnName()), Uri.encode(String.valueOf(condition.value())));
                }
            }
        }
        return uriBuilder.build();
    }

    public static Uri getNotificationUri(@NonNull Class<?> modelClass, @NonNull Action action, @NonNull String notifyKey, @Nullable Object notifyValue) {
        Operator operator = null;
        if (StringUtils.isNotNullOrEmpty(notifyKey)) {
            operator = Operator.op(new NameAlias.Builder(notifyKey).build()).value(notifyValue);
        }
        return getNotificationUri((Class) modelClass, action, new SQLOperator[]{operator});
    }

    public static Uri getNotificationUri(@NonNull Class<?> modelClass, @NonNull Action action) {
        return getNotificationUri(modelClass, action, null, null);
    }

    public static void dropTrigger(@NonNull Class<?> mOnTable, @NonNull String triggerName) {
        FlowManager.getDatabaseForTable(mOnTable).getWritableDatabase().execSQL(new QueryBuilder("DROP TRIGGER IF EXISTS ").append(triggerName).getQuery());
    }

    public static void dropIndex(@NonNull DatabaseWrapper databaseWrapper, @NonNull String indexName) {
        databaseWrapper.execSQL(new QueryBuilder("DROP INDEX IF EXISTS ").append(QueryBuilder.quoteIfNeeded(indexName)).getQuery());
    }

    public static void dropIndex(@NonNull Class<?> onTable, @NonNull String indexName) {
        dropIndex(FlowManager.getDatabaseForTable(onTable).getWritableDatabase(), indexName);
    }

    public static void addContentValues(@NonNull ContentValues contentValues, @NonNull OperatorGroup operatorGroup) {
        for (Entry<String, Object> entry : contentValues.valueSet()) {
            String key = (String) entry.getKey();
            operatorGroup.and(Operator.op(new NameAlias.Builder(key).build()).is(contentValues.get(key)));
        }
    }

    @NonNull
    public static String getContentValuesKey(ContentValues contentValues, String key) {
        String quoted = QueryBuilder.quoteIfNeeded(key);
        if (contentValues.containsKey(quoted)) {
            return quoted;
        }
        String stripped = QueryBuilder.stripQuotes(key);
        if (contentValues.containsKey(stripped)) {
            return stripped;
        }
        throw new IllegalArgumentException("Could not find the specified key in the Content Values object.");
    }

    public static long longForQuery(@NonNull DatabaseWrapper wrapper, @NonNull String query) {
        DatabaseStatement statement = wrapper.compileStatement(query);
        try {
            long simpleQueryForLong = statement.simpleQueryForLong();
            return simpleQueryForLong;
        } finally {
            statement.close();
        }
    }

    @NonNull
    public static String byteArrayToHexString(byte[] bytes) {
        char[] hexChars = new char[(bytes.length * 2)];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 255;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[(j * 2) + 1] = hexArray[v & 15];
        }
        return new String(hexChars);
    }
}
