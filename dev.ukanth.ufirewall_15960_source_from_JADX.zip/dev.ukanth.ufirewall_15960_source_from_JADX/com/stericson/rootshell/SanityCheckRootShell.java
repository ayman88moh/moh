package com.stericson.rootshell;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.os.StrictMode.ThreadPolicy.Builder;
import android.os.StrictMode.VmPolicy;
import android.support.v4.media.TransportMediator;
import android.widget.ScrollView;
import android.widget.TextView;
import com.stericson.rootshell.exceptions.RootDeniedException;
import com.stericson.rootshell.execution.Command;
import com.stericson.rootshell.execution.Shell.ShellContext;
import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class SanityCheckRootShell extends Activity {
    private ProgressDialog mPDialog;
    private ScrollView mScrollView;
    private TextView mTextView;

    class C02681 implements Runnable {
        C02681() {
        }

        public void run() {
            SanityCheckRootShell.this.mScrollView.fullScroll(TransportMediator.KEYCODE_MEDIA_RECORD);
        }
    }

    private class SanityCheckThread extends Thread {
        private Handler mHandler;

        public SanityCheckThread(Context context, Handler handler) {
            this.mHandler = handler;
        }

        public void run() {
            visualUpdate(1, null);
            visualUpdate(4, "Testing getPath");
            visualUpdate(3, "[ getPath ]\n");
            try {
                for (String path : RootShell.getPath()) {
                    visualUpdate(3, path + " k\n\n");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            visualUpdate(4, "Testing A ton of commands");
            visualUpdate(3, "[ Ton of Commands ]\n");
            for (int i = 0; i < 100; i++) {
                RootShell.exists("/system/xbin/busybox");
            }
            visualUpdate(4, "Testing Find Binary");
            boolean result = RootShell.isRootAvailable();
            visualUpdate(3, "[ Checking Root ]\n");
            visualUpdate(3, result + " k\n\n");
            result = RootShell.isBusyboxAvailable();
            visualUpdate(3, "[ Checking Busybox ]\n");
            visualUpdate(3, result + " k\n\n");
            visualUpdate(4, "Testing file exists");
            visualUpdate(3, "[ Checking Exists() ]\n");
            visualUpdate(3, RootShell.exists("/system/sbin/[") + " k\n\n");
            visualUpdate(4, "Testing Is Access Given");
            result = RootShell.isAccessGiven();
            visualUpdate(3, "[ Checking for Access to Root ]\n");
            visualUpdate(3, result + " k\n\n");
            visualUpdate(4, "Testing output capture");
            visualUpdate(3, "[ busybox ash --help ]\n");
            try {
                RootShell.getShell(true).add(new Command(0, "busybox ash --help") {
                    public void commandOutput(int id, String line) {
                        SanityCheckThread.this.visualUpdate(3, line + "\n");
                    }
                });
            } catch (Exception e2) {
                e2.printStackTrace();
            }
            visualUpdate(4, "Switching RootContext - SYSTEM_APP");
            visualUpdate(3, "[ Switching Root Context - SYSTEM_APP ]\n");
            try {
                RootShell.getShell(true, ShellContext.SYSTEM_APP).add(new Command(0, "id") {
                    public void commandOutput(int id, String line) {
                        SanityCheckThread.this.visualUpdate(3, line + "\n");
                        super.commandOutput(id, line);
                    }
                });
            } catch (Exception e22) {
                e22.printStackTrace();
            }
            visualUpdate(4, "Switching RootContext - UNTRUSTED");
            visualUpdate(3, "[ Switching Root Context - UNTRUSTED ]\n");
            try {
                RootShell.getShell(true, ShellContext.UNTRUSTED_APP).add(new Command(0, "id") {
                    public void commandOutput(int id, String line) {
                        SanityCheckThread.this.visualUpdate(3, line + "\n");
                        super.commandOutput(id, line);
                    }
                });
            } catch (Exception e222) {
                e222.printStackTrace();
            }
            try {
                RootShell.getShell(true).add(new Command(42, false, "echo done") {
                    boolean _catch = false;

                    public void commandOutput(int id, String line) {
                        if (this._catch) {
                            RootShell.log("CAUGHT!!!");
                        }
                        super.commandOutput(id, line);
                    }

                    public void commandTerminated(int id, String reason) {
                        synchronized (SanityCheckRootShell.this) {
                            this._catch = true;
                            SanityCheckThread.this.visualUpdate(4, "All tests complete.");
                            SanityCheckThread.this.visualUpdate(2, null);
                            try {
                                RootShell.closeAllShells();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    public void commandCompleted(int id, int exitCode) {
                        synchronized (SanityCheckRootShell.this) {
                            this._catch = true;
                            SanityCheckThread.this.visualUpdate(4, "All tests complete.");
                            SanityCheckThread.this.visualUpdate(2, null);
                            try {
                                RootShell.closeAllShells();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                });
            } catch (Exception e2222) {
                e2222.printStackTrace();
            }
        }

        private void visualUpdate(int action, String text) {
            Message msg = this.mHandler.obtainMessage();
            Bundle bundle = new Bundle();
            bundle.putInt("action", action);
            bundle.putString("text", text);
            msg.setData(bundle);
            this.mHandler.sendMessage(msg);
        }
    }

    private class TestHandler extends Handler {
        public static final String ACTION = "action";
        public static final int ACTION_DISPLAY = 3;
        public static final int ACTION_HIDE = 2;
        public static final int ACTION_PDISPLAY = 4;
        public static final int ACTION_SHOW = 1;
        public static final String TEXT = "text";

        private TestHandler() {
        }

        public void handleMessage(Message msg) {
            int action = msg.getData().getInt("action");
            String text = msg.getData().getString("text");
            switch (action) {
                case 1:
                    SanityCheckRootShell.this.mPDialog.show();
                    SanityCheckRootShell.this.mPDialog.setMessage("Running Root Library Tests...");
                    return;
                case 2:
                    if (text != null) {
                        SanityCheckRootShell.this.print(text);
                    }
                    SanityCheckRootShell.this.mPDialog.hide();
                    return;
                case 3:
                    SanityCheckRootShell.this.print(text);
                    return;
                case 4:
                    SanityCheckRootShell.this.mPDialog.setMessage(text);
                    return;
                default:
                    return;
            }
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.setThreadPolicy(new Builder().detectDiskReads().detectDiskWrites().detectNetwork().penaltyLog().build());
        StrictMode.setVmPolicy(new VmPolicy.Builder().detectLeakedSqlLiteObjects().detectLeakedClosableObjects().penaltyLog().penaltyDeath().build());
        RootShell.debugMode = true;
        this.mTextView = new TextView(this);
        this.mTextView.setText("");
        this.mScrollView = new ScrollView(this);
        this.mScrollView.addView(this.mTextView);
        setContentView(this.mScrollView);
        print("SanityCheckRootShell \n\n");
        if (RootShell.isRootAvailable()) {
            print("Root found.\n");
        } else {
            print("Root not found");
        }
        try {
            RootShell.getShell(true);
        } catch (IOException e2) {
            e2.printStackTrace();
        } catch (TimeoutException e) {
            print("[ TIMEOUT EXCEPTION! ]\n");
            e.printStackTrace();
        } catch (RootDeniedException e3) {
            print("[ ROOT DENIED EXCEPTION! ]\n");
            e3.printStackTrace();
        }
        try {
            if (RootShell.isAccessGiven()) {
                this.mPDialog = new ProgressDialog(this);
                this.mPDialog.setCancelable(false);
                this.mPDialog.setProgressStyle(0);
                new SanityCheckThread(this, new TestHandler()).start();
                return;
            }
            print("ERROR: No root access to this device.\n");
        } catch (Exception e4) {
            print("ERROR: could not determine root access to this device.\n");
        }
    }

    protected void print(CharSequence text) {
        this.mTextView.append(text);
        this.mScrollView.post(new C02681());
    }
}
