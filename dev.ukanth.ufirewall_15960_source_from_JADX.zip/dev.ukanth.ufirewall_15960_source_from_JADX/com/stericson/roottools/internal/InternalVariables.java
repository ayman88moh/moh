package com.stericson.roottools.internal;

import com.stericson.roottools.containers.Mount;
import com.stericson.roottools.containers.Permissions;
import com.stericson.roottools.containers.Symlink;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class InternalVariables {
    protected static final String PS_REGEX = "^\\S+\\s+([0-9]+).*$";
    protected static String busyboxVersion;
    protected static boolean found = false;
    protected static String getSpaceFor;
    protected static String inode = "";
    protected static ArrayList<Mount> mounts;
    protected static boolean nativeToolsReady = false;
    protected static Permissions permissions;
    protected static String pid_list = "";
    protected static boolean processRunning = false;
    protected static Pattern psPattern = Pattern.compile(PS_REGEX);
    protected static String[] space;
    protected static ArrayList<Symlink> symlinks;
}
