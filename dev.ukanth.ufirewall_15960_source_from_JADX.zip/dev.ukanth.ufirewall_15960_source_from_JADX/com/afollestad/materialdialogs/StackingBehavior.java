package com.afollestad.materialdialogs;

public enum StackingBehavior {
    ALWAYS,
    ADAPTIVE,
    NEVER
}
