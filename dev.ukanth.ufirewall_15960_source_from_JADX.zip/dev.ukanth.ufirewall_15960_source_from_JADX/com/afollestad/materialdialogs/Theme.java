package com.afollestad.materialdialogs;

public enum Theme {
    LIGHT,
    DARK
}
