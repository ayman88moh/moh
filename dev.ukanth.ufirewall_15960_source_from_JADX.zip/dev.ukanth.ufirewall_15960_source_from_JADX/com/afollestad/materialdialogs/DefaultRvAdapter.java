package com.afollestad.materialdialogs;

import android.annotation.TargetApi;
import android.os.Build.VERSION;
import android.support.annotation.LayoutRes;
import android.support.v7.widget.RecyclerView.Adapter;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import com.afollestad.materialdialogs.internal.MDTintHelper;
import com.afollestad.materialdialogs.util.DialogUtils;

class DefaultRvAdapter extends Adapter<DefaultVH> {
    private InternalListCallback callback;
    private final MaterialDialog dialog;
    private final GravityEnum itemGravity;
    @LayoutRes
    private final int layout;

    interface InternalListCallback {
        boolean onItemSelected(MaterialDialog materialDialog, View view, int i, CharSequence charSequence, boolean z);
    }

    static class DefaultVH extends ViewHolder implements OnClickListener, OnLongClickListener {
        final DefaultRvAdapter adapter;
        final CompoundButton control;
        final TextView title;

        DefaultVH(View itemView, DefaultRvAdapter adapter) {
            super(itemView);
            this.control = (CompoundButton) itemView.findViewById(C0244R.id.md_control);
            this.title = (TextView) itemView.findViewById(C0244R.id.md_title);
            this.adapter = adapter;
            itemView.setOnClickListener(this);
            if (adapter.dialog.builder.listLongCallback != null) {
                itemView.setOnLongClickListener(this);
            }
        }

        public void onClick(View view) {
            if (this.adapter.callback != null && getAdapterPosition() != -1) {
                CharSequence text = null;
                if (this.adapter.dialog.builder.items != null && getAdapterPosition() < this.adapter.dialog.builder.items.size()) {
                    text = (CharSequence) this.adapter.dialog.builder.items.get(getAdapterPosition());
                }
                this.adapter.callback.onItemSelected(this.adapter.dialog, view, getAdapterPosition(), text, false);
            }
        }

        public boolean onLongClick(View view) {
            if (this.adapter.callback == null || getAdapterPosition() == -1) {
                return false;
            }
            CharSequence text = null;
            if (this.adapter.dialog.builder.items != null && getAdapterPosition() < this.adapter.dialog.builder.items.size()) {
                text = (CharSequence) this.adapter.dialog.builder.items.get(getAdapterPosition());
            }
            return this.adapter.callback.onItemSelected(this.adapter.dialog, view, getAdapterPosition(), text, true);
        }
    }

    DefaultRvAdapter(MaterialDialog dialog, @LayoutRes int layout) {
        this.dialog = dialog;
        this.layout = layout;
        this.itemGravity = dialog.builder.itemsGravity;
    }

    void setCallback(InternalListCallback callback) {
        this.callback = callback;
    }

    public DefaultVH onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(this.layout, parent, false);
        DialogUtils.setBackgroundCompat(view, this.dialog.getListSelector());
        return new DefaultVH(view, this);
    }

    public void onBindViewHolder(DefaultVH holder, int index) {
        boolean z;
        View view = holder.itemView;
        boolean disabled = DialogUtils.isIn(Integer.valueOf(index), this.dialog.builder.disabledIndices);
        int itemTextColor = disabled ? DialogUtils.adjustAlpha(this.dialog.builder.itemColor, 0.4f) : this.dialog.builder.itemColor;
        View view2 = holder.itemView;
        if (disabled) {
            z = false;
        } else {
            z = true;
        }
        view2.setEnabled(z);
        boolean selected;
        switch (this.dialog.listType) {
            case SINGLE:
                RadioButton radio = holder.control;
                if (this.dialog.builder.selectedIndex == index) {
                    selected = true;
                } else {
                    selected = false;
                }
                if (this.dialog.builder.choiceWidgetColor != null) {
                    MDTintHelper.setTint(radio, this.dialog.builder.choiceWidgetColor);
                } else {
                    MDTintHelper.setTint(radio, this.dialog.builder.widgetColor);
                }
                radio.setChecked(selected);
                if (disabled) {
                    z = false;
                } else {
                    z = true;
                }
                radio.setEnabled(z);
                break;
            case MULTI:
                CheckBox checkbox = holder.control;
                selected = this.dialog.selectedIndicesList.contains(Integer.valueOf(index));
                if (this.dialog.builder.choiceWidgetColor != null) {
                    MDTintHelper.setTint(checkbox, this.dialog.builder.choiceWidgetColor);
                } else {
                    MDTintHelper.setTint(checkbox, this.dialog.builder.widgetColor);
                }
                checkbox.setChecked(selected);
                if (disabled) {
                    z = false;
                } else {
                    z = true;
                }
                checkbox.setEnabled(z);
                break;
        }
        holder.title.setText((CharSequence) this.dialog.builder.items.get(index));
        holder.title.setTextColor(itemTextColor);
        this.dialog.setTypeface(holder.title, this.dialog.builder.regularFont);
        setupGravity((ViewGroup) view);
        if (this.dialog.builder.itemIds != null) {
            if (index < this.dialog.builder.itemIds.length) {
                view.setId(this.dialog.builder.itemIds[index]);
            } else {
                view.setId(-1);
            }
        }
        if (VERSION.SDK_INT >= 21) {
            ViewGroup group = (ViewGroup) view;
            if (group.getChildCount() != 2) {
                return;
            }
            if (group.getChildAt(0) instanceof CompoundButton) {
                group.getChildAt(0).setBackground(null);
            } else if (group.getChildAt(1) instanceof CompoundButton) {
                group.getChildAt(1).setBackground(null);
            }
        }
    }

    public int getItemCount() {
        return this.dialog.builder.items != null ? this.dialog.builder.items.size() : 0;
    }

    @TargetApi(17)
    private void setupGravity(ViewGroup view) {
        ((LinearLayout) view).setGravity(this.itemGravity.getGravityInt() | 16);
        if (view.getChildCount() != 2) {
            return;
        }
        CompoundButton first;
        TextView second;
        if (this.itemGravity == GravityEnum.END && !isRTL() && (view.getChildAt(0) instanceof CompoundButton)) {
            first = (CompoundButton) view.getChildAt(0);
            view.removeView(first);
            second = (TextView) view.getChildAt(0);
            view.removeView(second);
            second.setPadding(second.getPaddingRight(), second.getPaddingTop(), second.getPaddingLeft(), second.getPaddingBottom());
            view.addView(second);
            view.addView(first);
        } else if (this.itemGravity == GravityEnum.START && isRTL() && (view.getChildAt(1) instanceof CompoundButton)) {
            first = (CompoundButton) view.getChildAt(1);
            view.removeView(first);
            second = (TextView) view.getChildAt(0);
            view.removeView(second);
            second.setPadding(second.getPaddingRight(), second.getPaddingTop(), second.getPaddingRight(), second.getPaddingBottom());
            view.addView(first);
            view.addView(second);
        }
    }

    @TargetApi(17)
    private boolean isRTL() {
        boolean z = true;
        if (VERSION.SDK_INT < 17) {
            return false;
        }
        if (this.dialog.getBuilder().getContext().getResources().getConfiguration().getLayoutDirection() != 1) {
            z = false;
        }
        return z;
    }
}
