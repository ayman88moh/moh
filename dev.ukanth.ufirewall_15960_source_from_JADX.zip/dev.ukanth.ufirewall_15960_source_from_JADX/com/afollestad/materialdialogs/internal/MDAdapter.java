package com.afollestad.materialdialogs.internal;

import com.afollestad.materialdialogs.MaterialDialog;

public interface MDAdapter {
    void setDialog(MaterialDialog materialDialog);
}
