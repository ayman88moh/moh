package com.afollestad.materialdialogs;

public final class BuildConfig {
    public static final String APPLICATION_ID = "com.afollestad.materialdialogs";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 175;
    public static final String VERSION_NAME = "0.9.4.5";
}
