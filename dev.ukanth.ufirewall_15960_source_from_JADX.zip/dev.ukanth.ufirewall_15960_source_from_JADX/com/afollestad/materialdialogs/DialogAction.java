package com.afollestad.materialdialogs;

public enum DialogAction {
    POSITIVE,
    NEUTRAL,
    NEGATIVE
}
