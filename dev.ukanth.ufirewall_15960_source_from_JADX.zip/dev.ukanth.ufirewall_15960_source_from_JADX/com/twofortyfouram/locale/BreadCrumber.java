package com.twofortyfouram.locale;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import dev.ukanth.ufirewall.C0285R;

public final class BreadCrumber {
    private BreadCrumber() {
        throw new UnsupportedOperationException("This class is non-instantiable");
    }

    public static CharSequence generateBreadcrumb(Context context, Intent intent, String currentCrumb) {
        if (context == null) {
            throw new IllegalArgumentException("context cannot be null");
        } else if (currentCrumb == null) {
            try {
                Log.w("LocaleApiLibrary", "currentCrumb cannot be null");
                return "";
            } catch (Exception e) {
                Log.e("LocaleApiLibrary", "Encountered error generating breadcrumb", e);
                return "";
            }
        } else if (intent == null) {
            Log.w("LocaleApiLibrary", "intent cannot be null");
            return currentCrumb;
        } else {
            if (intent.getStringExtra(Intent.EXTRA_STRING_BREADCRUMB) == null) {
                return currentCrumb;
            }
            return context.getString(C0285R.string.twofortyfouram_locale_breadcrumb_format, new Object[]{intent.getStringExtra(Intent.EXTRA_STRING_BREADCRUMB), context.getString(C0285R.string.twofortyfouram_locale_breadcrumb_separator), currentCrumb});
        }
    }
}
