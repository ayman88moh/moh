package com.twofortyfouram.locale;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class PackageUtilities {
    private static final Set<String> COMPATIBLE_PACKAGES = constructPackageSet();

    private static Set<String> constructPackageSet() {
        HashSet<String> packages = new HashSet();
        packages.add("com.twofortyfouram.locale");
        packages.add("net.dinglisch.android.taskerm");
        packages.add("net.dinglisch.android.tasker");
        packages.add("net.dinglisch.android.taskercupcake");
        return Collections.unmodifiableSet(packages);
    }

    public static String getCompatiblePackage(PackageManager manager, String packageHint) {
        String temp;
        List<PackageInfo> installedPackages = manager.getInstalledPackages(0);
        if (COMPATIBLE_PACKAGES.contains(packageHint)) {
            for (PackageInfo packageInfo : installedPackages) {
                temp = packageInfo.packageName;
                if (packageHint.equals(temp)) {
                    return temp;
                }
            }
        }
        for (String compatiblePackageName : COMPATIBLE_PACKAGES) {
            if (!compatiblePackageName.equals(packageHint)) {
                for (PackageInfo packageInfo2 : installedPackages) {
                    temp = packageInfo2.packageName;
                    if (compatiblePackageName.equals(temp)) {
                        return temp;
                    }
                }
                continue;
            }
        }
        return null;
    }
}
