package com.twofortyfouram.locale;

final class Constants {
    static final String LOCALE_PACKAGE = "com.twofortyfouram.locale";
    static final String LOG_TAG = "LocaleApiLibrary";

    private Constants() {
        throw new UnsupportedOperationException("This class is non-instantiable");
    }
}
